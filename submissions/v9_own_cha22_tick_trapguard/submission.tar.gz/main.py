# Kaggriculture submission, team 42 (Kefei Yan, Frank Yang, yirenw11).
# Base agent: cha22 agent (Abhinav0370) (Apache-2.0, upstream notices retained inside the embedded source
# and in NOTICE.txt). Modifications by team 42, 2026-09-25:
# 1. order-slot priority layer. From step 288 on, each turn's market list is rewritten so that SELL
#    orders are issued before placeholder slots and before fixed-price orders (HIRE, BUY_SEED,
#    BUY_ANIMAL, BUY_LAND). BUY_PRODUCT orders keep their relative position. Quantities are unchanged.
# 2. day-end room guard (True). At hour 23 the projected shed after this turn's unit actions, market
#    orders and the end-of-day inventory drop is computed with the engine's rules; units that the
#    100-item cap would discard are sold instead.
# 3. eager sale layer. From step 288 to step 700, shed stock that the turn's orders do not
#    already sell is sold on arrival while the quote lies in the band (share of base price):
#    MILK 0.3-0.9, STRAWBERRY 0.3-0.9, WOOL 0.3-0.9.
# 4. sale ordering layer. From step 288, SELL orders are permuted among the slots they already
#    occupy, largest same-step race stake first (the market's own price function); ties within 10 keep
#    the base order.
#    The base policy is otherwise unchanged.
import base64 as _b64
import math
import zlib as _zlib

_BASE_SHA256 = "127ed3e62988c0474d386db6527ae8ca9de9bb1fe7004128557ddef67126c652"
_BASE_SRC = _zlib.decompress(_b64.b85decode(
    'c-q{(XLsVvvM~Dntabi_FgAx^Jmg@q$vFpm?f?P=2!w<sk!}C>w}T`k5FS5!@AIyE?>u2ZbXQkbS6A+qktmY08BdQljJV+`LfDK}v>?zNOKgL`+|R^%Gh*m5'
    '(QyX}b7D=7=ak*`<ai`lPNc__K#VAc+gXS;vk?e!PJvzoLmntz`0xKR5{*PMUF#7uQluWy7sAX_0>y7h5sonBxfLOZ)S7SxU5~_^<LM)K>~Rpkh!x4tXqIrg'
    'ERRI8+HU024e%k+XjEGS$xet|x{-oIkn1(YPN)e%ifDZBh2W;(BP|e9nxURxqjaxkclzA~EpQCLh2TIRnw`NxmXt^c)cb~F#}q-c!kXp*u+f1y%*jK*`Ae8{'
    'Ydg<vM2fdNf=;JhpjT^#QWL|1#?aCcjp*|eV}L6?0b@Q96;8zD6-9{dM&wq23}cdE4hTR(6nT2Ifs}a$_=8^sQ5er@c1bah5;~8>gc8INAR_k&K=9<=|44|G'
    'C~QQMr5_=fHNO?;1IZ#PrNC%BO%qvWbDVJ7C*q7XfW*^yA%u{!oIE9xGz%#J*Hvd?TelOe4w{}9jGdUTK;svR2js6FDgKdYQfrY~jVPW75-x|!hhQ`*h8n|Z'
    'uc+}HU@EMhi80Tu2bjGE91pMoB%*d;4JH&?QdT6!96P1?73LNiV)wp*>w{p{B+hiXoG-t?|2;`CcW$y7!`8n<dIeXQ0h1wT)U!gCM->SWm?}>LMk5)50;6#&'
    'dMqHy(X2?#cr<e8OqI=A5P6DR0k~s|6#&7e9CL$Eu7E-)&yNX}1k{;P!n3rv#DqN9AxjG)$Aftgvkl2lLYM1Gtmg*-vJ&70euZWOSY*7R&<>f9Ye;&L12};t'
    '+tK2j@Oi-c<HocAmYx7?y<spnJYA9qE(?jsN{Hl|!URG~2Ed{XvL<OB?56dz{<d)hugHE$Ebk+xl_&U2G(l(3DWF=<M?xUMu45>2@_3%)7zhbYnks_Y*sx&X'
    'DFQGV5MqFg=TSqq_mr}MFbse-WF0t3N%~2X2m6@3HN(Io6lX_@Rjn&{rYtP{@2`I_wnPat*I&AHfRKe)A#q$FS-=?wFrLHnUB9^~uAhJX+U<5vBpU3A<7dBQ'
    'ZvLghw3Tj@n?$0L0^+xl%D3{>N|VS`8$`RA2EsgDYgAM1Bz*jcTBY*MRwMt?hEG&roKHlGngTAvtfeKzoix)sz(qg~0_gzc7L?*}g)y6fO*z4R!B*pmjQ}(W'
    'PpKH=3=KA)0B)A0C_xH<$){MH9l*MbF&rlt0xaBY4mO^wDkj``vjQSVA3=`4!f?#34?uFvMS|P0V66depgS!dpkzmy42^mQrPoQE18D$82ZDx0JSU!4{|Xao'
    '1~@*A#<;>}!@~KZ$xw(}0W29EKo!vT42c76BxGqyz&HRZi#!Lm1j$qK7Y0q>5zY)g-2joygWpywjy(gD+G3%CK;dDZhz!RgY}Olo%|S`2kXm5})!N-jfbP(o'
    '1j0;PaBpr0W#t4&{jms90qOyLeuVODOagv@?aqMkuZS8@BC$Yd!gYnC3!Cv=LJvs6Ifdu|7y}JWBJdYf+R>2R03b6B@Ih-P%;_}*Hl?S4xNC|ZL+EC&<H3SP'
    '<N&GgI;dc6L_vgx09X~Ua6n$kKmpVd#R7tiX|TAO0aVytvcfC3xg*Q~0{q0^S=8JB{)Hsk(vuB@$P;S5Im4j#0CQS^7_Ff+MJAubh<Ll8wYtHJO)%^j>{_rR'
    'SC_1~=BX*gL(PDGouXw}B5RAA&|s!m$*9(zX2;A15eMvBXo&#r3iKORSpqi|caZ-CG$vTA30M+&yCPU;NVv_TEI6k0Y{N^YCNKrBq)&CU0K9TN4U#?JXJDm('
    'f`XVKQ&lovfSy%tYd|ppHYR1JLr)m#>y#h~Of3ZQQ9Ic)n2TA1ZMLT22ILTm(yV8IRlt0}W6k_8L?D>>7OMsUg2LM!7#}oAh==tx6}lY1yb>ro@DO2-gc;<?'
    '^OgZ-xils9hQY*?X1O9KKn`t5njuGwEIU-f?Gegm$fsjcVmDGPQ)DTLtx`oyV%kyAI73oN6rlz~1e0+-LotJyP<s*?>!2^t7+_D}zOZou`3>}5a$qirl9G($'
    'Ek!{32zQtK0SD73iA0GrFiaA85+hQ8>&l`HjBIeYRRDWofd@xJ%Lq5lZcdNqT3G_t5txEBvhcPvT4l)ZfKt-FA}By}j+egyC=v&#ci$Nv)TO{BV@0$iBp8xo'
    '&<+AUCByid7p|qdO4v;`qT`XcB&9@2$nnyGq7fub#8WF^YOA(1wI+GQM36>kJ}Y2%G6!hdFA)((fRP{zvE+)f$jkukcYaEak>YvOs$qr3SExZsQQY*B8<J2%'
    'NLGa|CtPk7WtVFQR!AysP+4Ou2tjz7g+hEjkt`q;Fb-1-bp%arP2^FvcSNX6I2QVwD)K50DF7)OJBatt6cCcqjzMD~#c*ZFs8%0o)NhrL+CYK=9$^4C#E1ff'
    'odTMCYc&1LvLNo1ncbbiVcS9x@1P&@OL-0m^+&iUBa%TZw&P(}7MVL6R$2@KZj*~Opw2{tG!upMhC<6BJbtU*)Iv`^68QIw8IYzlgPmF6y*#Qlp<;gt2LU)8'
    '!i6dTYJEdNg)~MASZaiM0_s$3A1P*@dJP`6Vn@RoD&j*L0-Jlh5d_(1qE|@PO4e)_$w`f_qxLdEw3C)u70gLk1J{t-2w<C|7|leHW6&g1S$mW~&sd~G0GGm5'
    'Lv+?<QYhc<U=W5R)cg7A?$&0%u=*7e$Q$)1c9xo?P`0ivMkj!y3R(bG17<6QbOFF#J(Omz;z*Uqz`@5HSOIJfK<itzOV#4b^+aT$Q3uCQDg=@3I-<G3YFlDv'
    'UB64aA=RRt0{WLw(Tjjm2jGv)NMwBg0~O2|n3!uy1cXxYClH&=WJg20hUHj0VhRBe0DiRtJByz|Pmep0jCin5c?x`^fmylb#!wsRSqqXE3x}0GM9>NB#x>;i'
    'D-o$t3)s;IbOp@3W=OCflqUdrtic8JL^5C0zUGAsqDXUO!e5Q6V=EwWq+T_*YSn5al-&P+S~4@}Nv%b=A%R~c%0?MLQ^3BPg;?WBtCkcv5dhwt+)~K8RH21p'
    '0^D>8O-!IqC<e%I{C^;dI9|l7rAQCSWS0z5B%f4Mgyg^rCy!08*9>%&ITkPjB07|N5`trfqyhPHTkR|XQ4t(9u@%Y7g553%Bu}HQJmrDdlHD$fR_Rl<tS}1}'
    ';K_3=C23h8J%Q<?I2x$uWe3&Fu!k<`aWD^TTxwC2M%lrYk@e>jk)J}QP&;e_kaCdkm1Pp?8AgPhk??0EAf*U|`K$reRzA-Of*sKh&S%VRpv8v219l(@hTI7o'
    'T7+|Es2SELQjou^vGk#w)C$$_gd<Wf7=1yC7HB|?&&zd?=O?ew3faj361M!bOsX=^WH(ycO|tuQ-iMMJl`S}|Wu&mCsNx|~kWECGLy-AWA-0s`n5adE=ZR=g'
    '>M+<7!eK=o&QkGGd;u9s%XZYIAp6F;MC$}CRxsXXB}JB@^#uOr)EZyw`AhM2eJS{O_S6u4G>o^RD9ivj>W)naS?E1$^|+a|;E8VlH_jmL5LN68fkmgmjG@3&'
    'Ti|MU7XG=KH;J^(rHd1i)wF8xk!o-pr8=AT(BFgM2pqxUA)5i$hGrozNqHD89#BXs{13s7QI=qWNdZCWp)gjVfD;&xvMH~MNFdJzpmsS|Ee6WSXQp|C`|_-P'
    'AEn*!2*vA!f>zt3)_g(ye9mzxDJK+K(ZNbbI%};*EQn<=2*nA93~Zph;Cvy0@jm56jY^bVi_1ytk#S;y@=xIr$z_GSa963e^2zia*tmNUtpnVz(qPaR&<?2H'
    'lPV#iv$?KljTTW0O?I70u(sp`Iml<;q;v@lB^yd(X(37S5y=)jBQ%%CpHNy0NuTVxlt!!wz%UdkK<Dow*&+2hZ*yRijbU0$LY9;<J(K=StxKL0zQrV@RuCE%'
    'ypRUkm>WS)&yosi<=I)oUJt?XkGe!BWqVT<+mpN(9g0n_Hx#m0fa8jn55VLnb~xLEvRW*RO#+`EWy(q5KDXxBZG_@am+C4eK(-2w1}HI3;N_e>Z)g);AtmiX'
    'B<&8GoQ9%`$jJnL=Amn*W>zgAc@7e_ezH{_@nQ&IT`nev96%VenM^2lvRTOnw1$&pS%lqId4Y9=A)>b&nE@ox-Eb%_2i!YsbMPA-*2F~mKKG+bw6ouXY-p6^'
    '!1l&PtWUc>5RNo0HTp0XNkbD_V|DAe7Mif8PC5=lQYGQIsSZw$n%y-;p6=m>zoZUJDmxB=grjRCnP)Vvl7SjUulNEm(2lHo$YPgqC&it*@KSVE$&36lxpW5k'
    '+Gl%Icp};?(9!~0Noo&99MjN=M{rfCCUx}YaB0%2;&-aB-OW&)#u0(zUdF4i(K%8_=l`KEDcN}lSrso~DA<&qsPew}PlXd<KP4fCwAF~iUL@S+Gvty&jf4;s'
    'HbAWi)P%z6HMm=}>m&__%@`am21Hf7w;Aw5(dIZvy9l|E)Sen^RRxmX3UPR9M)Ejecj+K$5-2_(Pi1>YfU;F(<4-swenspKsPb%ZDWt?Dww6?RAaVs`hKdaZ'
    '!+jLLg;@~kD?m=-bKF>FY#H@OO`uJ3v*p4W#4f;K5Wqq~lL0L?ur0V1EFOS30lEY0W(+1PEsokbg3;@%n6<p`<i(V9i;gx?6VCrcq-X)TdoX)GCAz>824p%Y'
    'dqu%{bih71iXuR_P$N9h0wY)J907bhFQg<fgfq@&h%^j?=y=)c4ltOjS$7MJ<^ctAmuM3C<{j~pXy%(La(DBsT(#XIx`{?3QEBDVO`_URS5H(kM56La6!Vo7'
    'u&!vFhu_0+v7ng}jbze96*@leH55B0Wf^w>t~w$ca^HAeISpvr%C}1CN3awXd%lus<SW^9IbCTz66JIwnFF{cUh<`U>lJZVCf};0o4D2^aRyUMG{8c(ONj<i'
    'Yd31uW*TdAoSS7}Mg~k|4Th#swgzRlqza=;P6Erxb8DW49s`>E6!0Ewg}C!9wpB4?9CZ~0V1mJUtHeGnASEGiV_Na|v3`(}+$cz`&T?P-<7&<fJb|Y&kzv;o'
    'O^#>=6*c6cawmYn#fk_a3<*49Q1lld%kc+oI7!YA0^SnUp%9juG4u?U9a<ih5`;%hoLe2^`s<!BV~Yf4K^S_3Y)ORT48~d1DIa-Y5f+LFsA@rf4`KPM(L^xt'
    'q*_OYM#D>C4z%RtikxY)9uR<BvvIE85Y`l|dC-;t(6H)HO2I&r2}iqOvQvU9i+LDq1lYr%K98#ypp~Gu1z_U-(osjm-6)c2gP+i>w7e>@d=UdNe_Ns;;|Ax?'
    'aG0HE95>m~%tiEc3G4XQYZAsuq2&RK$A~FOGq45@6-qGE4SP1EkYd%Z-+`$U$lYq%;Nd9&Fcf4_=rCMHAkScw!~;3m(kLZ8l`3w)E|CZ#m!U`_sCP;5iAap0'
    'dVxfdWj912aW({08>c&m-h_5<>m+5rO=Zev@OaK~I3|pOzL(_>C=Lxw#wmrQ5D=3HPZAdRq6w{WP*{?j2gH@siiKrCnn)lfG$T)f;6{uTctbYQFDR^_0gf|P'
    'U}A7jNlqXwT;|Sz^ONIt&{xC0uR=UTVHNE2L{Uu=%V^U{iUT0!l~8P3dJN_8SqdYpkyUk0Luu5)IUuIu5Gh&?9Xoo8B|MZ4SU4a$P1SUoP*dPd;ZDFtpXekQ'
    'NPdNcmu%)M6xHng4bPu5ky2P4NOg)w)zUbs{CFKv9~~rnMl-Vmq{f-VigU43F{;X9RWMR>c)F5;8e6XpQq?L^tAU33-ZNZX6!`#R`5={;sH-{QZwRg3MTQR6'
    'TK=%xqg3;v4UVWReGcq0evN9}u@m}uj!H~vikS!m&^SO!U==cgnPCbr@ZIk}cN$L$hFc_6dXO0oNoUDfRmB6I2y=>K|3|6j&~9sa2!n+{kq6{v3&50NV2$}1'
    '8_9D~Sq9qNINV#p0ceN4l7dD73XBF2FrY6Zz|0?RErpL&IsrAuyakvM+RoTXMAq(FR`zmUdqkbfjZkh{g^vLH-T^F8kROWkJE(uOIcKSM2_g&llU5f=NQ9L0'
    '-b(!G9K0d<@f=nUsQKiaz5RUvfBq1^(HsEI7m4mas!kFYO;k>vmcJg=b;N`jHc+Z^Eg=bt>^ebFf;FU+d5~QUnw30hBxMzrQ(IT6I0iRDVM0<9v6T6p6fer9'
    '|5CDC0^UWXnT93as*XSLA#RyHQpKSJNflSTu49847<Geh9E5+<JCL0MnU+n8(jX#l3S?IS)&g^6XB%{60QlBCds*pu4ho$;3gLQ!V7R-xJ8iK(DtfmgA#so^'
    '?FsW5{!}{vF9jCsixXgkA}s<->;C({5`-0XvqFlIFez`B44?@*QvkWZ?+l`20SslwyIQKd2dZ>9Jl#!!9-;WVXW}=vek7irp8h-%cXKcg0X|bblzzg8d+=}Y'
    'tO8KGBDH!X-o=B|=yNy($f0<sGz&Z_yp<7JV;K2n5&IDEs1C*3p#cF`f*1~Q`TuZ;1j&vk*U)SH@Bf0a3m9{SnrVzI8GIy)FeBxtI^hCCIbgSd;UQaYX%YYx'
    'C=oKEFdSN*A?dKO#!dz#FcDaFG5?yJ{1SO!FhY5cC?N-Vz`zW8g7d0UDg$YN5yveD3^$|477Tj__P_uZNzlAH_m$7Wup1@k;YJKM2F6&e1bFw?OFLgmJxbJ)'
    'fGdY62pb@sutc0F4FR+919)~ra~1(U1>OkM2O_op9|2geFd@fM_)Hi@^2|Zq{)|6?fDPc05NU)d4{U+~pvCnFBWenZvQhmVF#TYf4U8qg%Fzuhv2CVHC3ys3'
    'SuR6LvjLbMD-AH(OlFigK<97H0|0AXvUvP1JHi^#3BU*20WuXZ%QaIF=>1?q9tLV~PxJL!8inV$)#Vrjv7`WC0am((BSbI=^CokslwEH9Lmua~kiY_!w^|P%'
    'HPq+;skOqhNBcuz9-x62__P)p^ETKCS_BbH_=@QGDPl#qM+oQ(fwe}N3i$hX*viLy1`G|P_XI0R%oEWFkP?As3<K5t!nm+5#%gX+AW9tb-~W|nXEb26DRhAe'
    'Ge8UHW##IHB@#meirvzHu~sNk?0j;&p8P;Gv)h4l;C2oCPwNBRqQK%DDTf+=BRM79{rSEALqv$v-3qYM;SR_n5hiNyejon)-b3*uiL>AP$HQ5W{YGD*{KBNT'
    '`R8uKLPi5S_kBZ7Q0)#J1DFt$Fc3MwVt1bq1RC_2sK8xirdDh5U?Dz$hOZ`z>C_$gc)D8xc?6_nH=Ry>B&*fhM=jB8wHxUVwATSpcu?=|*Bw|OAk^-V=={8z'
    '^%{9?)E%BQTm}I11SRe>!G6MeOdv|2q&`7#(leTckra-nDI~*BpGYcS!ImUB1}*nFKv)o!M`VhP5eW3)8h{AwBB{GVH+X&vjjD{9n4xvXUKipwfp9!M0fvJC'
    '0Kh{)Ye9z{1!9R*wUP$y#+1UD)S4E!3Dtxh?Jf&eo&Wt`D5o?SOgB(@4hB+DlDcLaGNkkrT14=xbh@eua5mp{bLm72E-ya+3O}`~<wUCrKQ&v8ME51#XuQI2'
    '<#ef9fgjS@Ec%`=72)6AYPAIa&ZHZyd@28yZrp)=&;)Bfs5M}G7SaZf^GrA$=dqp%m*YI%GvRe;$AqmN%D~S=zyWBPsN~Cu(jZxFwh-WKwc1RBAKj>Fvf2fo'
    'J?L{YmrmCZSXDm&9?TuEpr-R3WX?OK|DD99cPc2#GXM)PuQWGAM1Z9O9>;_K2SYo+?90^-`t5XAsWw_U(BBMxv^y;jA~4nDC+I;MK!)F)kAwq$@22s0J9+@d'
    '%QUK$)}Ya@4DzjX886%=_4U@u0#R+Y28m<~Ogvp9kca~ukZ3mHLtq;s9M9$toMrP)WBq9D9mvlA{a>kcCebbdpy^gCU&*4GVySX>HYY&y7Qdk+adW4#1ulM3'
    'RQSbnMe$xdS1Y)SpUz6|;s=$Qy7=X+X)b=y(-qn#Mnc@6WQQPQ1_i(XY(^H2;&&-C1Tt$dhAsv?VTbuz?!p0N2LgSh@a~WvugE<<xh!ZNBhUk2Y(q^CH;_l^'
    'K(lCi10=BEPv94{SkM-?|L6V?bBbA`L--SFN({hCn71SYXaa1B13W}NC4n&?focJ3Fo4|MT?T4Q6gCm0+&Vs(fdacU)RfSo#3nk?1eWJm{3YkTDe0(^@PvdO'
    'a&xByjLixt^d^rF;mAYcSOX*%fqs30c&ZVU3<B^N%H0V30LPPI-GT35BcWL+LqaPZF1H!?(isc?pf}LDfqIyWhVUOmRiG1;SxE$S$is>J;d)@DgEXAvJeymG'
    'HI?Rh7<=o$pV4O>#HCSGC`{>*nU!0TkHiQN2?!*oWE6vS8$jQdhvj1DhN{M+M_}dKh>>Rgq-q4H+y>m#tkS147#?`h5zJhwU!kf8eeTXH0^89z6AG8=dR~Z<'
    'pp|wN&{G}ga8p5<Yay&)YXRhMHH0=YZmFIR+~wqCLBeyJ<~1h(I>6m6PYU3RP9~ih7qv0Nvlov*l&paPiE<_k#loK~M3``0Pbot(@SFnn-Iyt)G#rKa^^0(6'
    'W(h$2cKm^hWJV3`aQ)yX3qF7jes=2qteO)v@&=@6M#kPF?4!?y`$yscFro3p!LXJ`<%{!=<!TZL9yVBiz_5=*9{9BTTg)rloazlE3|Nj^n^EFRL^Wr?x`P>S'
    'U@D?{Tr3U{El{$<v>Gej_JPcJ<Xwz$^%;y?&sga34Tk_QaL&yu8sa1n0~BN(Y*<<x;Lw6aBdy@VgXh<{!$I*wZVd<s+5qC=2NF#&Js+j@QXqonVCj&dp@KRA'
    'ohGms`r$XX{&O`VM8)iY{@xyN_+$^b3^Nd93iSK{pC9Ds7WI&k2!U;c?`9(J0l0;4Zi-8&sRl5?uA!O{<)r>-cbM_<zU?($`DC%J2SW|ws#7VEOso4qzd~9F'
    'xI3n3H-c{#B1$+33hX^3YE&JjxDQy3D<c!1lv4IPW<;c?i2vu>4TG(bu)*!H`(%M=UIP9NNBncuLGq(4P$pi;LtW{Iwge7cL7@kh-tmJ4_(6X_6NnO`u(Ub9'
    'V;HboAyJ?J(Ipmc1<4_61ucb;Ie<Z2ED)v$0*rtEj%2bL(czIwOJ@RTimHBE;z*+AZ;YfvI%(K$q6K`Z>tPWc3<_T8$OgwTX7#joz+vXW&cpt?<!Z0w5{(XW'
    'GxXP6qSnQ7ORx{nmP4XWxVw$L;tu|71{X}F_9kzSk;-SkSr&Oo@Dg7LPV*g#G!A6X4}X)LJj>q~`+B~*Opdn?!oZ@tQd89`=@CNq&~MQoSuK^)z`;`y?C)5h'
    '?^-N)@CkS!{6INdufsOLb5H*(lN^)R%&3t9@E@E#8+2%DcUH>DIYq8vdI85k1(sY3a}E_+z>wbom-Rt~Ed|11&HB06R%NzfeJqC;fsHVLCwd11uu+-mBcU<y'
    ')(F@mF`mxUtbpQgK$t*_P0uXE@wrFfCL=QZRvSKWlqc8#^hfP}<3W&Uz#oCeg)##DYQYlX^mzdR#=;l{gcDe8Dln?v(Fox}!tUJUFW{vxo4(yG$KW187c{pk'
    '#87xNLY$V*1aMwqa07cWfNi0(uzV!8r~(j(6-+t_<Rf;E)sQVuP^SoH%hecAq=G?ofuJCu8p=gyu$^Gv->5S!wZTQMNFZFmQwI>$E2=W6q&wbp2_}V1Zqo|~'
    '7A1;Fq`E;V4C@?>{0XU0Y#8zh!;y+Yk~k2eCxwn3PYwhL{(S)fndtK5)O~TZSw)kJj@X)vAZ9y5LT$l*`mGLmTy_Qap;Q_S7V2tXDNZH1<$r*c`Wx-UH74Bp'
    'yo~BzIFfZ^2~k5;XdBK~rNLEDRN-&Q@zcOiV&&4r&muw%MK`p5M$Dp?Pk;d>(L_)7Itoc)>fhjZwEbyh%qwJvzp3`Q8u9=UMFtNzNDuyIWmfNG9g9!eJ}lzb'
    '^O*k|Q70*lDr<?PbPJoJCmK?ERmz+Szi|T9{Pgr>`2##PR5+j{O$BmFiHBd(2F9A>NhT2npjge%#0fna(358*`JwJX*&;cotX$#-16iLcAiN5Q5<Jq#38>T_'
    'ak0K+aoMAUJlrGB3s117yOFkm5JE7wtH1!Wg}2fGl_|-6<n6;!3<2dJVAUp4jx%xvv+$UQab{RS7iRW(RICh__$uIQ#*lG_88osfp-_wL&8iZe2;f?&h!T`K'
    'NmbUA+OKh*P0Gv@=5yi|=1wijQh%ew@zP0u^AT)c%X5>yYB1BpDbGq4a{!Rdyu9dUn6t<H&cl^KDSR0JLQQW;VTlVOGCM%iiy>E|2}#^ygJ+btHq(%KRmfPb'
    'Bo2_JvMRh>9-XF7n>9S=YgQIoS4V1BEuy8>rL2|=uE@1+o6zKp<>2Ly=;u4saxewVJR-+S7}ACb8UU9+XrEpJl2cnazYIr0VRxMPr6+K+NQuDT_;w%ZKp)G>'
    '+4pzxpt=lJ{G$j$ES{uuGXJ)GQgI}LDDk6gN5a81Tn4QMH5E~O8h^HELJNYZc4g2cfFbTsz5tg%5Pt&-3nB`r-u=07`q5A)RfA^&CYJ6H4ey>M9~6J(G4e3m'
    '`Kg;GzC$-#u`}F4O5G@Z?j{>bGX|_@fkj5B`RC^aVyfvYwlJKHnoOFRp<k)>wWbm^A_0p}EJoCF;d&X+CXT50JXRZjG)v&XM25sh$`wn3%g_#Z_!~C*bDfA#'
    'p$e0*PZNq-!w;%X*AY@}OI6BFV<f2ehjy-5Nng$wh|ij4du&L2lL8RP!y)VgwTC3uq(n8)bx^%fYZ&kpHq$A+hsJ@Rig03L!a}2n&c;Q|jUZ}y8~4zURsCRT'
    '(1`=d+(K(|2?67CS_A3e_(NEMn+o)lQ)Mj5sqhQVL<MiE<OU9n+tGiQ>ngX`z<bu$)d-{C>p#Cm$jaw$5UW4>U{U=b<`eM`qND6t$Ts6eE=+1FM;Vdz_xsNc'
    'grH-OYqBAMpo0&Y;toB6ROOH#>6V({WC23^`F0Hno)&D4=4p#)+(GWQ>yO2vBM3AMBQ3Q|q;vBz$H)&6F_7u1vvnA}t5DL8W6qIn)h-6lCGt2fR07l^1X51K'
    'e?%hyNu(EJ(A*+<Wrs-K{EvbR7kMI_K!b;q&KVT*9lW>%-dHGVf+B#8z_ekl61<ZH>SB0};27QF0$E8di=pb#&)TVi2-q%++{~Qe23IbWq7NnYsZpG&^+z_3'
    'Y}1^dZ)pl83}NiZd^3_Gud`yGYXl6hZ<+trs>VNB5r)CwjD%WPT`q?_nhfsl4_5A~ubTdtGjCXeS_LTskc>=K9u|8gGGR4pQLPYFL_uj+t>%%kSt>cNN&LyF'
    'ap>5qYCrTO4o2hLNCN$cR?ngjQe8E28>Xt21}L1MR{86Xa;`x6qeLmr)hD;d#YsQe%7Jv1M~4feGLHV}4u7sKl-Edkg7RkH5eQYOp07cb908^OMQg}N5Km+Z'
    'eru&cQ_$@jOsJ6vA6(7@tDtiW6pH%%D^+h&P-%0qZrbT-*6>l8&5hMmtsK59?aH&ciH_3sKY-39=>YBJmil;W>Y8qoOx^4P&A)THszB=Y2<Jxs7{0pB>h=Jt'
    'R>}ysSXYLus?)j+_}u6Ma|QZOCZSvTb$d{~=GW8G9TB(El%ZZe`u&WNQdNZg`J?Mw;GXB7q>_p>`U}4LL&xk=dFsEf+;n8UId#VZn&QH0LY<%0#|i#TKU$?I'
    'u=S*oh8I2!DV->TeiHGEP>wFhr!D?Rz-Jav@JW4=f!(0@DFF8eg+$L#FOM`l!PM;&pr*)^(us(jeAEnAg(&yyNTnkrd)SeOkSbq5<Eu=8AQFfLygZAZKxrZX'
    'BOJ~X-zJal0;DIjbg=-Qwbs>AVr7bP4Q)k8mvaQ&0=*U$yJ3{2+?50r33D7DzfM@8=TAUl0hizWTP_W~to)M3S1__8R8U`w#iE8MGd3O%vO4<o`&sV$N1vnA'
    'he-ZCj#8Tm*DQ5yENFQw4=-F-9a0%s0cY_ucx{}N8YWSt`y)Ew!g4#LeBL+IhElGLX3>p57Y3SgVINGXhfrJGOFlBh;X4aq01;W?N{tfi03Oi{qc#cgX&rRi'
    'Bnnc%yEmaXEe)q|EeY?|<kt9P9=<FJp3KA#Y1LLh*uXAx8o@&xizopDaHvcH#^-5xoy~^d(pw5_l!VlRmacNblTlA!GYzmo(Rm#;rc$<@Bv$AS7XfeE6_^x>'
    '+!c6O(mo+ok#PwZl9i6IhSYa+!Xs?(&=CN;1QHRVi06ufNNc?Nq@zhHD__9JKk?=F(!qSV#Hw>ih_fd2>>?zBY9wGPOTFKuEEe8y(yoHJtRHVoDF!FG6LLiE'
    '&p!%lv3n6Y(o*~hMIf+8g1`JI)P;I!A`R+DFfw)&3V;EBFny)ft+^}dT1ooQtQq2ohOy|1LCa;t2K)pN(zg0d|G6>+{$8u8V-djHHfVN3=?!VVRULU5xI&dv'
    '=h{nzs;U6<%7l=mI-&xY%0&w-Od>Mh;K0eX>4TdoG7De{gF*&WfT%N58QPj#n`up@wBFd-k~yj73mpNxRrB>tHQXH(vv(IB4u|R|^$I@`{a`kgwn$&pRiNmB'
    'x+GD<zX<4=lL2v2N$nIcA>JY9-!R6Sws=!uCcmOLDOIE4l22TdgzKS{a-<u@Nz#Ty^!sLI1WJ_3y5RzWZS;iSXlKT}4DA`66~p}W8`V}_Yzm6eunDBI&hP`}'
    '^kziir0Z5Nc7j^Tkw>W%OrfEEee2&i@cgS$Rt8Aj;q!r5DLms-kFq|v1`b#4#+YbAXhetQW=!>BWesx8toor8GWu?Q=kb2BZs)bbbiIik92tTAX4t=PZo~`n'
    '9{z?KzF{Y2mmsI-+EA1<1^gX1RrArcHHq6epD)eGixZsxeuD2JNb^_cqzQ+Wuf-(DsVLtNC7n%1R-BymhL-@TjulH43c#IF%V1pT3}0x%q4z+*+UZ}YlGzMz'
    'PnRq4Sc;TR?n4a72`~#cYkV~@K8mF0?Oe_edQ*y>qow7AwF984g0sIbPCflmSDJAPDKUe^F=&VrpfD`_ZF)vsAa(95W#6B#!)t0G2>Yqyn4E|z>0q4;YKqR!'
    '05F#SZ3FH<V8lrK_@cc2%Baz(w;!7;c+bk)Q~R6hl!7ekZYw!<D_dGv{a(#MTe+{~op6=3T)`+;P_t-7b!Gu`{J;|iWP}ZV<Mw|ZHHjzq(1o*Q>Ji)+d#9d6'
    'RRbgJ5jf0sBg{p5zaj~F<8Xt96Huad4$sHY@F3Ur20Ndv`z0k!S3N-pz+zD*4L745V`sUosSvCv;rLD!Kq}zl1`)ia<is1=tTqJWn{*(ek1e9pOidts4C8wS'
    'kW}X7SqL56HD@?<)=Zy*e`AsF56=IsRPLuM^Y>NxH&*1vYRCu104)6&%=wm$U#j~sREZDbC)zWPZkr#kC~?kBR0{Q*G>Q^G*A2-ukOGvez0VpIX0Zh+kV49D'
    'qa+zv8h(H`nE{qkT?C@lV$cazM#XYmNtjrmEeAj87I&!WDc2%Nd6`RyO3DT0PgGn00~1i+{LyL)6!^t=yPegGwh-U~CEP=D4AB=I>5JMZZ`{361AzLT>j0Fw'
    'AtZ1|7zJ=xZm=x2QYJbZ4tItH0gq>}zh#hrbT)_FLryR&5WtR-#?eLK5;PRpH`^PD1aYKz&VDYAL4<-{gCND>WV?)nmo%WuWdJ&0ah|l`P@GA!-Y*wHC-x7U'
    '%Ny|KW|>S-=0w>e%GE<i!bmxSNBAnc85M!2E7Y4tDOr~oNo5|LOV)p1B)Ji&=j$37g)4E-XI)|TS0<Ae1wKZ#eEOp6_R`z*HM8zXGgWB?MjCPUnQr=3TdE_s'
    'XClh$`Ww$heFv1~##uLYm7tRN)Qd#xr>j({My(vwyS?Zc$5)Y<dmubeayj5Z9YVxcytBaW#aGjfC~-$o(nWNNrr2?~{L6B_5eM<Pa(@*}q@s&`P$8Le*%FL='
    'KVlmm-zBXIB;y+)MPL^b=vdRQ^PweTM=25-UiSDXz2*wbNjU22JceqQHJ3D4h6y3Pz6VwdO0*(H`~q=Yb5D%84Lc!uT6)Jgjb5J$F_**d8vg`cf=!>5h7<x<'
    'l+1<abE7N;M_J`isoJeT7e%Zop5~xnbQ4x7^QgJsL0g6hfkg@Jg&qKP`1s)xqPjv9E<Swl7oGKkpfN7dlH<l;;6E~6e~T8wwl@RCa=os$kXWgH!=wH{<^3zw'
    'Y~NJuNoe6xHfU+#?^x~0D$n+9b(_pRU}k7QWlp!%_>X2mI4=k#A3(k_9n}$K)s;W$3wzMr@2UwZ)?`>>CAq&er62o}THg%GG|d2y3Z0Qfs}q(60AwVve~S)5'
    'U0^BY$hDWC{P{7Kk~=L`^?ajYuTt@{qD3k~&t)3{dM$6%{YX~4p7$tA`rl_;@sDEk>-~7?1ZW__`RVj|zBQ&|@uJc8+WP8qk<5QUb>)E8dWQH7hnf-{SZj=5'
    'JEx?Uv3QYh*Ary<4PPQ51BACC{eo8_{W{-=^b1{vbXFeNs{q;&UP43Rn}yL!l~B&sjDv3~xrmTJH!~i<{1N4()I8!ci&jy|H`+?5;l!?NNNST~SdkDfP%+`+'
    '0lD+_Sq7-l1(*SaXrfs51gLM}-%~@<A&=|&sGsVcC@#K6cNwB*7b!FFTrK+lqJjReNlOG&LGEXo1>KtQkJZb?&0Rka!ATJe?kawv66G?z{x=09;Kl*s)yUO('
    'z&%oSh@kt6>Q%{dxF+v~Z=oNQg2ddbh`GO}_g>{MSpKQPxz^Z^$~<rDpZ^c*5{Xfs05WDBiv7P+)o24ynmbbet?UiHqfNTK8C}0Asj-U^M-pD-5B$3ur)T6#'
    'SOF6VqEu%Cwk3Q&H@}rmO(K&TpP~7!0;tNm+`6+B9{e0{V5ngrH&J7Jb@Jw~raK-0G;%yS)MxCd$pF2W93l@tAtU_p;zS>4#8T*`F|ZX&Nw&JS89pFAIt=hB'
    'YV}X*v(ZRWDG#)AS#{<{A{X4o=p6uxdvTQsA!UCAdn1223Uksq>a&5v{w9Bt+|kSH=!ZSfedaep8TxWV$*yd46Xqm8L%*HxlG)t6lITJf0(s|@<lROc;YI*l'
    'a(G)mdb7Sv&O<!l8&;M3J#S1>=B?kL13I}UeMck&&yeh}UzV3%F`e8UPC|L8hVe+)HA7kS^7*%~X}MIo2#(|<!Exnhc;(NRvD`*o*(7Q(5Pju`OITnES401G'
    '8alV@=+8yv=3P(d;+mZw&FTW6&eSfTYUZcz{g+9ql0t~<bT9hTowUR>nz^2N?q;~~JV_PTY3Fw4I?Z4fo#-gC(SBfEsw4*YuSpC}zr^NjL&`gz`xit8rxqF9'
    'k3~i<-?+(~SVfpc!j2WK1zuiwE*!WS1ylb~>zm);KU7exdWHxO{+4VM=l87k(taJlYkhBFOrf&xh)R{+-YL?FVcZ2r##A>3TfWJ)N?O_$AygfHBS3$?s}YiM'
    'x-Qq(n<o_AcW0C3C&K)U*tw}>B3f^6Cq*vH#-v6E+%h0<p)JL>w3y!rXZ>{=HytMHU!;S2IvVlvPp5;^*xK2sF1P;c3{-9Zz7qc$>iDf|@I6luInCzMFHxA%'
    'JUYpVsH?tJ2TUF9c^Jo&&)i<h%jJ#hWUr@=?xw|K*@)$JvIVzPnX8)cmFE1EUIgp*5rBk<uVTTkVvth`2VlqJK)c_Crf323b4kHkc;Ft8!W^dL=M=t(SQD-~'
    'zsdjuls$SSwSpp5V|W*faBik~1%w%qSyh?<x=xgPPH`oe@TlZsP+`6>=Xenw^MNWALC4`IEU|F%T#e?21>Hqe4IRS!5pcw8PJu;0`v@<7Na_w>-H6k^FoF*Q'
    'h8l=yE}Mg()byj<s%ZJxf_yUIAiqrYXK^k}#E5j7PIVWzHj#pxg|#^n{Lt|CJjoSvDTg<8Jj*MFdX&R(sIleWNz77v;F91P1KqrdZc_G#ITD@iCl9COL*xhl'
    'Bq4%!gCrl&n*XCT#yL?0$Iy&_j_%;=w$#^RTwjRsT?ESh69~!zUVy^89fzN^rHxnl4ybBwX(5$_P_}AB7Jzm%ind@yX%+rE1CQa`k>OoHf=;2y-&O$a^vDko'
    'moUQ}{@p0#S^Ovm-n3S^qQUHPxuJB!847n@o|u5=c;!i4Ef8T>4QD5Gx$L@@AA!`be>u}zspGaI0>})7IzLL;1dHB6Jqcia&FaMBWP*rsQJ8?v=IMb&Z&6dg'
    'UCV@T8R$mj@f>KCMzWjjaL+5SkX3&*t8<OjKMjxS83kv=ao`hdDm0=_{6r$zRV@hm;reVWx^L<?cPUSANzltOS*XZvL%5kuu>AS!0bz`rO&UT!T&jB6)4y5l'
    't~v|;&upc0(fAp}v-<r~_@wN_&Q0MNK4QWH<9NLh;B9i)$il}0Rcj@`o(I-iajL?0NJY?N%5dmy025%7@Z16HYa$Ky?n*ufj2px9d$l1V6?8xw4q5;<uupg%'
    'zOcy#UoW}^uzrm>h5_;bNP{U5IKPy;a(|%{lTa5xQ^u~jyNto-fgW+f2A#!*cbCfL@bKaVz<83iwC1TPylxLB{3JsSA7^H{tLh7NM(`2Ni`Cj;KQoo&qka#%'
    'btljc(tQq`-oI*>wQPaitpEStsj8RP?K)G%YA>pk3(|3ro|UVvb;|$oVj!5fU<!S7{6{PKzdP-BRnKp^j(zKw>C3Mi_<5oa)%9P+k*;qH|K?8nXWbflOu>tL'
    'puW9N+;Y24T<5my?=IQDJVU5|&GldKcIu;pq7NvXtPVch-N^A`=D7_`uLvFo>rnVp$|wJz_Wj0K|J=Wj1PwNU6|;4KWF1cbIR1gxaVxrcGl%+*9TW||msMM;'
    'i|Bsns+<=`Ii0DFLOp7tIF^5aA0psiu0=zlQ++_`Y^&;ssVU9Kw*Vp0r{jEJ*MpVhpeTiOw8W8OIu>=63Wbd(6+UVOsq7NFitV%$wV$!G6J~t&!D+cj7o$;r'
    ';JN?>$MH0>JE28PP0X^Nf?lN*k*-#y#b?6&jTfi*a86XS{<jw*-tZHzeIQI^T5~*8?NrI=KkNG=5<}c}ORiX1IbCwgGRLHqe1U(tw$Ax~q4wb)9H!UobLAY&'
    'P2%VUWF?l<E0*|{AyuxBp4qK_8S1}mcHb)e|Nhb>t?`|NZIxG!l3+pJH}J*ar2P8S4e&&H9KeKUFGQ)_OwtnQM8lK%y1X>WGc@R-5`proUD0hD@MX0mjN8GY'
    'I#QU!*Wkj~B}2`g;LF)*9<)(kQ=*)$fJN4<8lRB*4jl@<3?AN-4`#dp*u&7rFWIJ4m4Ty^KyU`=MWixn_^Olf92#d*c{n`0f!;R^C4lM_hw!8!pvu*jcIVCe'
    ')ovZx`A5ff{`I)roZLdekI>ZUx9g^?Bo)po=Mi<k)fCGkR_~GkIGUnk5ejyKy>6#I|Dv3ezzDK`u9U6rse8>4nj0C%Gv)pRdir{P*R=gx-S_uLd$dAB^{V54'
    '(^psBe)jXq+?#Iu8QQZXG)B~cV<(sIUE!(oeeUwL!I~S1v<F3ygHD27j^u+>b&CT2I8p^oUNgK*pF9w*pn5Q%S+0vk;f=JalYi32mj<ys5jn{>#>p3Sf(0ci'
    'v~KcWjv)MB*v3CRZE$8c)jQu%HXRAHpQX{|WcEJ{{z{TYzpV0XpL`!FML_;hJ*BYW*UUzc<&2a{golHJIF~4ipPz;8ojRdNX#ijfqJ_F?2}N}+Aw<m^hruM!'
    '+O!R9jsm(Wla+hEHYk;4w-OgCt|MQ}w|Nxu4H{Kn{^-6F{a+D3y7wSz1<~bgh&PY1X<n=T46o&a;$;dSAz(lp;HVvbZMy|udNQW8hu9?jE?WaIqDHDJ^Y!2H'
    'etjGmUmC5cfd5-5`}G3-);TArI{yz%ap{HwytyQA?0ertvf*XUz1+a?^2oD1xVS;`KmU#v=^APL3Qm{;ACU09=Vslva$LWL<B_mh<=0cFUd#Eiq0xbD>0K+s'
    'AqIN;E^W(j2rO|9rQgx<3w&S#U5PE{K1hHp&A=AGLZ&Aax?m69Tzzo`Hq>e4PJJsKKA3p!4`53RuUy*#hSY*Vw^EuB|KV#G*Ek!2)gC7ZH1LmAMZMC?ZUEOv'
    '@42}k;rX2=7j)FT8{ltry1H}x`etYOLUoJ<yaMw(y8rm<Q5l}*_R-7Nf#}^ndW|72qxi|y<SI@3uUt`nQEV+wL3;lSgd#t>ex(OG<u6^GjBe|;{G*t|`5N$x'
    'QI%NGjf*67-(2zh?NR9;yrAL-3ykOtQ2oj3$uHIW$yN7y?hn4!6!pe0#rw&+{?U6enBLU^h$tsHJMpZfCY1iqgwEZl=%+vD*T8{Be?I>)1%Lb|5VX^u&Qe2p'
    'S(XY4YJ;Udy;=kF14t)<@_Cf63jtmpEPXjL^a!elbg$-e2MLzMug#Lr-aQkq8)37gh#YwU9yv{z4|DPmZ~}+2Ip@|y1HbOb5p=qrAegx*u7&4czjnLb(-O(?'
    'r!lwsHRdMNFWmDNI;)Mvn;rIp-4b&cQGB6*d?BhwXsmPqGB8_4?|;cA0uY9C_<BjZbZaQZ0<h3PfN~m|lsrt|q4#?Y8cs)GkV>=?5jfi?h9f6}8O{~Z7rq_='
    'o>ehpx;%{nUiffAng3^O=jl&-x@20L7hZSy;0<RSRJb?kmm@FhhRxtJhr;)t3v)14F1s>ZbI>~4>&qS`^uGqp!^~b^qy?_F>pAANu+#DN$|OHs^(dQ|zGd4%'
    '>mi;M?TO<dx%{%*9@ekLmB+Ohn8GFR@epizKJu=9#M<83eeu`NRqHflD7W2{VRpxT^l0q23$c&WAQtjGObedKNBM)?o`(C#Cf@OjM}zUiQ>S%i*qy%20$aN$'
    'Nxm=3FSWv8p8qgr0`*bhGz+=2;qq|3h&jeRe}ry5n5mCpDiY4KOWxF}zZPuWLoIu%w^z2%r=RJ!L(}S^ZOz8Hn30JT2cdQ`^w!Nh81D1D)%<1_W=z)o{*^h|'
    '4&HIU8+(6<8}1t&+osa_h!3~^Qva<`jcyiQZ-JUjXQ#F&S2d-4@vp$iyQJ9ZOE+Ada|y0GOgO~pus(1OJRcvC4{MyyZ0LC-N5?*P-MR^^Y9nME?}}Xg6quaq'
    'iC#SJO-}AlbdC<M)~DoZ@c!m$=G{SVe5ww6?c%f)cdsUe;C^uU@J{=UOwmq7UT59VfZSROn_M@`MMH(du^%*U#y(?zHFSOmhRwVcubsGsw|gI}?%$5flG7KN'
    'Wiv)$_?BHp#oqjLwf1+n15f>Pmz`DYR&v=L7y|aPuYWoeK6``0AZk4xJd;@Mz1z*MTWjIV{#6?RQqDq4Htnv}vqA61Q2VNNL&F>|wricZcWR;OEMxH{w=r&1'
    'Xh%2o7usL2tx4l)EkwjjHanSCjj3)X-FzK|%p=3N8vNvgAN%}r5P5eU2VGCu)e<{pPnxo^*{JXm&#w#dPtNwjrbl$izqVOc#Z2k67uJc-`iWX_j<@hZScaC>'
    '<NYA_F@68=*R%a`lny!uy98iN#`)?ue0-WyALX$B&2Ef`*YUA&915Ct%Y$<i6KwGs$s30S_sZ5ub%Sql|3@KyZ+h(~W5a3jv-NI1)*tGk?O6GENTiu@fO%;5'
    '$Ks$Ox^k^$Db(#p=+ak{{_K2Bf_pQ6pLzFXBjLD_PiCiMw|6cScJ5wyP4*rV(M{L0Eb{5?yyBbz&U<hTeS>Tz9qtEOVKW=6g?JCSX&+|Is58p=+O_-Cy=C%N'
    'jUT9GVR7h)nb-TsBxEhNosCi~To3zCzPGpRA+$YsXZOpZt>f>FB1S4@?}hD!`SQcra~M25;n=lpr^0+0%y@F<PV%L?7}a0W;>nRRxCVRP(C1qbe>BsmJ!C|m'
    'BjgCQO07w+Rn4bZQ{z?0R>rY`y;rP>b{B88F6|o|TmRVRij<B1Vrt1zFFvfAABIUfby$$uM(1nb%kueC-r_0@D0geIFlM)J-J194aMH}U`udSBZ5Doa=+)4w'
    'rK?;^d<gFwne<Yu#2IUG((~lScyqUFObxVYkc^L#)6Ba)({Blur8C#?J7ccFdy~npT8VBc;0#7gT#_4qv>K+m&EP$nj)Ax6ILzgXh4@!(TCU{l-cHK4w>ACK'
    'rg$F+B$j?Lv`@`LLqoXFkil-MmER<%_b>7FaQL>3z4msV^he54G&nkm=DXh?UF25f<i1v*SBKcjlG|_0_SXet-y05{SE_q_aF0v%I1^qU2gfdd8ZhPL))8J7'
    'J&t0aGgx|q7MnFtZWp#zA6L%g9~SHO%w>NOeASe23?`!QD=}XkHfu-oCT8q@6}CZUzFpQcZO<k-S(|3TLE|A|@0i1av0Y3WdtW1W@nMmrdx<(}&RY&tKeO<C'
    'e7H+2^YUO#GwteLh%u(g$C&2R%jTl(ibgV#Mx$BszVY{;-O1sz$5+Jh`f$H+PjX_76*GZVV?7BuUq_DVgFlk4`cJO%)DSfF4P%3=nC&I(6|0#fjh3M0BhYAv'
    'GEK*zZ}s_o=IrDl<7M0{%X-m1#$vpqP5JC$8y7yL`wyAbB%kzc;;H$2Xu4h0-jXYOGUQn%C#lc0bGU!7>^>agy~94R)(s!y;mF=FCCe7)tYLO|=E;zubO@h}'
    '!l2>~xZ=S`##MMZS<NMW`7-o|3zazA9e#*QllZpGc7@WG%w)*sFc<(^;N*MY%q8>3-0Ke3j4!kM&0C1Ex$9zUGj?XX@y$cX<o#M?%HdJI87GB!V&ogP*Tr4M'
    'v+!q1+4;k0XehrlLa(&-U`bJ=<G^`FftY)goV*yy3(@ZX43rsX>Z=)YXQn03d-Z;t3ftQDqtk!%nAmEkGwJn%ixz2TTKBGweZQ+VQ&e;o<znwC?quqGd{W#f'
    '*Ng=tlb7D%P>v+MlU-px2)Rb$hK^gq4~uDRwD2AcZ<X#i7zjoaT*t-M=I^I$p)si~N0t`5_a~O?+&<Uoe;mTpebBwjmHV~vd-z=tJhMdov%<z4jn=ruM)T9j'
    'GGg3pfqKtO9+sc(FLVEu^%m)7Ba?sGSe;Yul;~vF%W#A)hHBeBn@q=@hJZ-hD&im>Jtg|N&)mSnyXIS_nfRpND(``#G22)sjH$+A&>_i0+hOC$R;py#m<m0M'
    'VeILM(Y&)}cSnkcukdh8S<T*uopmFGOmD6Ja*-c*_6N^!78e)I*XDBhVqPp5F6erTWF!5!|G|9V`FnP6Sxye)ui5s#bRYS0uE^5BvHcqE^IV?vO<nPIjqZCs'
    'jjIG-t$DVV*gnn1*Y#%D?y0Tr1FxHAyw&U_4PVySXuGWkHlkNBcx_Hwx{!Ngj1i-|FD6W1>y<TKjC5Dg#>s8WE!w9F9Z7te?D5s%%OXsDJGbw(T!|YqwqiW`'
    'u@6V;<x$fxI4$nqay9DZEtcs9jG?_LSTVfvZ_`7G@zxk)dSo%|QsJ7-md;wlxNT_kzh)f9Rw`UL<?Rz+a$0x^*Q(=ItvpG03fnrne+?{_vjy09BWEJQ8hvqR'
    ')IXS2*HfWB5a**vbN&|TPu!!|s^cSCNIIhH9Jk1miRj#J*>Y?<eHg9h=6lAP+|7EM$(r&Dc6ZvDh_y|<`F!G!*!uB}EpZ=;l+xZUxt+Jg<4Z@#mOb;1g>49<'
    'hpG6rcHU3z<>Q<8eP>=4Ox<LEx)x6_-I4v2DTLfiC!XyEy#BXZ!L`Y!g2~XjTMkv-ubpD8GWz7}Zez+IT0_}!{nQ)O%v-mo;k9#{w~^P~eocFfRHoP|c(_G0'
    'TyFc4FCoWb^SSVI?c*$*jyBTok^Quhjg@Ni>}mQE`)Gt~j?b097>N(5V>sCh71Cp$ua!vkgk2{S-EGSo*PNcQ{&>I?w&o3v<1Fv^d|>k9K}3wE>#v#5weU%X'
    'eS(>syq&7Cx1QbOaUGju)9K5`02}sIOef=XBHu4Jy@}z+s?{)_wq?d^ScYbFZjmq#*4YQkmm!v_j~!9t++%h(<MVnsl`sx6^=2*LGt`zV*J|%E&zqciI~VJN'
    '57#8xE@bwJUa|SwN{>&*Ucb7?wbGSQe_>9tlUlXc=7yX55o7YlW<HliZ1MM@-Wz!eFe@gWNLW*E=FO<%NUyh<y3jR!Mkj2%wAg0Ik7bMrS`#m=Rk64U)rQN0'
    'i?^}y=zT94KQ8%kmHi48OO4vn<BSaby}W2}^~cFh)Z<`RrhVVEx}SKMW}BZ1xy{S6S6&n>2_}^ljJwaBkF6CJc{W>pv-b1b{@hRcOQI*}aXuIZ5%U*4O@s$;'
    'Z$@Wi=ik@goW_EUvh+TS>}K<^c*xv~z)0w<B7y26$VRET!5GMmJY&0<vze=l*GAcM>_$7YH^a%1Fgj+*c`WhK*sYw|G8=eVSx2@=<bJo{>kn_{(wpP;*dlEc'
    'a+6&7tfRrP;pL6_!tNn9{(Q3@f*-A1u6o$HJkwLzGIcYimd%x{o&xcT0jy1xIhq}rrTgK<^=`i3CU%yvq4>p_*Ir*v*tVF!`#4N}PN={##Z}Ekcc_)Lu4%FR'
    'nXvhN!!pp+h5W#mh%MKa-n2`1qZ^N{{911BdbzR4_l3}*zl-+j&hFbJXbPlkCgU;JTI`v9hVItpF7m@@islThhom!e%-G{q`{!t2iU$pG0~K1hxVI!-?!D(L'
    'o<q+-f91#Tg41+z*hrJF9GhodtK$6CR5bP7@98%m8GUdV`Ha^X{Im=rbHCR=biU^e)f6q{%xwJBc};DnbU+v+O4iqiuoW#|IVx?Alvx+YO`F5j$JTzxvSd0I'
    'Gm@llWO#`=Kiv-tHg}9QYc7FJ@1s?x-4HaMf|Wp|8;+DsT&^{KbFlVy_c*az1GQtn{TX{dt@FX9JvN^oQiW>lleD~MKldxwy}kZmN$xg<V!|bcXU_d%2~?2#'
    '%hCUAxVwDJ-hZ%INke|?Sa`mMiPHyHh_?dP8u>NjjQ8PSD>|aGN8m(JFU$6El1;kIJzpX{95VgFDl(cd^+G?;wKRkMl6zKRqI|;CbCyIf`=G`87M}WRrL+}{'
    'a&I?I{p)(s@n%i!P2&A@Wu@*5B<l%f2M;3$pBZgKuEf0EZ3hQrndD}P=4yUua&~5BAuGmxaXJ}sBcDMGHq5h`k=^Hel}UBxu-cCG%6$3uW`1i^Z?U*>bSSo0'
    'lcUpBk0-r+$^E)*hZuKp&%Q3)?ztztsF+R}`zT%+eN=|4de_vc(&=8?{7D~^u6rgv=2C%xb?0&H6ZNUT=dF7_ydG!S8+|Cby77vmz7N#BFDAN2KP>Wg^P)mF'
    'y02SHQefiiO)S{v217A2&sDY-D)l+E4DJWLTC;0?>9$^yrRM%%ZZA)>hqnjwG*t7}dS)S+@G;|ZFC3mf*vY=F#$~zefPU#&=iB%+{c$Y#c-GRn@0;#R(d|bn'
    'xo}ork42LoI2j)q<8m|Y)Dz{EpAC|x=G)en_;5LP{%Rr+tSkeW(P!0Y$OJ+@N7do@0EX6SFdHVkm4|TGkT1{dr@{XI<f^jC@xb76`OKez(nF6gBtE%X?JZjf'
    '^h&e-{q`;LmFiTu&(A!$Ht+KT7sW)obGB_O%}7%v!+0W=J-vL`=bLpy;N4q`w7vU~{oQy94~rR}r{C#BR+-@XB^IMMFaDvuwp_0!AB)@rcmE<L8|mH$6&)2m'
    '((nCd+`e&jzt~0pK2%&azjn-n-?NJsKUd4eD^U3^CzWqB*R95!z4wyFz~s#_&a6_Nue$Y~87}?tBHMV0oMQcjYgmn#2MvCaHMw3Z33e9lH)i?HCLeV49phsm'
    '6b+ohwQb}fF^H_3CQsNI;_HS+r)-E@?UcA}bET|f<+i;RE1T{IT_wkZdTLZ-N~R&heYTi>q_ZAnYA=;sq*!b8ZC?*oKiE)yw)j?|eY;ny#pg22JTn{3hK~Ho'
    'X14{pREbJ?jS;@<$#C3?FC8jul6<h5*E?%#J`+>B4)EO=^KzW&&gisr5X+w!*SNc{3uQx*qS)~Kr3);mSypJ=w>~r7)7X>ZtafrgNHC?uejE0O`OKiPIt-G)'
    'pg4&8b^91<QR29fbQ&@ak@<KS7%cwm{+;`Ht!*kz*UH1zQ}4!zII~U0ll77}2fxe~>p^%CecSB5<VZh^sQjqJrTBGkF51Yd7>haWrkpEaH${R~u3G3!26<C('
    'nFRJ~@xzf>l*3KuVO`0QjY_o`DhD~Q-@F`E%#-ZBt8Mg)f$}Q$<qUCg|9v{%qP#0Qm^W-UZo61^?#i9aKv+a$Y;8R>OopAw=X_Of?Kj!e{infVTGn^o%Imv{'
    'e`i`wU&Za_9n0X0iw?gWt<h3$Sa!eW{ME?&d$mW`?77dn)6&0RnY!C_$uWugQ}3lr>u3ntzpQqC&E`d5MYp*c&Aqevc_Tb%IPCms6yf;FxE%h>yqQX_6uq}M'
    '^4)o{5wwSk7CXCWHVZLl-Xt!UlZm$y&l{bl;JeXgpcaYj>-rR>jK+6+JCl2J1-zWF9QF;ap0#N5CPKTU*byd;b#^#+wSs|ZmmEjuUz6b`Fl<j<sd;divn5aL'
    'LwA}mq&K@tp}*?A+<#00m6l}|Xt1lTrxQCBc4dl6tc`a1lsR&}oq3qbr!3<{iq5@FKdO#*YiI0AHEeW`oE2Y9ZU@(z3^JKn-jydy%SbKfa2Zn$ezZMx94&Y5'
    'KJ+%3`S|zXE^Ko&$s^^pczjJ?VJ{{QuFfth__GEtpQx>0Z8OTW$=4j)*rN9pwHm^`Mrzn?0z=wTh+C%J2VczG7`#ke6Cc9_zP=t9*Wpkpg}2=2>pWgy$OljI'
    'lrm*Yqu0Y&Or?#p``qiY;rGnj8NOfQ#+GC(ll?T24_<pE7)$%#&EaCL({WXeZpZ4_Jq)KOAXFNOh2a5g|D3rp3l2Nw_~|X2bjDi`Z@x*MoaKC^kxW0Bw?TGB'
    'y^LD6a(~!q2V!YAnU9*h^w{WkcMOhQCwT0C0Ey8yh~-(^SGV!ARk*bjL(@Ee>abMBRQ)^!93@kj1iLi%<=_hw(NAycuZH47fb{I{8-Tb>B*%UB0^6OFwmcZ^'
    '&G^<>CC#Q+C!5+f!Y*go%?^&QRd>5t^KI+9btFBnMrYo4dnTQ64kxc6%X@j8uu<<q)z%+19bc_C);thQwv(qZaEiNTtuWl0)3&}n6uIy9R;|NeaoW}snf$)H'
    'ZCYaOiQCup7WQM;xRQ2PmgRznEJqpJvRVoq>PK_l*_-o*y2V<ayxZ%ifGs;68*K5CI3BhAiEwdWTDniRms230ihmlGxk2ZxK!)>XN2=YiFJ~31VU5=4ddSoB'
    'zgkaBd=N{#nQBI7BE%LJm4%74Q|)7SfBKq_r`7I+6jtVu)9oF$W4tB4<y%ST*Ekf;)&jwI>irPdxEGmjv9un%ZQTW~yXl&((?G_y-!inVXgY=>p13gl810Y8'
    'uf}1%JWV!Jo6zd_*9mHv_LqvbjF<0@bBSrN^vb=t>u>M={g?BzJn|2X<#xDSH8HvU#uYho6=!L)2mjEWfuCAW<HO~2P5SL7^MsGj;wdq^wtDj+7PvwO<Hl-V'
    'EgY?VKD?%?)>pQ<|Jv0XkzCv9@<oryeDggU<X@)4j$!R9#&gkJBl=!BkXwH)UYMl}jeRlL?OD91`+e^IR5v{|7@Ot6O4`E7#{1TJ3Rp|Qw}!=Ejb~EjN{-1`'
    ';(^S(Ye{+cYilhsIh2~EZe}|@t-n^0U29PenOFUtJ8T19`Z)jPNvCs*@%vG{kGzk)4QGR#h3k{NIb|wZde!1rKWl%T^WOKM0a&3Grf)g4-@GsUAZ2weDJHSD'
    '+v(zayjL;W8<Z>anMqaOUxdD;Ieo1kCizUxTfH|`Otr<{_u9zYqOtUS=fh|pzkS3f+x^R)Hy%2lv^cMY>0-*)8e0#c7iZk`@#%_86PcPf&>hhAShD*1*$p{s'
    '{SSj}R}fZ*h3k;&u%mFv{6J^!n*s7I$B)0(bNAB1=3gD{b@g;g_c8<j@xkxx?zWsTI3@GB&SxoheD!TbzrAWGk0O@0<G5)baqD=l*rnP|s>cR=o>ptoti_MM'
    '({dE*Jgg4e6*FjMhKJ~=;&D5hZy{HPz0de<^hZVL3Z_;6uwoD4FUOa-<p<4TFTvdlF;_e$uKVuUgKb`TeX#Nk3njcWEVY}v8WHE%^<px99ABrgPx>X%c#V7N'
    '2BXDxoKGHB%e1c(FgZ+o(%`RdONCtbvnGVZ`j&rv4a|EFukWStz{(9*g)iD^jaHYLw`g|g@pzVldfVH4c`MY%dAj_XUz$griEU=j0aM!kcK@;}*xyf?6c=ka'
    '_K|tEcW}+$qOO(EPBnRh;PQ&|(cU&6+YaFj-zYb>i|t31j!uv6X~_R^pijrKE41o}sm*$DOgU5D>dMnD0-rEC6ldLSY)6G7%zA%cC`AqXkiduUJMRm}F+x(a'
    '?5UfpW;2G|to!nLYNt&VLqC<MnUlp{n5p+jK2;TLabr0?t;IfaQUA*8<%JQwpMRL_`;qgWwKZ1ue!x(TxBypI2ZpKR{yy3&ZG)kL>BBBk?@PA*@Dce4R>va)'
    'zY5qg!6=h+d^(1f*giTtc&d#ClQwMV?#$s52FvVc!?QZs_f0bQRX>`Xy<<0L{~XgoXUv#Zq2mji5I^lqYeM$ehhZ*L?7UW@j5T469rCsOJZoSEJimGH@Cj=K'
    'SW_=Avmxa>xqF58d+}h-`+fY<YntwMtJr(~-593#+q@;6%`QV!-chwo>>0*;pV{Q*t&KT%iZ0W|d}3xRX2;Apel&hAj`xmsXkFcIOG{(xu-^L;{h~c}U+%hg'
    'uKmy&X(bXHVVudiR$H4mf9P91=2D36?>AqwQRY5-`eLVVuGq30I~@Fc)+20p*3fqPP@K^n(?)0|lFPkwwp)Gd{Rxw!muPYae?2rGwwe^rx$>LIxVLn6ysmPk'
    '7tU0i8MkS@t#A9B|73~RttDSMJaoNS4C8z;HQ|zNTOsn6cJgnnZJ@;6e}v6uF=UF({NylP9nJW~Y-VY@Tn}8q<Nt^(;$IzMe9wCx#D4Q+v?S>IOMaev+q>r6'
    '{kS&+_Um-w%4hZwjxD-MLp~gySy!1H|KhkOcOTADuy2WleFoF3>ClXu$h67zRvEu8W0j%L%_b~1?`+&~9bBX-TC6;DbCqG+R-=|JTgX+}944>Sf@wz#rb;UA'
    'p$(b)2H&mK?DeFXY({F0;nZxjnchR8ZDyG=&%E(kX21@r8?I44=66favXF2Dc%QQ!=!%u9@2fc2xtRFAP&c$+f<3>770vx|KhAa@__3i=s@;pW<CHe`JJD^v'
    'f6PSOoPAwS%>&+icVBp22MR`hIa_sB$NN#;J!&mKcR>?5Ed`6OvF82DYu;@zct3p=mX1}*u9>$~@Yd_&ukK{*tT67AKUOlao?Z^{wDa?|8UCVPz5Fa#_3`%|'
    '!zBEAjQ3ogt=VaAycQW#rEFi9yKQsX-26&@IR*uf)e|*@yaLnjGf5^G9?!(kGLsrPBJ-NF(RL>qX)0DP9QTvrrjZ`Da$rLrOD*4P^(*I|QrY;2$!GOXJp5GX'
    'yZ~ooZ(Fg|?brN;%n3m;+vna_=0hYCB@M61WG9x(I?4l^eYA9UE${ZKl_8tHs;|i(rj|(1S8nbCBWGm!Uf7o1z1>6V*cSTsdux-c#GH+KeCyq|$ESK~8X2z3'
    'jnyJm=4a-qy+l{vQq?LS-n@4LQ_<}8_?X^=t&+vqda`OWeq(I;-nLQhjolG9+4=zQWuNl%)|t>fwy4C+-QRsA9O*#HmkKh`x!uIpT0J2W>XrJ9yw`TLXFpv`'
    ')D)`<VWXHErwehqXeu>YIqu{w1OgQAHgu{{E)od0_fhv(x7SNf`EoxHjwLLH<}^F>uJT`2A6pm<cZSlcEPRfPLwkGf$pjnzmo&fWW|?Ht`+q1n*QMp4Fbp3{'
    'BSsoCZ6ro1loBG@q#q@fHbf|)&9Q&)cLI%B)^p$2wa{BVDRsYyT8+p0Hp*v1>9F0xSRUdVg4XZJL>(%p?;H2#L?DeGdSx}g)V7TH{zOroQsq^}=u%O4c-h1Z'
    '5wEr{@bo)8Z_u&bmdJ1YCuCY&>i6+LY#6i#Qm_{F{EFYF{;(!$O)zfPe~p>Out(RDM&-r7U#(`R+8gAxeb9`@Z8nFGOg~-7x+f;HE{3d?dKV`e)Xa11txnN?'
    'JO-$3-mxpCP+}jYY29FF&Q_=<mbNW+La=l8$LZ!l3dYl~YHKbTJI)IOv`0OzsRWj^^afUOL?}Hyt?qEWbgptA`5vH`q-g#n7j4ELhwEmlZY+<e|2DmK`K-)u'
    'M98;}D5V_xt?Hd1m5dvH$xSRJz(E|Lk^4gXIm=;(L%)@t4AH9o*zKb?@`<@Sw$GY#^F-^Z*FqiWOmEMqH{g2;;!kH!^BjMYT52`V`e1j~g<Sl9YQ6oW!(){b'
    'AH<>cx3KcbTVPMmd5sIvz`1PIaoV6MBIy1&udC^53DG0rpxc*WE&kTQ<@&zJ(f$Kzk9*uE7{c5Dj(UurHiOC+8Sws!=KMB2GG<6KVa=v#buV<4T#q<*A@G+^'
    '%gj1w!fPEK``O>-FqquaR&3UcyR|#_w4f6;_gR5^b`Ek7hCus>RnIzdsan_BhM$t}5gZ+AU>yObwQZ<OKhPvg>e9RW;eQ%f^ESf7UoW)^Kd7)6Do2W^YSt#1'
    'L+8V{>N8Z{<JY?f`L}qJ)_33`;4i=xxB|M>EZCkFrcQME?PfpC(P@9N9Tn<HYuqezu!naJc>LqnXAe8C-Z$;aK)8RbAB9$Bg-lw*Yh*kg(qBg$&bm=`4?ptK'
    'fxkUjjR2oH1=mFF6XO5_?zQkE2NM=26JX?jM{bY(t$C(}LPgj5&iJ?~BjUOy@n0gbtAZ0J<Ief<McPJX?mt!)f6{-wSLF15ANTdicQ^pn6Gq-9`P9Ibwo`-J'
    'D!-@Jf9C6Ul7eh5egMc>JT@M^^Q_^Z{(h`Qd85UKdvwjuJ|zD7++XJaB2D2o5+00KPO6gJq&vwxLYo?Wo%q~i#67|*{MknPC2pjg+IqIPn%ijZ>cDyp>^s>s'
    '!YZ>}T+g3RwFh5L{GgS9{8bGoe7U2vlDkg$h|1oTxT(6pTJ0`X!NTXxNe|r9b^KGuhrCKU16`gF-5F+82h*e;!7b4}{mIv~DcWl;njJn9qeF*iasF{M0Lt1Y'
    '_{LAMkO@ZsS$J7YF2na+3v^3TrC|W~o>cIh)f;G4NG44j8`R#vnblUwd!kRXE3+<mt-U7aGoT1GUzOMH=^XW}K2i}sKy_pE$l{3Mk+)ky?sN)M!DVXyI3BlF'
    '(V=-s!ZC}{1Yex3X1N&!WeA*n9{j7L`Qwj=>YbVK%<`Fqz@gDcv|LzNn_#nCzIyxhpeqjL4FVf8{YFaW9aoJ%=H;D$9V6wri^l7xEQpmxJPHUus&$rr9yRJG'
    'tY_AXGyrG`Pua;7Q(}D?!U0UK&db$l0vo-L{bI71ns2G=(0HuQdZ%-Ln5|9c@F>YP^iv-uTGD5#0CRi*?Q{JyC8#=w04469YMaFkchCWg`{m`W${xMB3)-|0'
    'BjxhDa@6L~R6;`U;x)t?gt~1g$Ie*T%{HC6%B}eJvsc%g?dhgH0|MklwP{D6v?{)YH5tcUc^>wjmF8HYSKE9(DCcpC*{2w2&dy4*FfW6?MiaBJj0lEX6t#6g'
    '*64A``ym1D{Qo^%_XmItY&+ZyBiOVGziOk~ikn_h>r^}sxECxd!);T_;zf+H^B&cyZu~iIqPXGf>eYIUg4U?lB;mC69V_5l$wYaXL<E5z#zsD4pHzi*NBU*W'
    '+w$PFU=`)ke(I`8)GWN3wSu?+M~`OxI5aBQc=>YRZL3w?UM@!0ljgMzUb(ER-sR$rqZ>rdyf-!C_e3`v_-`cJht431#Ae`+p{%v_$Vt%*(Z=a9TqA7U%*TGv'
    'VAo>*HS=?|kx;)Gv3c1WjmiI9lm{y<c-f;T3LHNZ<#R`Na_2m)Eq;BYU|b8iy*{klGx%-{1gLOYwwv~>e6^_y4Gl|IhfaYs886W%(#Q4mZR6H*s1YsY&pxm$'
    'Tq+4d^MqGLZSkwtpW93#)WczZ&|Y5c0Gx#Rm%xVc(%W5DkEp*KGaKRNwwm91cSgQ$Sq*5pXV@yKt$PE^P^1M)>$?d{b0g2BOIKcdNjnh7+wtRL#jhFqO$^(N'
    'D0;iB4DRjP7Do-^wP$)#y*`k`MJ?YEEjxHy8l#coW;S8NRZsYBU9>lLFVh&6=^x3L`jk}nQ9NevyxTuu^TwgKnf_`6xmGJ_mMS09+8=^jax00-fIG#<e1@@>'
    'wR%F8VfuEMpb1%XnH~prDNbMrYrZ>tdGD@c*6Twx+B+T$(@mOtCS(pN1l<DdO=$dUB63L0eb@512>9!_JJ5R%bpBKq*TtIiXU3j1R!|}^Zf|1Enu`|u*4oZl'
    '#s5$^su#>te9yV|6v=SrFUz?JUmB?Y$L-6zqW^rNVSBT5d7?1A4(?yio!+dh;aP3+nmGe_#6r(@oraMay7Vm~W%#$ek)dk<^_&Sp2i@}%sAliuDpI*??N@P4'
    'k6TtJcgW+a)8_^h<bJDRyY<arx>I8jQD6$iZpVz<K+E&(TfZxU^4O+#Rz+gq&JlhITzUa`Jm1t~e<HVAU?-W*<=(4>F6H}Y`Q|3e_ZM0W2d2IB?(A9<rr$$#'
    'L3C!SZb;DfGTWz*W|dxkDvHOl=6m`${_Je%t)+D_KMlW}5?ClsfZFjLD=UF7kNv+U_Cb((({oqCm)f^TH)RUDhsFd^<0lS7I(ji?N%t*8HGI5HR^#0Y><y7x'
    '{n|?E)$x270!?XPg8cR`3<BHi)NK9}9yZgJL^vzOGV9n+-?``#hPCf#9WPG^;O5{y+@=^WnbP;%|4l3BM~$10z(%L(QMY651f;QTKlTN=Gj<wsURQUUQHUD-'
    'WFq?Y3~y)G;dB25J$zzdMDn%}r5_1;_}o=b?L~`P@6Y?I*1kN>c>8X{J>K9ek>(AE6rOm`#dLe!CB89<wv7$lDwDBzI!#9sdMI10YR?dB+T~}?r&D<x7$&$s'
    '5P3g(<UM9u>)tMjo?rFXs`DKnx1u2AMwP^|&<Gz_riKUO%K#SsNNeb4?-W(w&R4B0CtG&y5(G1DEyN}RR=Yh*xz95KT4dX5wk<oJ&CGR%D0$cvKI9aA-1Cal'
    'I3tbWs$addF}Rz8BoLuD^u%aqa$fmenOwutx)u$d(e+MN090x?{XVB1k<0zQUnSjfa71U|2FtUea6g+1SgihX#XnNSYJpTgk0FT^7vk2Pe)zPv5T5gOmEEsu'
    '>3BVGn|Xg^tQn5m!uOsgQv8H=!<llgwFd78v-=Eueb=f9FB0w9L@&AtTRUBh_#FPj-DveV_Ult)E}$!Z&kHtZHoPMiwpPF!exT~x8?|>sU{pU&wY4=-{%UE~'
    'd0_jA(#XpX#Z<$lTCJkm6c*bX!)vc3aDfvw^k%O=!o+;Px$s0u+0m@`9JiSrT2DlpN(!D4&sQ_8JlwX-PHJvHy?vT6Z0x$^V`ew~>#KF16Sq$2*)8(IrP^b5'
    'UYQ?Z^oc9q^-f{+$65zJzHiC5%Cel_hR`#$is;?)s<l}3v2HG9!&}!;Fn|la7eGJF4`cSHB*&p6S?vp;<3RpuY>({us9{ixAGV}go$OFs(AV)?gyT%A4Mx;{'
    'c2ooqJYiK((~5aqnu#aZ)(*D5E&2QS{W@=UiWaArUg&NS?&r1tM&hBjQTceIf5`gI$mN1++*Ge`7xOln`^_JXFh5%-_Wp+RrsLbl#9s=xer?e8o?p!1Z(zjk'
    'YCx^BhqSKWpA)S%Ty09vSuz@*O1zz%uVUSjsux+Ow%=x=+R1d(cy((nty>%FSFcj536_4#>qI7vx?jBU&i&=uy!eK6ifb=wp2}L196MKI%VE3wFcbP$4p?%J'
    '*6wznG;IRmmrVKlb;b8L=7GVx=ffA}i?=$P$NpY59cE5E(dRWH_JF}5;_G<lT1)NX!gA3-z72DNm!Iz9R+-c!Xb3@#j&{FNSL<xo3%_FOtEic#r}sfcjmHn}'
    '7az73%kRr*H%g-t;!(%y=64BV`2O?l&YD0{AQK7>*LeaB#D1e#jy^wOJPpe=Ki;m&-?s86(5Kg|RtU{rP?4!GrS5NfzbmwpNIA*f-7Hm)R2cphQD^6Jv8CwM'
    'CLkJCp8L+|Wk@{?SKXmpCirpLaYRDh%Eu4-he%TvJnZ;>XRiw``wXXMqW|T{_`}Wb5h2$g;lj0{NwSiV<9EdrqZ;+0jxYoOfU>@Npm7p5(RDOasfK{euUDSV'
    '>$jKQX7-=28X5hy)6QS;ZogQs=JWi?XY>jh&k5b_ZPbtJGY+<CBs9nKzQFNzl`%#^)c2P4^$X+R>i#sRMtUGm>+?S|tw-FcalOqN4BiU-(W3V*{wzdM`T31k'
    'TSFT`zQB{iiysfRh};_5;@wg!diwg!y*6+UYJewvy1Qa--0N;2-fZB4whrasc{zKh3_WmqX<_wY3yLIY`SEnUYbD7x+|*9t|E~uIs%O2+HuF(VRcFbW<n}R0'
    'DF<@==e_~1CyV3_t?ockLG2cA-;!do*E0`78durur=t|<xfRf(<zmGQ4?wI&ne<(<zhG1rjp7u^6g1kJZx`cR&E<X3+>1?chK;U<TkC(X%9Od43Ag_(JV+3P'
    '4rjb3)Vi-t;59ax!Hum4sa^w29b$E%#!kIQZk2Zs4?yMM*8J!@^K^PP8lS_HVBl31nl@s~JTzWxyk30@SD8e+&N%taR_lf_Ww_ZNnW!qWZ}#o)@7*8SL5HID'
    '4Mq7If}omODAn5Db~>_W#uwLee;4@;`p#n))>Ar5q~kYAyrm^f{*1S^eY8lk33vqix7a)G{(YGfCe9DWT=o`n%P%@765dX-%|Y%R6-1za>-RpqTayZS*v?kO'
    'B57{kg0!~-qapG83yX}VqpOOpUc?p_yzX(XqKo+<e^DH>C%{ophHCTO?fithR-@kR?VVtg6Hj5a$>h?eb7X#-EBC5$&~HDn-3_2`Z~y<FcHTyCow(MOPcQD`'
    '`Dd9Kl;}~Ji{IEYDYw?^9@N);pOur!7F?num~UAsHr{UEgErSPCOwc~<#|p5zaauF%By~UrYbg(_9p{!JCpd-Sd+oV?GN&Y@)fa}a$X4RINGxh((gp4`TjwT'
    '*EOOd?0h12GcD`1`$E?GNl^|nI6fE5Qp1IbCiG36x&&C5p4#;kvof#yQWDUJDJ~`v@>Hf^$=~0~pG19|pPRNFdTu>~b4x8q2`*<3`2K$FZz^$)6Hl8mLmj^0'
    '2{4`S7_(DNCY+X0oA8$ZDQ^XP*U0PPFitOGbJrcDvlRKVKq@?I=+RvM(r_!~OaF@BBszbk%ZR=ix20^~M$xUGk>FSygP*?}-AQ}OPrv~TfQDdRUoe-o0I*l('
    '?0=-T%GZ!-;MUb;xpjKgU66S@B81sD_K<p$E7Xa<oVB{{jW>}Xtz<kI9B1N|*MUXB(h}W>9}r9>`|amyUHUuw)3=Zpx~JdE=WFT(s$CSzPBvo|A$-lwX=S}-'
    'cKxa^YK!{M%gi;X(l~*Rp6+*vdRIlm?HTo*t(#H>GZHUqnw2w?Q0WYI>lS}%8{tc-0M?(<*N(s*SeXA$(yq(heYuO7dYN2R)6Y;!<C-8DiIeYT_9BkVc6w79'
    '>wytO_ZD!i+)t;RI9L6u6yo(}VWnm8qVwuFeIm<htL&smi+kQif`L)f-t9-}-JST-19msB5RclAcaf#_d~~H~m4lkS*#g$XS{@xUbJol#HcH~#aFL_CL+0ON'
    'zJm0P#KVu9C9H2}bGTgYau^zazqjfdz_s&zv`Lb)|Cg*AuD>rnlEa;Oq_-QQGkm_r&gHo4?aBUznf>0)e&m7v+4Rnv-t|Ka8j!On7Jebz-+70;G(o|2ZszCi'
    '^T^`K)L-2+8Sfj{#!Uz}ohk!@GdtAVT*K4kX13Qo-E^+)Wba%FrYOIg;PG)Sekq60p!IvxXjtNeIXYk!DghJ_Us>6Mv3Aqm=zf(ZrT@TIZ;kxhfes75kMBiX'
    ')pK-K&)srsV0vql$mIQvNXiBgspGS8;=`@ev?o212l{X7x6e*-!L?y$10@*U+39p~!=m1Xwq5JomS#^T>2!$-jCL6t9&eG`k9DQ6{WoAkO4-N}B6qsXg`d~Y'
    'lLD>~RkgYKsX=0rReQA99T!r5Tp}4TH3yTo^X89}Nes8f^p}>K6?g`3kk70CN(r_<ADGy>{d+dSI&s+QLnsc6>~Ct`iw#oD8+G2q)V4*$qxgFqmiP@p@4+>y'
    'NKR|HX>LM+SB&mU2+6)PJ_wtaTs%=Ryy5>79|~NTGmW~<4zC;aQ4PlSpsQ=Gst7$yVLw_<>Q%J02de2A$p&*SYPYhFSjhH0kjHOnve<OoD}0PyYo5ClIe&HQ'
    '<0lJj)|Qb7GupEh)9*QD1TE@4Z^NZ#=(^u?qj$rX!R^ExTJ=#vUC+(;iYVw$^+h^Sc;@Q0g^avsOCq>#Y=|?ITJ2i8_OA8ZEXG9iVGrI%Vn-KPJ`bu4z(pS_'
    'Q4!h&YC96|Egaxll!;7@gndq~F3*Ws`sw=z9#?za=Ck5p%uXDU89>8qFNh7<U#yA`d|czvmOglWg$#*WR_kvlEj@U(MZ3$~-<}`=?slM-g-$lLm$d$INP}n>'
    'L)&_B0*{ZtSmqK!dmaNjd07j=sId=YRbO$bVJag0Ij+{3*yQwTe3ju#G*-6cecj!-t0^6KQ$3{1Scz6i5#$$Qo~JwR%f0l`Cz(+C89;VZ_;R+u(ycd_W=)W~'
    'TWQ?wo+Kh_f~-Cp_3yvC{1AL((ty?M`6XgWEnnL$8U<kInkAHHPRu{NB<uWST)aAjL{D*Rt_sBWjuD-cehKG?$6EN-ZVumU1|LN5AA=h6BJ;-stBz`;T65XC'
    'UTOuR%<mSnSMz6`zwA1UxFgA)@d7r`xzm;(>I(?>*zB!8-y8LEv2VSq>(HPUUOwNfBF<|McRJZY8S49sL3*fZLX^+EY~BF_ZZ9v$W&72>Y%;jxhwniHo4YT3'
    '*AI=`Kwoal(UyxLVZ7LR$n4{lLYJxawj$KBCB^xSi%R=A7t@li#y%^*2O)7KhlcH6iEw^iG@&mH?a>x^u~Lcnz9_~P(DkqnbTic$;Hm||kvW;)E|9v~9SV$Y'
    '%)2kE1$2gWrGp&xHt7NKsfA%tZZ9d#BnHvKxlG1=+dnfw%)F+mwvQL-;S@WablMSSzoQ)By;%Vahf}HBuaG0DE^@n5V>RQv$E4B7l)2p^rnF!K4YH24Lci6L'
    'w!#he@15hWcH-YHU9wIN_8|v}e6v>QzVaJkQ}em6p3#OVpGkeu^v?8idX6_YL|xEqi#?f!Qk?+i<2B!G6$cj@<oYBE(H{N2Fhk&I@aGR$+^xD&!)SCS_n3D0'
    'D3_$USAG^<sXvf;<|<Z+dKISH%C|jh?xvbjbb>Sf=a2LDpRvsW*)@$yX%s2mjVieLB&%+(E6rcG`CCfc?OSvD<cwp;S+BZL|71FWtjit>FumbikZ$R52{8w)'
    'n+A>0X!jZzQ9+W~5^X%uGGCK^tCS!j+Z1S}D0bn~ylbCgaId)2`04Gt;0y6F1D4svVJUp>T4Z1C)AW2D$20o0l1AmG8bPmvBoEK0qIF%;_E1w5_s=ix#=a#K'
    'JU12x#|kHKeUX3K0<h$Jljn1DO%4jT32o)3+|O#QKbmOU9@1Qx1OO$ucdx#H99+?We~2@A3kf^*r|VW|UjO<+ZOWU+rPd<#`TDWcmGKz?8vc6q<e>b0i>k=!'
    '`5AQUT2AI(JibbXYM{dQd~K6kR9c7-xcHjT`m)^*+#@Lz6UtYf>^rPtq_nJeho^aJMUMCuyIga!f+~1-GkXbR>xAALVGq2!-6PrSS+ni)zSxedf<S#$=ZVxO'
    'xt5(Eh9#uC1)fWCH>6kz7S7qo7ju*An6LWx)=>P6(wUh8+^zXqtnJ|!(fd=|{(AWfE2oP1;0WkFNMY6J9uHmbd2!O^3(uTKI=C+H0dar(y;F-h?K=@ZV%zG('
    'T=pvSucx&myVhyrH-}@-cK9_{pW0ym%DDx;pB<%Rd3vt3bARX>6|S-PVEz{Tkxh2vkS`UCyEV2tC-%NMzGnB@-L<K@jb>2&GkW#&IT1eOkV&3_^%^~t>yBz`'
    'm#*f3#TA{)?M3HSq)*yClvU^sDsfv&vk_caHOh%YdEPJ2j8ZC_arjp))Z$MHxTgcK6yrJ$jyri7CfA7mtu}*;i_Z-90X(ZW()DusWcItwJ=cEtgBwKLTOszB'
    '2%#8l#9k|IO!?XudQV4&zQMn4cIIr<Iiztl6WKCZCATFYXlQU4dL!}qV2|>MIvw+$m>bgdn6P1aTf58v+6n#k;$)bol><r#<%HrA9gP>qhCQpVAZ+oF8FVbO'
    'PG{healiBYVjZT|#rWta<r%)(EA3(1`^*vD>ks;^v?yxKYU`|Y;j^p;{g@=GHFwbrvH2%_ZsTXH41ayEd7EGQ!N6Lie%_VrR%1ou2jD(Vij=+cdkqd~X}iPi'
    'I#V5RmFU-eg7Y)K=(OznIffcFY-aQqx6Vgx#_*+a)%-b1y_{!rH@h(QrJ_m3FuVPYk6eMhS;*r$IBP?h1bXMe$*H^F8RwUc%cwmzTcLw>$ey+KmColmzK~s~'
    '2)12X9@C6}Y#gMZ+CiVc;`UzfBXGL_E-ZTHYmGLNA|1YsYWxOVwYg2>Y{?(7pVSlPN#hSNuPphAweC`R<1ltEv#~7<MjlPJ1~p`x9=WJ8yV%#cgBe}9#ka-V'
    'W`)M#`h;g7RN!l<Lg)NwU4^XsPFjzN*>NjWqsh-i^Z?{XIocsIu)4oI)!`XWoYO_5@#V<ab)6wQkE>YxYK2HXDpF-HzdvApk2<o<IN529PktJDnaVtV=w#K?'
    'ALKaW2SSuTaBKAL+_{(C`jyz3Ie3Trq+ziE(uWhk*m^2P>)uFQ?|(nv2OkRPT;HW}1MKUewp#Rnk;O*9<thv>r_N!%Et;#7MD`7>Z2`?~clX}5=Ki!?+Os$o'
    '2W5@a3oZ?2r+MX49!tS(+?VcM@!#twi#qsFBR(KV3fukmblDHROgStxP}l`squ8}Sf3aRzVyr&1Z!b~ayjWi-$aD8<B1Dxu6^G;N^m7gaqIZc`rvlrxMppLg'
    'OipzS#T3R^jR@(P<d?WjuJcm|4z$T;FKESe&@5`rQ9P$1R1X38h8s_YJ-p;9IOf)F7R%8gy3WTxpngEBuZ?-W6kA%tePkicIxqXEiH8R-$|pFbYax&)#IhEw'
    '_h#Rgco$Xb$?ib)uan(22CzrR&1ws2ZT7K&mcXbB$@Dd>N8P#~AHRp8<*zF(=4DLIzht<p!SB%zD_(=MzOQ%26qkSNy`N|dhna8PSm%!9C$l=OY{>z(q)yU)'
    'yC_s%-wt<T39^H^K;14Q9z-j0bYb$aixE@JSRC^qk&ml~`{1?Tt*U3*d<e%I2~md^AM)H`9NgMU*jzN3&85=-sNn(`Rk>l)k7=QLkJ|cgRb8=S?GQb`{;n}p'
    'M&IAyC34CDTN#n41`Dzf2bABUI}Q1M)t46DO$dF4<;Qzq&y`cFGs@(<bttG$Gu_{>opzOL9XsX#+vOde{LHQWAhGpx*!L@g_1=+HYSJ8bJ5KfseP|<3b;C!$'
    'YKu}1>ebz87%P3iTU=X0@2uylk+s4$e-0Pin$NTME9xo8;vvIK)JP=AaT<vdij9EaDV=*JUBZ{_H@h`&?j>C|f4g?it#lze>;>KR^xPQ!-Of4#`!)cyy&6=R'
    '_bc1#WEo%62h?*%rF=@bG5^lTuJQSV^C4^vw}amf-0kS;e)E~P#mi6}VqCkY_`L?a`J1hEV={A@SPGuK;t)QrR!^B2ePQ@1e{b^pSQCH04ojAXKgR0Du8bgY'
    'W~S_M`V&@++1|~}>y|pfB^Zd^@3pED$OiKI+goc^>$eSd`o%tDThCTVxG#2_{<FI1cc`a;Dq_nKj|j3*Mw2u-`90uryg@r#KnnI?oHs{xsv4NLaW51hjMw0d'
    '82~}0GqL;Cfx_h|ecsLO6dm|2d6m1fW<>HfSIX8D_?u#A(Pz_p7dn-@Ol~9lMf-xY<oIwr&(87(+R_E`;JbUl#%ASyHsGYV0~UlHdK+ba7GJfX9bG4*!;r2U'
    '(yQIk!?*Jx<RbykI*w4g8e4iFGJkcR)VKC`BJj+!cg0gQ2x<3P7?XYA&(*!Xy+BN9Pw`K0e?%48w~|)_Q)?U#)|V$?Ha-CK>q#%3n2#UO8%t#~F6ws`vX!Qd'
    '#nrzd*sxeF6)f>DRdJXg4<Kvsc-!ozSB)C8H(2?!2qhjAjlT`Xna%C4yTatJ<SqgHZi#Jj&cinTfZ3=XhBlNOZpbAehYJzJ2g-gcl%xG^@pRFVcA@fa`fPK2'
    'Z%XO0*)Wq2+UU-%=yw!{3ug7Rep~8A^vBUBJO;5UU)Yrc3>f2Nujp|{1{rU1hd!reu?BY70$V=d=Sn?a59uzKiN)h}Xj8!vmvZdVm%XD6hs2xsK8<G^;Wp>t'
    'gnQCxtuKAbvEI++q^7<fY6o`Row)md^wSBduEsoQ${1=Qe%Os5^;FQEcAx5k3+vpfw<r5pAN5=g5od{Voi&vvZ<^HlA(HIhs@H7gT~hCG9<N62xHv(`tszT?'
    'ToB`}tBOZpvxC|O(jSzGKbdNy*>TMD<q$_pu0?I^Ew0|%`QiOxKxuS-%kO-^oGZ)lz|hQvs+x@fTdOJQhpi6FMR}HOAC%6E#5s2wVdz0gfURJnmG5w@&Puaj'
    '(aRAOZO$@hsfLtDyY>~lob!nQdtV7@UsXA5m)7EIT?v>O(7InoIEUvUu~DUvLSLOf-cy>%Q@>ma-LW?uo+4uSfw{-?CE3Jo>hC8LK!cvAQXC9#^~LFh&5NGk'
    '2=ZBVyy5XOUM+5aZbfcZ!2W_i7M);PaeFE$9sn?n{<3L}qXk7o+EKVvCps}DmncnR_#>Q1;!j)Y<Sc?zASz9})!8h1l6(GZ2v%4UFuS@b-(_?n_A$*(WFtKh'
    '#oU#c!S7xToo?0DOO^XvHrfKBYe1`Rop0RpSVMKq;T&3<!BGdE&3njM)I67*H!ZfC-)=`}auDp<-VQPee-5k<x%vU>7<wgSOn->DkI0_}-^ICOK9bngtgYDh'
    'gc+!nZS>(16whzU482eCKi(c}@y}XX9X)zvvXRQkICMJ>vp_kY_f1L1$)GK+_GTBHbUxl+F&_=G`s~(lR&P}j*X%BfCJieI5i^tSyfXX@k#^&YuVZDBOJlng'
    'lZk9}yuL7>SzR`>7q_U<d0$(##^fS`h}FG%onG$cCA027#-AhGiu&?OKuytD9eirH!Dg)G8R{FpA~^Z0+UCHd;LX$i7WQb+u>U{As*DV$)sBR8bvsm=e=hiz'
    '?|9!Ga(2D)R;6-Ed@jp*J4!1{V6+7`lGK&j7cm1peCE*Cx7Z1c_9r+FrhM=n&<7pAZ(G%exR4a%1)Z@*nwLW5{Sv`si1SiTd797_D~I~7q*VjvRupe0gPHDt'
    '`!JO!r@xF?j>ky9(6`bbmuB7kSwxfRFhz&#dbK;Vn!a=P)$fi!Ixp&6as<W!?mX*BJNngm9=s0&047Hj6S}%=lC#l!HhZ+sdm~t$$xHarNSUathJb9Q7S7yb'
    't4w?Bcr({tp86NvPjNI~+MV#bdEcOZg$CGRpmNvh6ns4|>@rtshqHfw%qsY)x@M|EPm?<c44;8>Wva86hTEC^;gCJ)a7!Sp#sU<0y=tGdYxBQpFMDj)LegG;'
    '+gZT6S-9c!P*NV}-8S&^7=pv3;GXJ~G(w=uTD7M#7B)xWDH*F1mdWbsHm>Xa?hZP_JH;N3*75coEY5-Um%Jag*_Gy;$6_g#dc!1mOOC{j;a@)KGj(x&zD|M0'
    '7r^kJ*hz8n88nH_PwjNtd#ipk*AsNNi2L3jy5Bk_qqS{`dF|i^$L!oybtfw(T4_y;u?$WFXYbRh$-a(|hE+CeE0YWiA@$IOzuBI8=J3z=CINHlb<5Yi7|PUY'
    '#ZH#qEbV^TFYw}ecI{Pj2kk|>Tl<Y`XN!W2&Sd#IzBkr@p3iRfz<eaLl~u`^XmK05a~->GT!l1dW^4=%sm~(Gx4W$k;^l6-$UJ1_Va1f~bBJBHtpk+fPLD;s'
    'F2szF&)Q&}(<y$y0-@Y&N9Ju;gI3^On_92w?^HJ@Ms@l+oLPhgTrL64&q0mL=gA-rQGdm^CUBJM-<)oqZl>Bk55w7o-vi5_?$P)0At4vXb~`fVtT&d0Fz<0k'
    '>u|SqFd`-glRe+vJ^dZv&Tp9-dUNwKVnEgW9{p~DBzUrK^U|98m*%c=(EHzYSEd&eq}Hs9^Rh9_2xN2yp1R!v#7M`qVu%ke*!vAFklI2%SBUkpWJt5l-RjH+'
    '-iq>JI9wh{vOoM%H85$9ofDbha%f|VR(-L~;&=6rW<v(K)V1P(6gCNqqFZ);+QqNTrnl9=;$gw+PiaNFo}}s<z*S{njS_VgFHx2EtLPpWYM1)$|C?xZUgDiG'
    'vwMSAIdD_`+UuyhV7319<9s}9{|5Nwp%C0KMr*I$9Jt+)cjd$E7n|i{KwU0SdPyjq;O95p1FbcFg^siPlKxvBedVB{;^P&cKD@{lk8?GlnTomSuwg^kU!qw3'
    'MIT{HngzegpnW|#i5Fc4^qv{42IGVLfmz?(*%~0&)MLybOp8r>E4v_+9^$2fy+g69UsHC*^}TCsC<k4uOHw`|x6@={HInodlTqqt8-F;t4bP85LLKPa*(eKA'
    'X_yGt$;3tN-UTmewRJndn|p8`+lS!2It+>VR@MJNs+w&GjJVb>>gh0_1F!Ec&^q9OUFfM#OF8$=UJK|4)%sP!>301!jTA%&Q#DOnCYurE1^b;N76IO-o_lFt'
    '8p{692WPEmTZiAdIIY{-7|d|kSy|_2y5PFua;0%u+H6){r%_N<hsYKhvco^wTU8%ddJ^b91%_i`bmCNZuGS8;eZ%2W-nf|Ucjm4AWp)|+XB%DuWaE31mn5}B'
    'DyLwj)NQq~y!F6vIldkH>jl+nFxI}wA7gNrtf@vm{z8po{k<I4&t3bu1g)HQ0`g87ka%*&A3i76{SJDWO%{V1`~Y6PGr%Jkje<+f@rpO6Puel|Osx!yr5`<+'
    'NLqGmRZC|u;G8|%95>I(1{G^(?X%k0-9Pc84{j8==F?`vlFm;DU+2kJQhoT~c6vKpH%n)Gs^Dl?Y)9=L_WMGdL5@E|`E>-|^YgO^YRfP$;$K$hZ*67|MInP`'
    'ufZ5<Zh!ASSgMug7J$$?5Obr3ZcI*>*JKG>4*$US^1y9w$JrVGQY_d-t-vLjNy9uhu!>RJxvy-_0u9gR--!6Mim+wuFa7?=Iyiq@KHyqCQzP9r@i;U$k+^Q)'
    'VfrSwPktB8gb;VO4vJnza@n_kwH4=c_UFk_qqDRfK^iyXb9_pQQE~=X-Pd^2I<_vG75MOPrkyMJ;e{a>-07l1j2)Kh4T;vDl5hOkm$WyocMzduaO@Fr1^CAO'
    '9&0l9AEQmVa(+@CvYP{vz2loF{vB&9)Ahp*bUEs_GrkyMR%e|$-#PEP>CPBpZSBN$JHvIGYf6fqvEknigT4$D-VgTj)%3ON6w5oqZE!-(>(Yq^6`tc9hx<(<'
    'ti5#>Y1z9T=j`OWFvi_Gz8?(q_rAMXTIy4dJExO@;fq;R*#|+sO6n(;9LV<W5x@sNucu_JM%5;(&Th}~W9Mde_cWScdyk+KN$3*p=ic%45}bS&mrVLdzT;ZI'
    'DRnoGu~N;H>p?ojpLE-={9H{MClZdXdL-L<`JF`}vD$LfZ(Vl$w;g2Bxh73~u30hz6nyr2pI^V$EROVSd#yI(;En?*QJlsYXs-!tzB)^Yn||LfCWITiZlP+c'
    'A0uPjZZ+whTWe4WOYqim+h1m9eYUrSPju)F|5}qPBtmpdO)F&>*>k}9L*W9{wcYok#qICZX#&?z+b6>2WfI2K4SOY2>oiy|$o8|ke)CXUJD;#vWOs!(l%ePS'
    'C41lnr5C~BurjIm(M0;g=ERF{U$Yus#Rd8a8#5!mEs^348Q0^z=VadJ(E`3!1D(tJ_{VW5)dtIu?DYmcuasvuX4S4>_sNrtYx$LZf<O<XQQFxy3#8ttOwX9S'
    '{w|N+0(N=(LN3RaSJRKf9Q+M)AP7M#K?mpcRX;}LJ3h1<+NWlg#}#OQev6e5SvQn6yi$LRY&WOb$@JmpEIp5`-+I4NK4xo?>ODcZaNvHdc!OLVT~WJv;a(T<'
    'BUz2j0^)cd*o?AD94#cbcV(SbqY}qX<*^3I<zC34N3!D=Vw-_!ab}M7wZZS)O``1YAsO6~0KN4!d3t^I6ZRK2Kx<#MU+8S8OtE3C1;y<?4!CZAesyng_^6I%'
    '^}`X6fR=Zp<;}U{Q?ofPbw!Uj%bC8s#zq=@LreQp!OiptOZGGH1T6gHr2j7>6(tY5Ie#5ahA8DQavEzVYnfjphgbZzb>H`2g;^J-)ubqbCN^&hovl$__c)EJ'
    '#|+h2rT*em3SVLJsT_w)cbL5e)2z&A=Gip`?bzB|%)$Zw$V;G`WVfa$3cSsoPnhpWY!WYOi(>XXE0+HfmQ_UJ?}Kh==>4lzIi_OK@*m@`KAvSP)Vbt*{R5|l'
    'ov(X8hP4PkGX;J*#nQAn{e$3Lt7PkBgEv@%kg|Q1KM&E!hvYdu)7iXy_Gj9rFC0!4OD30%#6NwM=<NNm&a$c3I%5kv+$PV>-FQ`Jx64-rE9Ng4*)LD0zGkOj'
    'e^h&Bj3S9(&^s9oVl>ES5uCNyQIlJrbMKFV-%KGCByzWza=_;2ym-VXL(2aocSDbF+lBES2c_0Dx&!dkKO{-$2z_zhLe3xRH1LE9_bPtN@7{F_s0tlc>xv^R'
    '&0rmdl|RLrV<?#+)B+F&O#876m_N$a%fxy`j&p_E?Q_M+22ooZpy}AF7R(GlGi>wmDK<>0)nIi8b*gDU+YYl%z|n4rl-YgX9oF}uh4wc2ayhTRguyB2#wi3z'
    'qkU!O6?M!1$l@;|o8*sInfkox&^On#;n8OZJtj#*FRIq1Rd39ib^Hi>-CE_nj|lI4-`6T(oV8>@w4-tJ=YxM!C<Cn{p`GX(-tE8>lFOPc&I{2-zjpD)r;pP$'
    '0l0k;V#=&daBAF{+%N59*Ly$Ejsbw!c&y47>kam#7M_er)TH%dKo}6bS-}2pD2xxIvq6oMY)xE_?TX&;zOd;$G4d*JR=W!|N2U#`VnOEqJqr~hZOA~H7A7zt'
    'W5>IaozfeqW}rLWv{7Q#?f!!g^RT6oP<Gi>!CzW=r|s#fc7%fp%jk<p{N_9adzQ(K-@B2zthVC^1s`VQyBUERaMhzaVi&=zk!4-5Z*Wks4#;LE$#<du<`}aI'
    'KONNTSG|e$72WYBd6n2xYTmcq>R>klPoQ_?&MbfT+ZWk4Tcf<&ej`1VrM`V}yG=TO9X(=rsNq%4;ew@}v&B@YdJih;CZ3`WCwQ^t#m&N)5A~&&q-~@($-$2h'
    '64vS6G}O$L<7U>_Z3hfBOHOL**iIXdT~WgoOy(MD?)~)oK3y*<=>~4sYn&}fz%BnSyCVw&iwrg|a%#3`H)}kRqR=0v{kUJzHM{hZ5UC16mA;<vdFQ0;R^9Rn'
    'vUlk@s=YLaUsYD84`o!&O<`U85uNL|S~q#>(=;g>9yabtr<tEw+i-V(iT!GdK9W)386LFH^n=v*qDal$kaCRR{b~j0)linewl!4t^P6=_*8jgj|D15;N6CA)'
    'NdTQmPdFyMV<7V7FUD9Sm^P+Zr2@}7o%il$l=*eO&+GF`TgHwNW*UMmghS&5i_gWi@2&Bzz<#QGrLjLsT6sd+S-N>wx{$FU!bks4>d2l}O%c2hK0=#sMwR+y'
    'mPZmy9|zYLe(5oi<~{&=)aY<S?TruLO<)J_V@lx(nB`By8}iqV5Zg@`%K17uUdzvJu1u;Ayy!B?xSV(TS@7&MP@hCjf;P??jroJR6sz+NAFa*WG@P5zktn8p'
    'et1@Ke&w!Ti8MtOHX%FFjy8RU&7M&EAtlp%o#uo%i%;!x305zk$K58<Y+TdsmYnV1o6d$&8;Pa~^6BL__xa#vFD*jVNRtQ*GFsoaLywp)ca4)eXy<;lvFgsx'
    'al-n<X54Po0%3a6Z|L@su^oD>V%?4z{i##U>fO=hV#u|R3(5e;%dPYLtY5<cR(c4qouYq;3iQ^Ua0^y>c`QA6rK`xe|8glF2lrrIn~Zw?l-P+AHyN(Q>Bir!'
    'vJr!L{O0|8?UldEX(#I(1*OA=>O)Jm{WhW@)q1v$@9yIB9m46Q0Yx`PJDtJB_aeDRyNf1i=UcyL)8Q_Fcwy%?y&w5<0uCyo#dzCKrpi-u9!KrHFKs}ITHc}W'
    '<%nxPig$zCKBjx7(J$3i4f!;1!5EH;$Bct+LH)9yx|^$cV*MXE(HftFCe9VP5WqTs+AWT?C(^W^?4?e<J#D@N2AhZ@4qz`$?DM0$#bq~iZuGUJvt#qI--JLz'
    'xWLn~u;snQ`o@*RA#|?lp;8}E)n)6@fZO_Ju^JF`T@Lj6JH8H}s#aTxgQJS#x8Fj3kQ81SfP5l+_k7GbO7ZN(tcVxa_|TwmvGH08t(&Em-cuIl7FwL&FWTBA'
    'Z8FljJQj$j?OjZPl<OT_?cT5T*Qb$p6VH#m0M#zU<E@0@9bdXqB?1Q@Bu(Ad@0iW*vWQTw_s)|kx^4Fsa99McsNDKaL;jw}Baz%4oh4=;NGt=;(fAy-hAhAQ'
    'trlu`S?Q62S;sbpGKcVWlQn8J3jVl%YDJz;T9k}Jpw@+(kC(D&I@6(lYObU<e3f^f(r+zSC1Y|;YfH5S@9k3Y=n|ltcwftV4<?-=JNn7IF)GpDyWddTq0y9{'
    'Zp?I1CAoUVF^sXqO>oB`_t4O)kQ~1y_+w^fn1pXNp_g{c!O*6&p4J8(#R8|nO>vGZzjj?eDpW?kC&2IR!NG^#Bv_XA;w>L+g~Q!iGpls(*ueD(cpi02J`?{#'
    '32xmJ6K*rP9+={Aq54nU4v@*$Uh-G4%HVBao<8c{JzbM}G5;PMuD(y8sZr^^)N1WfR43eLTjkB^26QKrDSB!=<f?cqmaFNY9uIqix7=wy2bO!CsRw6s%^JXL'
    'P&WV4WdiWK+5SC;Q0qEz?ii#DtM~PJ+3**E;NG2Xwwa$#WQAehGA&lv20&i9PzIoMn6$PK57_WIQ%|O93|gPvUaUNT8_-oS`Y)GvAfy>|r;b%e<?pe$0llTe'
    ')VF$-CImB)net^EnB6>S8*8V4a^g%Q^v-9J;s9)W&-!NtnbqvM0tCY^sO`F_)pJids)q5l46-1^)v>!PnUEI|5R)#SEq-z&Dk<wQYy{}oe?Oi>ZYb4H;Kxiq'
    '7a&p=vdRA*&^cnjomgk>6}R$UQpX6*q~)rLmQ5?%%4i8LfE;>74MA9Oc<JtC+js)g;EMK1xbT3dpI>J;>T^0gYyT)Z_on55Fb;o~1`U~JP^2LxsgO>R_(MrW'
    '2Zx+09X|W}ykB6aUAw>gx|(%+;DJN3<`~!d%21hC@!25I-;m`biy<o*ep?%i-E=T1f@%tBwmnR@2u4k>Mw`D9#D2Ty>mQ@yIHv$jZm)!bFP}Hz5IuT2g6+`W'
    '4kR+9R(hp9%N4Tb6)$P<=}WtJ7!lR`R4`+05rbZ^fdB>D>5sA3X@|Wz|HGizT{CPO<+#10@1zO8Sd0A3mI$bo{N@wnLxbur6szB$$qCEU%Jm%#1Cq<IOEgZ!'
    'Ypph~y#B;!uN^E2A_D1_O$uz+NU-0F6T0it=wx(Fd=0~*8bCh+T_id3k#1hQHVAxq&_w1)8PqtF@W!6^)Xw|KpZ*7TMkenFV8537o4Z=9mLZD*jwWY`E`uv!'
    'HS`${Osej2P3rKGpcfnK($xOY9$X`T3DiMPH&VJ>jQ5=$ZbL$cN;qD=%C7S`dB2DMA*<x;%70d8{rCF=KKjLX<*Gij8D@wd7LBqekCWcm_)CHhfV`befA0$7'
    't6ukRYeuQ{%M|%Llh4zL?kXpweZ2@@Z(QNrMz#BfS6Fy`$M^l_d|x-YaJQ&tUrhnlUb`H$3nOV0UtrMN=6}v;5*oYb=V6Wdi|(iQ+uwEh7w9e<+`Z|2F(9`M'
    '?|iKt4ZDe=D3a%N+I|9Sc-?EfjG`w#?!ZXd<oPOLdRDz=*8mjOz@V9w1Tm_^?XCmgXO8+*KO7jz4TArhoAt%)K%eGVlX3s_R~;?<Nd`voe7!{`Vdpv9rW}(x'
    '{`OW!#uS`Cw2w3cs^4@G)OmfpQ+G4GJ9w?iwsqh(8nj%=*IIZCr2kh!)k8O3uIOaSO+|7cF>AuhfwQrwtye2<HES96$)daL_y8~*jb-!UG*KGasl25@r8*1A'
    'b9=D5BG0Fh=r*AWTlTLc@8v)Cq>I(L`@{vP13}K#EV$?eyeN=Kc8g|}C8_5qqaVoU(g~l(Pv2D6*ZXjp*EeSqL?16gO6Pxd1>cGjXx|P$qd^>Btzk5K+@WKv'
    '!&4EFEzf+`=7HB7w^C}Mz1SuE<(qHMqu!^5v2_y^;5LVcIz8*nXCzbVa$ec{^>fvg2b;S#67mrrkKA}whvg_Ev0@86U)Bd1wj3k|ZRh)h?%E5#hT;CVNI!xs'
    'Pw!q5S+(UezI_PRm>&8C?hUHD<hBp4Mt`LBCevSpD!bLA7#(-F@qD@-ZLVU2T?xi=)(M#27U)_rJe${-js4VNBD<=<+YNqW`^{H>w4GHONqLstaXwT#&8q(N'
    'Q}sSM>UR7-)V?_TKp78e7X|-n^n3XJS6M88=cM_(W2`F7pN}Ny%1##B@3oZ-E&euWjWr=`UB;)0OT<SyxZ`>o9kpbFa_ennK9$h|T^kp;8g_X0)tE$rXx(YO'
    'h_PQe2J)HWcI3?#YGj4BU&IBuGo9cEAMw|2bL?B4XVqxAq#usycC?v_&>zU2+`V_^{38IT!DLr5VAW^`*VG@R`O|IL(Oia(cXx*G>IeXtNOouOAO%Wf>aS%0'
    'nrKKU!i~yh&W=B?hZIv?VdZ-ztSg^0Tq{Uriu`dc-LwY7VCv*6g}n#8V~E-ziUD)WXv8$^93S(W7UH{E)9ijS%$?(_x0+;s&#S`@!gghAX4hW7Kl3n7_cyIa'
    'V@6)3A%XH%qwOe~PXBrGHNu78YR3=ADKUxCL1z-)7eH6oF`N}u1ESaM7*EQStLNTfR=hJdgs;z+_j6rSsSXND&B{IAgN)iAw^xN{rCIIQkH;N5Ov~i8gmGxy'
    'IGdC+*{-9P#u76L!=!tQAz%9?*KZY89igLfkPQ!*$^|@GJ2{ht=xr;^_uf4WPW73ujV4+D-Q^GRYMkwN6ZDu3;)Yl4RyOz)n|530Bh$D(mFMV1@?_-2X|rF)'
    'TkZ}&@o%dL8h!BuxZl%cDJ<2FJo9OD{%n+u`DRyMq)p>8aCD?Cl|jh$h|xVc%k4C{XR8^oJYCqZyoA%P(t0S8WgP}{QBsPjp6-Oh^<-|(%yC5*7$Nt(iRV3h'
    '7D$X{6uQ8%MbvmpGsKRwzgI`a<$6ix=mzORSJFy*q^W1e7U!$YYu}^>ZR^>2>nf_*tG0RUo3%ixbbIqZ@f@0iE|FG0Zn1A~Tdr6BY1<)NaA;5IFIs7^bFPZ?'
    'll1fR?!d*}=(j#6Vd=dNyO@5zKd@gO_>VRsqn-A>PYe84a+SvKa*vGs=5}qbbw4c*^Xi?YlCz8ZE&74y2NN`4^!dcs=01MtBab0C0rVHGG4Z-QqSh~vvr{W_'
    'H`RGCx44-}cE%;U-9UENKA_6n7&V={%gepjA7|1H)h)zBfY|s?Y4&sDa6250L_icPI|VSFPwYXg&UjyUH(3N(GJ+E7ey!CfkUtnNKTVW>SAPN6?PIMzs>=!5'
    'zz;B>&b@j7UDNjG>OA05npRXD6aC)2(roA9cA%}b;+Uk$6KPgnJ8fFINTO3mtLmhl7$~)A-MdfS{;Csl8~YUb{7NMLPO4~YZy#+CKu&PC(z=H9{bATlC2cFE'
    'Q@`kKr$PtEm;fhCUK^9dgQ$r*8a1tlJ>N9-hR}@0ZIJ{Tvps=kE0j?prCkxay6#Xtu%^r>B5v=gsE!e6Icc>!WqTO#hb})@kvsk*b&m|c|6?m#do7Y@??6dK'
    '$HUZju-z{-@-xd?FX91UJ!ouv`R`EgnXve*orgt)lO)DB)?e&H3@)1Ui{xT%ykmZ1D!=-n{qtJ~_|mY3l^b82wPt@E%<l{(<mKigArjBSw@qPnmzl(abryJK'
    '(Uwn1?+`^g52N3jZ5H}!#*uUotk4}ZybkeYgkQVoU)r2f{MKEf)}x>AcQe^~anyIKXU0e>#y0bG0m*Ey76zQ~vvOiSV5yvPY(u0rXf4al)Spde{^V<|r`rwH'
    'yHBTu^yd?}1ZB(pls4qqW_+2iiu>;Q*&DCrx>f(3Di@|t)h-Un)8IjvSI0B@{CQZ+m#5fP!?yV^R=E8PymCsmT-|#femERNc(mNUAr<U5q&OGF;VT)AB~Gdl'
    'G5DO5gnh0(erq@aqjRsF4Dl`UR)TySVW-9Rs}mWB<flrd>ctdX{w8anx+ou0y_Idm0ujT3AYG8gPKL*Jb~9A_G3?R{Y&8`t$=a){c|#aP%L<>|e7PA$#ZDf)'
    'VYeCqSXQa+c9dNGnD+ZsUsV$({qDlypcB<h<8Yz5(YK8I2Ccuc@#j}>j@5o(^exuz$}7j&-0tH$Q%1X+G`(lZ;r>2)yX_Bf-|0x{-Ff=ux2Tc$Xo>L~>fdM$'
    '*dFN$I90PrV^eqDvN#-H?ak+xc1ncCs_?dsJPAw&2fU3=6!*-8Qf9;1*qLuCoptRAZAN#vO>(R%f$Q7*-dyaf(Y&E<7UqhSqm%dbfCDqQeVeZpxQ^GZT+24w'
    'yBF06BPj$mdyt=@nBdcP?Kp)nWvBgRhNL`%O|`Q)G)}`vcqha8xqW^jFB<X4r7j-b)u<-SzB{UE1T2JBi7SW^NQJ<MDgFo8`tumSZ|#m}<j9mekJ_E}@_gjz'
    'v$Fi|6jRjDTkFsaxu`ttnMw;O8!a-KAIFyorw#r{KDL?mO%uHIl_Hz##gRc|v=Jlp7O89%AR1KJYQOf^)go<8%YlobOTXpfZvj|czwGs_Ods3TsMuGHsB(Fq'
    'f67UH7!BlPpbgaEJ1PP!;|qpe$5FhNV1?B^VCGcC^qa(|M4z|3PqkycDm;V5ZQ{PzRQ4rxd;-9qTcE^nts34$XPta9-SwTpZ!EPAQ2F4j5n!n~jTN(J<HCqf'
    'yei#qo$sF^?Z}Ak6X)^%g}A6i9s2Cxp&<POwFEys+;#%}=FV$xRcY1z`|NfqXT0<Qm6Qrk<#+hzn#v!%HUhGa%$(I!@57|fAAT0~q-hp>W~kbAI+$Yh^O=hW'
    'TU?!PD{_rwD)6^Ch}xV)u7*0(lPW%iC(JW?q)K!t4K4JoC{@84a`aJdnNVDRAW`z^o?$OnAKcUF6Rg!ixY+i$^tfx?hWP0x)Yco4GvyAr$r0i-oS}_h-JFC7'
    '2VCc~%07%HPn!t(^4u97{b{EWmMHQ_#cFd0bscw&ij*q76ZSlAn`>&pNv<;4@Kyy_Kf&+x597uSfQ8eFj-B$J)c;HpuWd$)POBo`8oL+DX}+yF+r0)?KJ&g{'
    'eru1{uDwR|ZFxOcSKg?xve)l0bEGqdUPhPha<^49@G)LbwRzaf?*2$0ha9(rFEg{=9n)T|-8MW_ke7v(aC`5Stlq|<s1I-BgT=37tJkEm9@|lNt!_2c8mV49'
    '?Zzm-Ql0ne7b2GMMeAQ$3SZ=6b&yUByFZYoq0HZlTOWQI!GK#YuI#$HMH;i2Rd+v;bkSUt{Wt=J+`akh#xGNTZn@;+uJpF8bX`cpUN)wP6qv^;)ZI{D9f_M#'
    'XN6d^S5m`Uk<}Tr-KZ({4QOrMCV(N=B+1$@dXA?m{u$6#?eVe%vL7fuh=bi|SWZl_OJ1UxqPp=H{qB)8-|NZ6Fr%d_EvIw!0(*zyGi4c^JN{Bbg!=O)NbcsO'
    'Q;2&x=`XVf@W!Xrq1gHV-=j&~FH75B3+=?71$tanPs^V97d&PmQrqikWdx&_`_T*Rfn8Ys8?Xe&a;>t*_f5WSuFMh8<HuCN?rA4Qn)~<m(509=`y0_OX=~cT'
    'U{x2x1#W}aFF%-t_Gcq+7>pY~5unETV{`tVz?=SOoG3Genxo6U<(i{!li#`RvscWk;J$awW+Q7xJhCk5QF?nf+Bk=+AWZ=#s8-b@d5ShwU!C+I79UT4&SJN>'
    'Z_km&oU~vtopAG9zfP|RM>m)K%yjEy(;Q8w?kBsp9ieV)`SSFjy<b)~=+2d#_KxwVqcY&H_<yshXEx6LZ*d#CyS9Ato*yqn-Vw)ZG^V2GvvO9O_<j+!zUKbD'
    '7UWq(0T}lZH|Y@`MzRrui~iG-LJgvQB5c0X`0@k2gS9|~c)Jd~`g*5e8(kGX$7g<FND`r|SBB_77u6Ybit#J&8<U{Fv1bo+zZ*?iHw0pa%P+~JWpw?VI54+e'
    'UHuX{W^+Nk%Te%z)1%u<)%IiDt<%Kpo_sievt78Y7<zKyiOMmj->o)pEU=}WA^c;iOGDV+*v@WLeY<B_m%l@KP`ljkAT83}Wka`F*84+R(dZ3vcz?J(TDoig'
    '4gFZ6)55J|gWl&$y0@FaABIB|#<tS9lD{5JNmf(3)_|aCuR{OAT5EJUci$0@9w%s<4aq8V5Yj8i_|#YA^7>TzU+Ev+0fRJ-a0gD@dU}+5*s>OqH`IUZiy1Do'
    '<%yovqUx<hJ!$m$CP9fj_1cWP>v``h<1PGd5oR%&(p~X%8~$&^x<dDTGj32DU$kGJk3sgZ*~!Jy)4H!I_W?C)PPZeTa-yx-Cl+sMe%V5sd%a@ES!W8de*o5b'
    'GK=kk4nld|KW#fllHPP)rf7_5<uz2~%J6DkzN?iGpD)WLUqJB?sc+CAl~)pPpA-Vj^946c)xnZ_JznH<d0KPfly%Ot$tOsv)KC+iUah(CW{YT3Bh<&#b)N2@'
    'P@7Ko5suJBD~`df6K06L(q^S}Sj#=Ke#FKus#}V#T~|`rg``5c7wvf;mmXSRWEFhltE2GItk!x4N~-oJs72V_fCn214eVuW@TXVPDSY`<_Ial=WyVfxzc}5d'
    't7%qSq{m^O9>F8$J_ku2RO6QW86lP9JJDPy6bT^uj7GRnoF~1Z5h;72LA4}pRLQDu-eAn<w~qbqmXU!cGJnI*Y52fncbD}GsG<mV`#88y9|rb<WuZLQk@Nz0'
    '#dDT^ffp!%`z>phkteW#HlDJ@ExOJ<n06)i!N`j<IVb+4Wvx<V19-02d+C>71F_N&&}g`A%G)Wm;!YuT&9)-|nUBc+$_Lm3R}XK08+*VU-(Bb1ETcIHbQQKx'
    '`S8*VzfLfy^#xH02Sr}(1MvDmG{{;GgkN(mnk9fy*Wa&Sy?j6O%gH=ihd9j2uH0NdmmP{H>1!{Zbtaqj<ZL|872nLDZ{<B};eY-}uV?#;8_=ojfa_-$0Kwg8'
    'SOo8`F0P7Abf?o<hqP|8GWM(QO3|cBJzGBY_r9lE8_~{__|;%UH?e{rS}oVt`-H#KeZ1pB#S4fkU+nOeP_}x#R`gD1XvRq})eY(Hme-EZSHS=6t{*|;(1@H#'
    'uUSH!-SgHXh%&PDCwHiUI6NbQC-J4lLp+JXPP29J#D+63iD+@s=7aj8uFKiARtH-5-Z8h7P#j5zexWw0;Dd{rFOqAXv>Z`3k0z5nf1?=}l(TyNr>jq+?1=xn'
    '8^t|?^Oy3na$+ySyg58R(>*8720DIC{wVZNxh;0USOOq<lwqI<D1Y+eKf`3$RSl`KEHGU%Z(r_<JXV?4Z1Lxiy}NtJnN|41K7U-#4eMq6Io)#o$boKUdaVt6'
    'c15k9j>rGazJYP7E^baGIjOrq7t0kV64k)rKCfhdGU|WiP;0hi($-pj;T8RWsi068?T?S+tT&AA@5P+44+#CjMynTg+xTZxX?;5^>EVy}xm_#|Wot<PF7o5>'
    '<wl5dj}Toj!1o_O?)A002s%ww=@*sY&F^A;`}vK~>34-(T~F`qMQJ*`f4-+@^XE>^Sr15BG$^mLE2@C)9o+#RtKIfOVBh(sGh&{h{a^y~#(}gA>5ZJd)1M#l'
    'Tp7OxY5%bpDMgU#O)@FnY*`S!=H=*MA@O6j2fvRZ&Fhl>g%^#93(le)a~#%d@5SNq5I0ml+V<+?=tc(zzU(hlsXT9lmcI)YPFQi+Q=}6(s0kd!b{)V})7g+Z'
    'li{^>v|C*oxIe`5fl2pe7f2whUg3M|4_|M;mzDL5nzxI}V-MykW2#iPZMxCJMrjXgZE?U$%o*nuSr9!AK#5V`?^m0ISX^OCTixAJLbB_AbuL2LX@6uSNXex<'
    'p1EVbRkHo>yk`sd)Ru|iwc9`j52r_T7Z>@=yIMnlK6nkEEY^5j%4YQVRIbfg!6WYG5daN+1e~6G_*^blOadRXR{0i=2-w)2($N{bZsAe7IX^CFx#W>HHZnH-'
    'vVmDQ@p;h@r8=k|4ksMJt?ZCaE0ARjr;S6P&BmvoA-9i9wl;cXMrmai=1;Zc-7K1~W^blJEd6L<wfGlZIkxfHeHU^2ar_xbPnp+4Qj@pF&BpWFs3ednIiA&q'
    '!&U3VX50-P>*!}`pkWh4_ghhUrqs54hP);Fe>kvcyP!H{GnA@ZTwNibMQm0aoM9wsp%@;YPbNZlw20_Gg}gdrFOE-G(teE(9dEBxP7mhur+@)&B<bZPG&@fp'
    'pUkR@)p;|VjOLKu<wgEg)tMXC8P6K}Y|8J^{0y)FZ|<(WYd2v3Mt(XQ4p>KbxEm!d`XYE2OKxfB`zsNAxJ8{gSZxqZl8Of{rQi?V(M=(~QF?a8CyvL3*0aR>'
    'wRT`@A^^8`+ZQ={nYndXhxSD`uWrl0xIz}eA|0HL@Yz5lg1wQq>|W9_VebcU4?V62wFehrOb-cuyn?3Fs|5fFW1W4gH<>5ZcZsu~CRVg=gt*>}g+=k)P9nJ-'
    '>aFX0ts~!EeLp<mqt5z9elBS;JJivWJ($~zW{QnFq`g1)jn^eJo}(;UnIeTh%s{?Xs#)~)?(Teodx!Vefa@?nN3N$niR7fJoHAmd(3K1MR)^Gf=9!ne!@phR'
    'rJF3P1jmJAdG`JIXxCoAapmja8Xk;)D|9H|4i#-VG}%}AARXefeES1@Y#Cm^SJsUY9QtsZ+Ak)_>|JypiTYOE)4kO89;aW#?PTuf`QITMG^^WLb?7Tz%%nJ%'
    '(CBryRMb`>p5ANi@fC#b!d?Q_HPthh|3b{Rx)$i5MYiEyeD2k5ySKVPS${zHFJyO@<zi<5HRb0#3>%eoylC#{O<8PbUcJNCF|BbNF}K?!S~H^_IJ}5L&or^?'
    '9BWrd4l$Ma6#lK_+O&#%RtLSuJ_`s9j<1QL-^s~xzwUJ#lxksYUF7k0*9XFwn#Vgsb$DvcuS9`<N3{Kkw3$3O0~vAr8nyMP(x6+X?V}(~9GDRkI|SHo^q!7d'
    'P@~PT3YM4VL3*Avo7>hdhxgC`C1*>#z)|y0RPWJgHEgVjdQtILv<4tuDlm`sVBhU`2j|To?3YXh2%m>>e{)XaXf)|gE6&!b1e5J(r)F?>NBA!R*hDJQwpe>p'
    'psgj-Z$qKkA}pkpTwbSKDYa`SN$ON!Q^@Za7m&I~5A5Rl34hTP+PMfX#Laxi9iqn5ZTLabLGn)RD!Vn#ZYT?uxxRD(%Br)IRffDXnffNwx8b&Zu1!erCe7(+'
    '$x_Ye*)J}R%8ws6VPad+vIh=;cr&`Udh=PD6E9nmJ5Ojg(oL9Ml+&(2wvA?JGwsZuozWRgt#lZ|a+sXM6=Cee+KXthBjj8&e;r)x?~L|e3VaU1MyU4jZ79o~'
    'VmHrmkS-4}WaCMNtu`G@11d#O?9?3F+#<>eZA(5E`1k-PNT>FD?()g6xd69IyITiW{mYmn`@<(>w`|9|iQryR{QMU0FRWuAhjKFQ!ra#XiMUyhZvz(1GG<OM'
    'YMZ2wPgHWCsd)kf%6o0JqH}F3O;53N!zRpH&l|$Qjvsa>udrS=)d^=q`yTb(n1{6;mXrK9t;WsNlb#VTSLd(AAOOp92)AI0SjOUbU{xF3XcunCixTbP#pIO*'
    '^J30rG!<fe(AlYpKAOp67<8`gy>1owWBS4e^rDY^7Y8b}#R(}_2xBg*@$FN8d_YeN*f%b`O<L_^Ko=A9*4;AaciQN$@FZN{Uyb-_oy*H^T1YqK<CMY?d&2^G'
    'l*4LUU!|A0KA8Radj!kR;~8W;tZ^;##v5Zh$-@tYtGH4Or}jrU@<x1F^)_~er=d%}GsiLZvII56X?&zUX`1dKVGgrTvB4S1a@#pIxl`V&*M}jo-yWYVLbkNa'
    'dV3kR%BY@89~Lxz?SPPWhaEUfF`B;ffh><A<S&goYGe%b^Bcgn5h^xCFGlu%8%h}IY818Z!DSbhw5hbV<47*2HU3qYz1&5z>?Sxp{dc^_W>U7!EpP{U#m=*4'
    '%k*@wbz17-vRYVN0`|mbGg!M<;!i$pY0_v{dSg1?(L-?CYYmy9wn2M!n=MB_K{MebJasPP>ilO9Rz;`+dlKsk_70jmo22%Mkf44Y@pVtu&Gh(M8>cA-%{ouK'
    'N?mf%DI!k$Ne;DMFpxStYI=Ry@2^_*dwU{PE7{;l{#x;FjV8-}3{1k#jUC)tlGv#Mih9sGkM<0unC)qI{b4@*=T*>r`0T><C0<Im^d?k=@#Qes^6zDS2BVRe'
    'XtCNkHa_gCo_?HGBGvb;lHjuoS*r@mJ9CbavZ#6uoUZ6L-!m=lx7?i3O>eMoO}LHK-&|S35!wr_E@QxW1nr}d#q^~3+PsYyq2T~Gs!iEyiWt=Q`RcsYd8p;}'
    'B_MQOV1B88BwsTGq+f5rvo41WGF@91f6qgh-^W#Gy4y8-qtoPeFG(7CsaI4^@ke?(H}Bv!D?7@bt#?1K7X%%_ugt`r+8Kk$W}RdUN<Sn$vW6y4?9jh1D-gId'
    'cCe-IS7NVgKQd_ZgHPQ3sa=L$<{<jKUricWWizc7u&(i0Bw7yRp0E*#90QiC$GcVXT^O$4S!#ygfkl_i2Vp$jb_)M$KF?%2%f9$tS(tK-zCE$l^R~WFpSv`Q'
    'pf+5ae-BFy#m3&@56jlZFwnAV%GFOIP&gH`j@iDtt;1>104ht5d7O1rE1-LG(SA0hxI%x<H7uN-M`S*lq2A)Uaf9#htt^-UwRpYotaWMf3wNykEo{x1*m{9{'
    '@7{By_110t=2TnMIL|(9kBE5dG#VYIW_)Q*J%(n|PC3{oMjlarzx;EYfn)BoDw0poPHqjHD=l?ka{Z}?Dm$3_4Z?40p|H6<Cj4`!+p(J+ar7RTYwVajPhkX#'
    '5Mva){XEzZj8^LU?mF90er@=foX>45-)YzEm$f+ayK4;n30h-f&Cy5pfV^UFEVJ66hY|A>R&uT_Ab4DO`EPV0N<FAMOE4{q^OA0TCRt~667Z4bx*v*Y>|b?;'
    '04w&<oLu&hTnnc?a*_l1qj&8e4ugHV|1)uNJCUocRj0Rv268a0y+-Ov;IA!o`*bfq+}++B0>ZJpB0c`VnADaXGTae+kLcC`oFCn->8MfzfX?FswU_7H53kqy'
    'Iq+DhPD)xk99XXx-nty%G;mbFDQJZ?q}GO<tIXNC!3OrbGjN&T^`-c{zOW92+Tk9&vYm^y>$y4mzOCDNvs(I<cc50;Y`p!AR<KdFiUX#n3{XMsv*i(w{xVLc'
    '8Kk>c=6CmNFnAHU9_eeZYYey1&+$50j6N;sl4F(cwoa`A&3SAHHM?+~dPRmQVM$kJmF0jny8(YdO9=Ok?XT;uvD?eo03Q~XOJaf6!<*4-s5+yYTbDRBJD(fe'
    'Z4fa3nbaAeOY{M-pvmFU=rzyl#g>-*_jy8Z=zEs<%pDo-FuNIk#**H;q~7$5c%kc44`}vz55wmwQPkm&84|fX8YJTt>-7jO@OGW3Sy1_o#iX&BcVBhZB=9%b'
    'yv-~t`<v@ze>=H&t#e<|G4fKZ8fn-y4=0PoQTjdq0Jc{F7QI#-+y(8oJiKz1MNx3&d3L2~e|nai^G&olSM+#teh-yx(bID014Z9%{jo!O+~QtwIc+$ZQj(<>'
    'I61M#!)i0fR=(Q;=I})*75&-4o{tgq>W&3O-;bM)lT+3jv5=4)?HU<7ek`}(pODSK&0k!0Wh0o$wQ)_m91w89)rD}UU;|J3j<m&nH0YN@W>P!1g`+;KDAxWD'
    '1W*2HlHA2VB(asEK9hi9jrT{`aH>VSDN77)XL|y$(`bmhr}<s@+&;_mFj_e6?=@ZZC+sL)V7quVat}kczml*LYbzh+tMqTlbUVC;7i4hTWaC6pZZCNRzI){M'
    '>pYFZ@Xt_H`2Ts3%?Ty~L^`KR(fmcnRe!HJh<`oGY;Luaq({`U3vV~}VLfEvoQ=-8sO5@2{om%a1NR>lV|GRw!%x)teDlq&#Wk%#Wyfj&3wF>)S9Ek?jVzJg'
    'bR0rM;S1B~x1YCXCrB-bCW0&eli9*m2Yd%dBz^E(d*JnsuW|Ex2Vo&kym+BYp?R;yxjZSwHORCA^kJ%l^4f|o*>3%%?rs}@UC92IsjMx`DTMK>hBLD+GE9rO'
    'ruf{refq-|uWu-$)qxy)>r2U-2ng>D?8mFDTfaNR9au?>9o(VI+Lpx{?!(7k>W+6a(RL~ok?b-@$a?Ri>-w{G&+oL`L)PcZGOr7Vg$aOMuq@Mu*bFJGKGpT<'
    '>CYr5*+J*dL||L@?z3%-1b4jAPnE73k(3go6(bRK*LV(x#X~<h+wu+(>&ZJ5n?u51Lt^7-bT1>UTr$wiasQTlBRgWnmW#vq`#7o_cVAhfkI+}0&728%M(Ev6'
    '`4DRGP9!YAs0ddJuRlq&N6-GETE7l9rrbXG;NcVka#VH4^-g-}Dy^E;tGxth@M;jfHPK|*ne5U3UwyBm6Z<au4{2K%WMv|=CcHNX=SEZ<^3s0(y2HygK`B5F'
    'AMY2yr5!1!$kmt{@Q=;)jci<QJ#&s%y|L(~-yqcNSGz8j+y{=!F>A>M%}BjlTvx<7D>MCkE-Ruyog6wk+iG{cFZnOuW|@)o>GRaB2BoHoyrb4c4L<Cx?JsYG'
    'y4P&z_!UlTv){YZ3QyudBjg}5;dzhEs=m{?mz4k64u}KEK(Im0>yWYVo@hGo<Xg1}Z?^D?cjg@TM?=BtLBqluEU)=ivwP?X?y=Eg*tmZ5<3dtKFQ}~i|2UmJ'
    ')j!5*fS-|XvsLs4fEX^Q8>3=Ci|<>$&$NI2^By96aG;syFz$vc)x^K%q_Z7NIvO%N3+8OmsEu#QF#yPwpq^?g;xg*?Nxy)*Ieco#e<pbe#*h<*=JXIkEn@%L'
    'QE#L)KIfN7BE;25bjH>5f)&8)@w0H}aB1KMmqv%I*~;H_3RlJ||H4@R%`Hy|{y6;|O`|DPKEk@Wn&<7|4=mV}K$FfR2mGM@OwBIf5vrMy{s=_O@fHf~)`A$W'
    'v|vk)HPAqjaJWi+ZXkTTX*8DeK<FG)wkpiD{>N5M(%xO8@DAF<l`suIGkJIRaP-tnM<puE|7tl}pE7zjV;+b8A~OtV5!aj%VzLvF-uY8|Ilt}1IT6cdr;hm<'
    '6h_z8r^IiwM?62@PGeFHiaBNkVK`Fo>sKARE@+$=Bzr4fbrjw&6eNugLB5N6^I&iZ<mFq#fI&g?0xqv#kr__<9Z8>Fms;+9@$zQQuGR6Ld|kd(n*SLm+p|d1'
    '3kvx!6{A|UF=^gA-{n}r)9$tkOY`$!^IIHUYxrv`1c9H2tD!ZHH6eYoYqP=0W(ae{X)~-ZpAU9obHmfwS5Tn=U*LrGPwrdIZaTMQh$?j8ttH%V&F0r6rSVNw'
    'Btj&K`f2PwDh(JB$y3m@@%U1k^~}jB6za#{MI~<%)9GB}pTFg7XbfzWu@Y4~wXMNy#-Q6M$E!A2S;QU9+*q3z<9QiArEmAYkkJEV3KNY*^`d5(;uF1X<6ZaY'
    '3MH+L`5(aEb8y$-;pQcd#t_q@s&g`M2gAkAx+kmaaQR+x^mNt#N$Z=@eH!rr5+K7`XcatWJ6wV{&MQ~9qi*+b4D+v~GoAE|!q)L}IkRaC!yTYaMcyt*IHVZw'
    '`zxD8-72X#+?t(scx^?}i87?d>W#rzX-V&xg50q_@O(Y*pI~4QGz~c=lheDGmQc1Yqa$U%=uS&^Yw(Kh;Pub#tjN*uybat8VY<!BnuGB6vVR|TYmobP`#s}='
    'Tsqb3SQUb2r=xe@^9k{Q@55aUK$ZDU1sH&)s;wQk4SfJg4|w^WRcg_DdpeNmN!_g`&T@2Dv|iF8aOc$Rj?GXzUI<_gm2P7z!@v)yJMn6O4_NB>?ac}=X>6HK'
    '0p{wO{w?V4Z)W1cx?Q_|C>DYOiSte&`ZC?DJNeU`$&vr%>SX+S>E+hizNUl<_&nucK_49)G!du$6}+xo2G@L8t3c9!Gf@W5qaV;0jN$iA1FQ^o>swj96TUG|'
    'AGYbz(s(#ldUEHOMlSdKSR;g2m$>dj#(alyl(@d%S4+o!SV>^n>J<2G=Y^hDKA_?4T3c6}AonM)b~Ao?_-3I#8d@0QEK0tpY>kJv2=6zYqDlPd*PvcieLsd#'
    'ztzhoOZTujfxX5M3B9SMHQ_HA)h@fyF1{L$W9DA99?VFbzt117>ccxPmS0Uy<?_5E4%+EEY}bxNw~VbwO_sc;E|b4Csr%7EwddcieYH|1a-~3Rb9ME)F&~_C'
    'XlYV`%{#v}7XB5pqoNv%_=J27ReubdO*P|lPDzzlPx+Zrt$wlY*eUDm55JwceYM|0-6`V<+FK@lzcfE~18Dq-3j*>gKO9iCR{S&5#O0~U4b6|z!C#80O{vy3'
    ')6MSquz&*BC<)mQO-uiMdS~$f4YuzZC@9b}>Mr!w;YoIHi^i%~EbEBjo_AQ|=V8zN?<pv)F#)w#`+SAnSjZsq=Q`ZA?|D0mE8KBTs388V_08j@1#amb{N4=)'
    'Nid(5C9P=5_c~HAnM)3=R=-ySY>B-5H4g1Va$hr-tW`fO2VIh%)@K(*O%^q3**oCd=|r;d08NBzy2K!nV6ycto|Hf1r`@=;aXFo5=XVbW=!JD^EPwrciEQjA'
    'TQ>g8(SSMAX0N<4_rS~clx+(U3_yF_gc{A@9rh+&A8TKqdPpt2b7e*pJInJo@5Q-r@9E5)%QE%o2<@go_ka7|WB3;VH#t2I$B$3=GvIBk-q6X66sN-A{_Rwb'
    'Tl~?7*YRB1OmFLM(3;DDx$T!1c4J(2-SFdghq<dA40=!Y^Lsb120u-{4wT8}W(SpJA5G0-G~c!I`H!9kvHSh0_2PA3PY&!~#XXx~EmMSJcSp7T(Ngo-${(mo'
    'J0Sl9Xd=S0?Dy<-70aq`IZ&(@=r8#VPNnv&o7(L{{s|H~LEN-8<ZPCy*wvrB8Q1vv2xy+@ju6k2zZl4+$)M6snc$Wlona5~{Q2EPZ}RUa0!G_Qc1`*1XRI4m'
    '0%p`)HTL;0WO}M*z%xNVd>LYjwR_|5_b|aDz;~Fb-?;hgYO=32=bANIbU(xO6$swf%jWz904?!>S+D7!>~)gtKK0bX(aH4W!6RLu_*tvU20IOC_i@1;dHpC!'
    'UfW~N_7!5^2RNcFGV?v+*cI<tKYn$mKRvOoeCf2DF~I9rs+|VQ^I9FiT{Z?zirtmo52TYPiZo~!BT#~w>W??NPI!W?-+~{Wf>?g+Zedjz*3b0A5{{AUOI<aF'
    'hT!tpVCBm`4E^DZCjP2Y7tWN)1&?euhGuVk&W`I-(U=`~69&)v)aP2XSzV9N`)B+*O6}KiVholY>HZXDvtbbf03m)7Gi{jmR_0!h198u2)`B%)!>pWvqOZGG'
    '=l(hO?M~}?gkiD%b7MCtwWPUZs44yaqe8M7ud69N=wDxX8VvLPtHIXH!)?Q~B`O6Q$QN&9NRv8ugzw?4l^Qo(@XLa$Q<@`ya>YBM%6<mqtDQPr3lp(szH0AQ'
    'Wze7f;-Srg>OygLQ{sBG&feL#eAvXu(S#l>CU;zjJhZHgBk3Uio=d9*__u*6`ejhB3?dF#x+8~d7DWYPtL2J5Y?kHCo0yPR{KP{U)4k@kFP>4Oe1a0qx|!fP'
    'F|x_ri+r90_4#EjjsJF3A9(J&vvgJdm7dA1X;Y1AKots*OVO?2cgk!$+a;exyV0{OG<)^n#;Rj{XY*{RUH@1v+`fvj4!EcDyJZi1=dnA{R-WLzrB+w#)5Q7l'
    '{odzp=UkrH;P&GD=J#B=c=4XptKdT3Ka6$(KOVb1C?E8h?tGqkbZ9qU3LjzDR`Zy2SZnIFsl0($koR3;4%ox~&S}x$tIzIor2^4hBi27+!S(`b@rW;*;q={I'
    'Z-fT1NJh?UkUb%5sAJJV`*0BKY>RY)RFM}SDE^i0RrcSHFI@r@yp6naar8L_+*=XSX)(WLV}<prAr6W>TrY0^_}ZcE;{|xP)LSbRfkPprik6>ezLmerEN$8H'
    'D7rm`NWoMlV`Go#%5Klqoq=N_Cvf?TJxuakq;8>m@#o*=hhJtuy5aFd@n<Fg6B+~Tk2z$u{$v!v`CQ6q;+;#Y0(zfC0(|JVG1E8Vx^fV$T#_Exl8UwcH<~s3'
    'zj~8`pY9YIK(m_Pt<6O$nZ~mfChy^1yV5Z)`?K2^j@4?HsNRp?!AzmzQ24OiovBxjQ1kO$S1`AF6Q$1Nc&Ips1dLQxeRV1?%agDl7*Oyb?w{SJG+XhP9{l*Y'
    'JrR2?iG$C5Psjci*mh`1OJ|ioSnR#qxH_i2;SQ>T%Zuo)FZwnl>)*!-n<K!k*GXnunjbEYUVD@cJ_BI8UZc{;*f$Oht9DkI(iM8-qr;fBC4b+c7QdiBEN~7l'
    '4j#3Jdtu=a{c_d4H!k&R+ip&K70u~i$N5O&Hn7tOA=3di1VrmlXZ{Bj^C!FCA*0Pbty-rAam#-m+q?hJLUR64gEW5PzEwGQwGkBDs_R+79~3Y@Q+dfjpFR2s'
    '_Os2nV=f*G>d4E|-w5_x;0xHX@ecB{W)X@0<`H_#SUwkEy2tH3^fMbO<Cc?SsV^g3hlQ`Gb;_B8b5H4ymX7`oFl^IrFC&a)y;48-f#1j;riwgX%<rB3d~96p'
    ')6tqgHfiuwhY$Ky<-Xu-D(sv0$z{H@{=Z#ykDHJI){o;Vi=xa=SfLkkJuMCTRXWvKdM}?5ePI07)Da4C!f&Qq=zux;khU9Lp;l+2NcW(F{*vJS&Zb}Y`Ivsi'
    '?h2V0W(b0t$&fu2{!zN4C(4p#@{*4x$Tl0WYo&C4H<7)b23dXeUJKWLD~DTl!{E+&vafI=)ub;DcR4=}r8#0APoS#a)j2*-To}B~me+lO<*)+{ZcKN2i$%J+'
    'MC!yxE7v_s+f)ZOXJ{|+$My}wt`_$snfJ_I|JV#`RQrBN?hSGBEmI+^y@e<slAbX`W(_i5ssZeN!QD;mCezwD1+c+<Ppn$E8V6u-zSi&8<K2!f;YVQl^s(cg'
    '*?<$pa5>D&VuSRz!k<GNcYYiH+ws$BXP>nVT|>H+5jYyEcf?&i4~M+NqrX-{C2?z6L~Ht681^0N(xsB-3{smJx55DhcTQTMCNuQJ=gkeay!jc`YZpyw^kzcz'
    'E_%rNFvpY^3e>0QTun6a_Y)HHPs|Uvy%#{Vk%i~w1-_CJ@XM>31}5gJ0<MM$e`%vTU*mqYMy=1(9?JVAP(33etFunkZkFYGx*tPRvptDCO1wPP%Mzpp)n`<+'
    'Hk3~F<H^*cZr1DUZ)!gX8gpG}gqjZcJVBv+#)kYJqO=7*i?DYe8KS_U+3M}%t0&jtXoLT*e_q?z8I9mc90rNh?VNRFx+VA&50_E2b4~k$V>-Ej$ZEgxC<-|K'
    'jZh};PT(3{=7M;q`(OwC)y_-6Nz@zk$1{fw6gG?1V;)bbV^-pfpyK4O^+&qNU`G^R)2>`km*ZSSZtS5uNI&E^YJ1_!>;(S$HNvi`iaN7k28OqvxHDY{{^ik;'
    'X%3b*cX3`?@%FfMr#<o2{1VkxZ}HimhMTr{oA)q(Hw|iC$d@5@fc63~oi*A`kIVID4yj3cRys+a><Tg)OPh`gtv+}(xHh){+>}xsA5H`E4SZ(=bQ|$3ar(hP'
    'SrO^lilUH^(co%QS+@0gHS4Z^j4Wxsz_i<$QM^Zb7Yjiz{|4l72}M6XnyT3^@DD+Hk?H^tzoKAUZl9~x*o<qvEt>zCEXxW|91fma45m02^v?KqYEspN`1H7Z'
    '4x;a=$oHvVd|r-cqw`X#aJw5|9YItJW}moFy#DAdiM}}A`n6z=--zMtg+8sQlxV0HR8GsNk!4!v=gVC7CM|51jSf2zTn)}%!m*F@*|_%A(<4>trfbpnH8(5^'
    's`;$NPHnt<KyTeq?-MHoO>!yJPw=lYQ6;YQFMo3*7r8S-w-~kft=oH_Y*aROw7C4gNoe2ApEeoM!f0N4qlJ*RE|bSKK>MV2Yd~zk8WqWm8(F`yxojTmc6EQM'
    'Zmnc{{VA9v$oT!#U#eSp6Jo^Rj$~U}^xR*qa1w4CMC(=OnEAm3UB85sfp(LzV2^*&0-2+`a`JFGO6UA=VEp^3qk!0uVCD3CVGX?rB=Gk=7NKYLF_$uy9dNZI'
    'eFRp66NR?VezNXTsZyhXOh!`^Q(P`UnvWF;4thH~$;Q~ru;{Tf>P^?fCe&F{x1aTps+ua-G(o7XSZwmWw}9Sc0{Qjt%@qEq=5^rraC+g$+&P!irJubvX%xXS'
    '=yo<@srNn}n>J9jHMv?AcFm6NuQEVak2HeoM*KaTzMV^Ijvo`a)zL+Ydl-6~bD^qssv_(%(nG~+hG4!YF2_fKs+K!4YWvV4x!k(ICA^RPIk7`lUo|$<8i)+P'
    'm+@8W^@62R+e_=5rV{?vWxER|#NC;_qM})4R=GLBtE-Qfx@nYU`kC#wCXIIqhf<oy_6$_I{p>^L%3sQ0^l@HYPrJ+pq}zRdwXcmUD`#Vsr=C2Qqc72Yw*_W0'
    's+}J*KU0C=60VavWmXpFuG8aJR2EJJ^)tTlBMO(-_{GPEvYnC3uCR0J6km{R5qN-D5vpY$|5MV-YA!1{POH1|NZnpmUkLmDx#yJzD#<^N&VA`zE{@{Y(oiE!'
    'GbCbE=s=`GrSeCT4hkhj&e#4vzxM)Adw<tjpEYLoPU$)VX64j8d$?b!D_T?*vs-14HGC->Pxd=*9MDm;RE`J#l<{19luV)Q%c0vKsU*nyp{(|}AXl2plBc!j'
    '5xz*<eR)wCm>0%lLc?}@@u!lNrI9|g$EkqZV_`)-3e|pK^24suOD*bMR6NmREd9c7wlXpQ=CYo+Qy|Qf*0ilG?dJ4qNDH{Etodbspu42?w=id>x;2dgaMkXk'
    '7M_bc9+`{dNSZR;D%lbr>Z|udk&K9G*4it%4W67~KRYI~jWUco&)aENtrAR`S1z^TLj3g{M{JEoW*IP1=XvSfhCcQSb-2J)W<58AzlJ#nIv^GzXJs}M@qzMK'
    'lFHb&FyM5U>^t$PnDbe5emkvn$M&Zqc=8+6E&6&x-6AWv-~cY}?Llw#;I`z>{)~rGI>YYhe95S24PvZ}M0j+(b0@xsI_OUgMuYyCHFY7kY092%Zy?%C4h=px'
    'eDB7+{7vaY@r#A_SJ;9-EH`;Ai<uxLl-Jnc_leuDL=rxE&5`r%&#9jat#KSX-0s%%%9pWU7yYo>@Ar<i!O0hC^VJUK5XZM0d3{((Ps$CRX|H@E7R@WlJ{~>q'
    '0CE2N63HX!W9{lg4?z8yRZQvYDEMJ!%FwG-?PGe<G2xC)zZ^n&7OTm&a$58eGu*Vpn*8OMW>LW=<@?<-Dugt={ZP!-qFOV3Ti-2btz0ljt2c9Do;Lv3JcCp$'
    'y_l@YH{(jk$d?~+hCzut>_A?Xlr!<pXLhw&qne2luScuDr@IJuD}AEpP!Y_%h2toQOn}v;_1P&H8CDPqX#!W`dSY>i`PHph-$zK@lCDW-hI#2~P>u_&E^c#f'
    'mpSuED2)Hwkr~uzw2z*5y{^ujqGnEt``4Z6zwOFs{r@34B-J@hZK8v&hcvS~@3WX3!@~OSt7e?qr_Xze4>|?ty~gCGwG}^!!Ytd>UDjZFt4ZTLJ#A1dY7MPU'
    '7JFoRM|b8P&#sFi$KK1$WAuK$I=Onv-RIfeT%sCiuog5|6GMZu_i)N7vokng^K8K&?3Zxr269GfOXO{20|t%#F0rf_^${y~fH!&IA-xLhrE_ukgvhvuw2<+V'
    'Bu?8$m@GSR9wlbJ_PczBqoVN68TpVH2_Ql!KBfKQ*3lkRL3U3%`_kia#o5!s&e%<);;@vD#E{aRPYPcjC&}A_J)wRVUSp>9ilqfT4)OSAVV!MXiRL=As7oSX'
    '6q>trnw|A4HzjN|Cj$8T&6Le+<~-0-fghnG4OYU@c^eY*NB3=xxy&Y|u^}}V=~r{dm2VEB?$k5K`f}NSKrQst60YBdhQNu@RP;Y5*AE{rVTZdv;%qOUUfZwl'
    'cFA6LlvQ;$tpUU{rEZKc-}a7~%p$qcDBV_loNt_Cjd}P4|Jr~KeCajYl?<QunxG=`1Mbm);<)#l1d5AO(RJnOXazdV9e((;Vy-do<m`?8D@Q2bufy@(-~D9>'
    'H6oFCHZ#qkKmflisg-E;*@N!K*t@JbiED7H#|sQMF-SXfd4el8J80d<K3!k+ucAnfS39u}Yw?<5aZ3E`CVzp-_>;$NT&eWeO(Z7!&5ayQ<(Z9PP3zyaK0B*B'
    'bNkj^!G<bht=m~89TIkBmccjw7)~~L{H(59AMh!)c1kaj{WB`U?%<b)^Ba}+E{idUnG}C{Rz?`2?3;g(8Z7MBb(ii+kOJ}bQ3RlM#n#oRfST9_<-9gBMg;rn'
    'W7q9a(P`%bPG^<lb-b-)SbJ&?<+;8m=CjKoUA_A+a`yS)_iPVLR#;ZWo6m+x5J@wiI$vn!Z%92KY<IOYl^<UI_{JpL6~Dphn$2|D*&g?j;4Ty^(y24D{>NFL'
    '^<@c+X`xe;qfpW9Lvs_S4*<J-_0v!3?lEKzyW_(hi=s|<hU_P~w;K}qak)904nk(qEaYW)W#44K@1DP{hpPiEUQT#<5<rt8NF9-3V8Lkb4sEW@TAi8#QR2<e'
    'MW@qYn9epp_0^4A&M&7v@9VfMV@-cty>nPguCLV5bYM4B;)fQ4KxBOG`0|Z|a~-qpZGUIcKF}D`-k?!80Bp)h@k^~OiB0=fn^fcVMx1!=xb9<V8m%9RS*_>C'
    'U#owDv_)&Kw~KvHJ)VZUGpCxdcDq!eZ?Ie-VH+^JpQYLBygCO+kRou=ivQZ>Ws!HmH$|SJsq2ekyQ+D-^Pc;gxmdGQ{j~eGms%bY)#sOkk=Nz$y^_(z&&*%_'
    ')loyOai^R!ThcW?A7-b?XD)pjzt(`E@9C-cm>=zH@M-61b5Z$&`|Z*C0gya|ilDL-vQavy)zh)?gPP0RF9=@iNXCmEP@^ZcNoU{MSnsR7$(cG_tjfh?B7Fyq'
    '=)4oNDc5>H+9%<xd<LFH`F;prf2B9M50oxIfyT6&uv?3*%=g2g;|d?&FyIg0sZWMNd0<zP0y<ZSrYV#}%-@pD%F&KXFk{y;@cKG$E5L1R&^>$b#<W<DifJ$E'
    'illyAK9jw^eiHSmyy;M3E1{&)c|uQaO+P8lnJnx#urAzofWFKv)sAh>JAu&EkH(#vRv8ogjXz%luvgtNtLtkxKW)uewpQBTv%)}H-7BYlPqfkV>ypab))jBR'
    'vY`PcAAL1NU%aaYEI4{C`~3bG{TfeQBPZ0ka`7FyiL>ffCbOWcLLE1HI1{a*Rxv#$w~yoJ)&_5?M<m^`D$cRD>CWALtv#!;qMc_;ebV>Q+AwXCU}pyIw~yAR'
    'r+u}<eGS|;3^b<(!w1Q@^}i|E#lHVAySP;cFk;n5u>7*do8?8GkG*d-64}VvED&qqQAitNd!(JCNgwdHx7nwwx!mBGI^;X<-eD%<T6+#kM~eHboIcC#UtP6c'
    'U;8)rI?sWq+>wWKgbn@AO@gEwDHXBvLd^RYo8{5PI$vGlWp_{ed`9H+-O$fsoE*f>{IFZTSr}tk5ngUeHhKD-gh|^b+PN$H{1mF~z}F=)?h})5ZOgSRObVZ)'
    '!#h8ZMtCt9sw<d}>^AGI+(}HJH4D_a$tJKlcW0kicsHqR8>a*2%<ueznYOr=%8n139`@gICnBu-o6?8FPm#T>-dxzx;)tr&0%@T7`*t{<e5=zIAf|TPi4+Dy'
    'sw!+T&HPPs%o|O6m|8#8wwqd~)=SWLaD#Xc^8=W6z<I_$5BuJ&u^dOw<>f77E4sVKyL3fdbd=}c$JZz7DCV=nFnlZijx(wY?sR`w1I;Udt=cT18#UKSUZPB)'
    'itKg-R=nqtnRC}F68Y5JSs7&l059tEL`ZrzuGkU_Ny4m`O3%h}*aKPZ_4aINzS$aX$y%}2U9y+50gaoiIZ(t2j?7ndz}TpV(}enxq0y4YwdcirZF<6PxV;Z6'
    'pBxfMffvouTdiH~@JCa!_&$y5E{x)4=g>0gUr{cWdz;^h<CQKv!9TV_UZd@5Fq1Y@UHG<B8Yth-$#cVX!>c~qft}5Ai?nzam{*Nj756{C=bDtJRQzm>l48bN'
    'jN?j~eMn`2RO=YMXf=##&u4zjS(w$hH?&p8y1Z(gwAs)9^yS{AzBq$5Z(FHFWT^!suUHrBo3SUm@2BKT*TI<Oi}5^=b^ew7Zsrr1@QnT3J+1yytSu+;?#8wc'
    'ou^=F0Xdm|E<~QCf=MD$x7KseQOQR5B70P<UBVs6?`(jf)v})K`&@Ed`0*wc&*kWO4&ekbl1sco&;4k78kqOA-khrUVTp;6QDy_mQfvD_quSBpR(-#iN;b(>'
    'C`MN7PqjAN>YYhJq;QM7PgG@KSP60H3xA*@^{9+&I!oeUt47%<V@Is;>x{dJSi5#x9CEn~H(oZ~3S?{47qfEl-1c&MH`ogB+8W=>#Q?_RK-DGvq3KgL-AjEr'
    '3WsRi4ubxEr&d?YrPYFu{SX*80*JadxA&d09HAeQAM%%)4EyxvwNO7wmOd_3YG`lo^2cSXz4H)B=u?zBgK}M2-1fgEh-!3I?L$e5bVqpe)F*)+6Y}S@TdPh$'
    'Ytd)#k1XJER*4K3Kf8QJJxHtGUU`vxpJa$VzjD^EDQ${A5FHvx-d^G3+G=eQT^Bv9X)8D{r^kLp)uFQW%O@P>*X8_J-b<0|;fnd3_9iG^J)O2vr!%`V4ejYy'
    'U3wK|4MeTV*DSs@*EcXPrjKm9t;o=oUyQHg6VINE^{y!(leb^3ylq9sf72DtTrg|`oVg1>AGb=36xZ9;?+35fs~^3CkC+Wn*YIx->e{N5U{dXvtYun-`S$V4'
    '<P{J(<m~VSlC^0(Y^$pz6!>|QKYr`S$e}go(mai*c5ibrhO_l)CF#kE7|qJ<#(Va?t^J+x+U=<<ovOQA_Tpwc=f{tmt!)@i7}gz!0ePPY?Ec6-aK>-?b6aNR'
    '*5CWkyyxXzR~j8R^=zBaw2VV-Yf!3(VtwZ7G*knSfifv><a1al{QT>Q3b^h@MmxKw{ot>CzIk%-pr>N18G9S*`l8$ia<#E%$KEdJpxWNwW;qug^5^rId19xJ'
    'Vb`dkY3-#oS<6WDo2FIK-i;2w^Kp;KLt5YA{><Ea!ib)mD~h{PcH{T%-ZSS6$q%yJOr4b?G(K+52$z;}<ni@=k8PF{X6ND+pt%|y0j_%CH(RYP-$pT^QRYka'
    'QiYNlH_=&6XN^w^$e1=xp(uiy(@wXBG#~ce*C%#AYXHyFG<uZ|IUPskv9aIw%jK<J0ZzxuYGq&-FP=>4N@FxTqhr1@a0MTzdk)76gQ?2VA4WNzC+|3>+bw18'
    'hfKS|^2}*9y`8>>+)r@fu8nW6_t!SYVp~1;xooE|4n4opvuyEO5yxFQexA!){}sx5P&>-w3@z~4=C|&ZhSTq#dh}zYmIE7aS+b8{lP_@JGDE^_+Y!vX!r<9e'
    'qLj^hjT~8W%ZrdT&m~Zj(+*cZc}%04W>$m$bLXwrr~LL64D=^k3c$YV<2&nZ!fJ*2Qk{(HLWNf}9;eADx=dx>?Jm^g`t)eFpVvM7mgdES)va5s&KXV82P508'
    'rKYB|&gRC8&+r8=M|G`+PewRy@6*PZTtc@te2efh2BkaPsWC0J)vbS)*TsoskWiLKs!wc2KwVgMQ!0>jQ~Eqkv-_zj)V(G3z*RQok3iO<#mrvvi=*@IusexC'
    'pQp)Ls;eJiUNLLBJZ(HY9HTDQhQsykE!cH0352y+it@#_jjjSbWf#luZ{KhP^~JJ!rGHX*kp=0*nS&Wx6@PNxDh}-Q_}HI6u%qB%O?Ld2d%z31D37b(RoR**'
    'bg063wckhEu14Bpsf@bwci?d9uW;>MOIi)B)8Fs3)=w%VMo;}SxvZOND-G;x*tmYe-btA!FFCj=19o+nTrs+6k}wc})t>7PUlsh)>4U4oe$XnnU)Oc_)gsA$'
    'cNSvbR7vH_?)0@9_V8y59+vl{-xEk<06hqjjME9--uUZ>Aq_SBK5Ym1x$1!R+6|-jzlO)BbN%u+Ib^$@@tsZxY7f1yGt0lGNAvpVcG&h7yfS(E%fqhm(|a&5'
    '#Us59?*8JbiR=x}0DJ2`pJAE3)obQKG^;%dwPwu;`{+H-3#qyKqsXB$CT4?o0<llLDjzmRMG|{Q;$ExiD*%4ttKkGJbN{*Y=B>6)?u3$*)aUbdT!8TtCDL_m'
    'ir!D7{qi@JA1q?j4$t3eR5^yP7WVF)fSdir?`t}K&-EZ6R@}73KbP8PQd_)azt`$xQJ6fx?_n7|rpOt89MrT6aJ*;p(4Y#oWKG{mYhgZ0+p0mV!`X4agleNw'
    'w=!=rn;WYFBqf%q(#8iGSUR1kivuK!Z4vM~Vs*Lc5N)*zKwP`oJ~a=n2QlFJ_8gjx00E|A8@trhqS_e5&xY}!%wt2if4sANowvPswBOus?+?b!Cy17yjSoXk'
    '$m;H50aOkt3clNE6b11hqn~T7pZ7>Q;qdUfx`rUum}TX;O+TCCr{(oMxuZ=zze6ocdfgvZH;=Ys!>`bpL5a5(@2et#vpXk?i=av`vHUT6-JtD)A5=P=aqxP<'
    '^C7b*`ftVhl^VW+*c%Jz2mWaXM@20`>?U@WXN7{}!M8s?Rj&;#8`S&Z(4~YvDyM$h5TUd5m^Q(l39%4&PYrou>@I6EAod$;y=sh~uum;o_0t{no(<~PBkE!2'
    'c}Uu`{iN)8hfsNefm|ITm*NdXW}ASPbx$rXE^kkN=eNkxKW{4e(Gk55N0X8py{`*zal3%4v%2j9Wi=<RdqC#6$xk*PU{rMabcIA3W46aO_A$MdRu=*Rk}276'
    'plQc<EI|R2THM3^dF;Hu_f5qH*B7`}rn_3$P<Rg}6zfs^(VLI0(;ffD!>P^kdjEJB4Zz{<-V3Ci_hO`bL;16UVVXR+BNI)q-fwt+ybjxL?IaWyKU^L4_X;8h'
    'r3EIM*ZUqs?Tn}mgLXnvANTu&eQMak?(qH|8l=JzKH=f%+&&*B-e1YJnp6sq_}R8{wK9X%3GI!imcQ6^YY&uo1Zib00jQT|0hkWtRBted1<!)XkLV_M%LCl9'
    '1u4`8aqSX+ibvMPxuY}x0n`2(xEgUQ+HUT(-}-j!2PUb?C2`dGk$w0zHRjRnSH}@k35Tcl!}Wkaj_%J|b<*jRlY{ZD9K7GoxbSqp=+uZhoZYe{UQjPrj_Uhs'
    'rE*p^Ro7SJn(#V5&P`wm?M-$kRH_>!k*}E0^;riE+|~KM{>>C=@U^$^TKpir^#<R%IokcMC!|%{zSy&x2o-hfck%%%Z2{Y6uT#6+{a`W~<REfeUv55cZJLt-'
    'b;*@l+pT!cYiH2gs16^K4%N)r`rKj}A6H3r&%o|8!|`i4pKOqeODLOdyHCF0`S}GJY=5~%hChtHagTX(GaILSrK(Wz4&@ecPd=SMl0McEp(oY(4PT~6oxE=D'
    'yL%<Tot4F3$<6#C!f;q#8da>!ZrYk@JdbFKH!Jlzf2>Gk*TC&ZLJ5D-D~|1F?PpFZZi~M7^Y1hXZxHzXG@B^<T^>=F&a=x9TkczjYMvc6XEv{55y+Q7+|tgK'
    '!)^;0>vSgGnIl)-HIOEya*_cH^wq+%bEYki0}{pK3tg*1>*t!axo%zh0zK%vpDE6808}OjEWUdTSN-!t)sS8@Jl%(xD;+84&0^XQ0X#nZBtp!+GFxS8BkNP+'
    'Rj|(1&DM?b)UeeMOX`JGb)93HpM7}@6X`G6*cbcST&$*Mkljk3KlfQo83SXt{F%uV9bYGqv|=9Ro#_6a`{a5lT45#IJyd+MIMc;!BoC`>mi-l+?><fjhtae{'
    'Uc65<=BvYX4S7A*vlpj=@2{`lYP;)>`OfFH&eZm%R0OVpaeaF&@^CZ&BBbrAe`>P_w3>fs+$SGA22TA=A;J8Es6&DIPT=DboVQ+_W@A6D89C*C2jsESmr_?u'
    'Dr$J0_H&4Z(<3E1p_kW>#boZPhee@urXn!?<HqInrs16PrqGjSGwk*L9U}X>+Sj&km~n|1wLhhe-@@gIV%Ahc4jHjGs@C<c=|&|67pFF6?(J7|eRu9~V{Zl%'
    'rtH}hSHYHF^fEo3u8CNas!UtAx97CB`=f58Bu<WVEY|(9PZIC2IV*=Z>B#JLMGXCDs}Fp;tMRWp0;y2<l<@GnZKY)_HIX|OzV&6Z=S_?KV|yP=Z(T}$%z#~S'
    '#v=HSl!Yi6C(}!htUknFKCtZp>fIEwA%m;qwOz!<ZTNU-gF&5*Ye%uVT4MJ^uMGgk2{@_M8!vOosq;@Dho`>x86Ni9X)y0{tG7z*0CH1XCz~cPa6a=7>h!hX'
    'SqJ6a_Ijw$YcNVS)|~N(d%I9HUKkTXmgr#`%Z@3{^vBbbrVB63^}nX&LSdsXo0V!NS&IwHft8=OE|d?8fF9pjN_%l8cRwW-4Ypjxo)3v?i#TG@=zaFSm9}(h'
    '-!|KQV62|I>wUDfYtOxI$=!D1XRW*k$A86p;2oVw+?n}eeJ>5EFOF1~((gF3#66S3h1oNUZVzaJlaUt)Lz|vmxMvidwdwFcO_$F@WMIu?YE(OZm78Fv!@E;U'
    ')JGbwsM`0Uk7hk}1T|ib^kD;fR<8-d76radS7KU^9@VqmseI<S1jOYhM-`)OSP{unC)3tRdZ~~0{r-Sw-@@Z_9uw_B75}W_?h80fj;}>`rv^9Sc|O6G0Y1|D'
    'U(G?TZ_E`T?O;!{bU31E1CP{CtvB)CJEXqfTF;;tl=4WQnbc0*&YmcSO#T@A(ln#)--}Iol$q6qjbz@p*hd2&H56GyHWl5?=mmiA;ZghnBYl)!F*FH`@w~H6'
    'Mla_3R*@^!&<DnE7o#|LYRQxCHzvZVhDzF|QG3)ThVduHIa7BM;YyHa(BB<sq?YJn6Qzd6QzlEP3=U7?Knv_)Nq#%Kb3k_9y-9@6F89Ym>wP-KK(_k`bh%%l'
    '@mv{XDL~J`sM|jjZ+cO6QnlBDoYEjFnKOC_@(=8wGX@DJmj8vKZ(*KxM+!Lzlb9El!`)=kjy?w`f58PeM%HLVx7@qVn4gEmVD9o0O@R+PL#=UJs4S<|{n_u6'
    'e*1Hqs<-F!+FZs-+Eh_rB@cxR^e&dNv)#{MMM0^wezTy#c)DoRmbcu9o$P7+qHzey+S$}y?eh4l-R=JJ^7-k6|M;JS{tC<RrK+!$>JY(@S=U^{I`tk=Z3;tY'
    'b+B^whw<T(4UZ4&4<DqN^10Tf-Je2Qo&9?6y7$%`or6fPC{VdsnfC7c8au7;24=XFffd=GtVpt>_asNw=FV(P6eGuFLXO>dTqKD*kj^Tc-`-#Y3ATE-tvS2u'
    '_U=Orjo)^+0xsbfB^ubteJL4Z<uH5fFZR$R(aIJw(<o@U_<LjRnGE+Dl5VETol9fyI?1TthBHpY0oi_{Gky%~o&`6Se;D3LMtY@=u24|DU3v$3fV}bJU5ZF!'
    'Ve#I;qN{Tl>khPLklkjwrMaJdmAIdcCg=gw4m7V2qu+Y1`XL-QEo(j-^BXE_exJs7I-MNdDV$)EioB~o2FkiT6kUKDJPL?marUgyjk*ovswzT{PkZ(L@ln2h'
    'h?=j|gkq2``L4L9?&Nj)yOq6;D<B7dm&t|l{;HDv>HuL>);@ScWN7)jGoF{ux*{p>E!$Eq{-@|nb5u{`aK(3S@hGG9ZjzTTn4{RJoQ-C>am~u3X#3UX*dMeO'
    'o&;5fslBmUmT@{NDg4cnG<Ch@Hb&x6D{h>c!H2I@@BJ#ur(X<c%p`vDkf;tyzlzrLukz)ZDrn%ES`{bXtn=ovGm18E(%3@h#$#q7Y%jTQ6ei+X&kzf3Jr;hQ'
    'NnVC@GG88WpfW-_oBCiEc!ve8ug<OJO4(UB&^vAxr7=|&1N^USy^riUSC$!i3+dfoH~WFNa0X;uiKj(R6-i>qWY;+A#__a1$^x{z@6U!X`ii*w)Ogwn*Ixkd'
    'o7DUqfc=JRj99ZwJ5#(noxKOScqz_hEAvjberI5&lieUPo&wd#lgaweQ6E`Kxf1<(^f5B&cYnH409fOf3>7ydpr}B)?_Oj2x)V>e$!E1^Y4-$2@T~L;G{9Wi'
    'NWu|BcA5bDE2C(&#Km$0Nu~nm1ExIEo!j3;Joj^Fe0(OE(W_}rGgF4@zD|J|vw=3SYZ+>HGd~a$1Q4eGAE|={!nRc<F=O-Z>Q!fNpzBrVbg12b<+Dl1mp)p5'
    'b75HOc;$wG#vQ!)1j@qg9KJo;&(Vq_=FA<dJxt2_X~k?R-Qy|vXkU5F3AN|NYA@E)d*usJ@l9?U<eHp++Otdv+wz8pJ1u&PS0?7_qSM<|O7$cmZMYB$dJX;6'
    'oD9*$*<E7p^UwD6#mBq8@0-WkT*g1&V;Wo}&f3Fw8})_1bn2j==18b_7URDiY(DePchqY5zx#s#omKnwobKRTWmpVbTRGo+lMX1h+unC@aOf70r!NwS)va&t'
    '<i>a~lI!T1_`JWwL*7xfYd~DPtyKw1q|k0tV7c~A?R@X-rK~=w)lV_(x`<?L%<pTFFN0yz?L7zA;mJ9N#k)FF0y{iapLbmsme)#b<1ccgl=+D<F4KVGwQAfx'
    '6ifG|iTZ3&1t=DSQok#Id9sS;<N#XPmpu*@+jAmyEChW#SYhc3K)YOHSmJ!=7(7ag0d%t5m1b4iw@34F+IDsi&Km=~T+krfbv7_gK6=D9IQ;%uRAY+K%T7t&'
    ';ED{5n2c2zF?{;#=ykPgmvL=YbE}K1^xTzqZW-LAse808W~fE;*TmjZX{D1Hj#=z_?rN0uT>C)u$DJena`i@Q@%4fYeN|i6Gue`{{aQ^BcV4^A_S9CdN@Y`^'
    '-zSvJ*$=fT-x>UHTIX40I|EI&yYIf)Kc>g=dOoFIoBKS=yzhIpIgR@h3AldMcTjBUXX>u(>E&aW?$M<xJHy;B6#!PM%l8-=lzBN=x5P8ICnwG`xsJzuVBf5F'
    'mttxvJ=uV&;S#NuFRcuWHMXTbp(gS8>D1x5zZH`N&aKektFIk=oNL6aQLD~knm6#rR$<KGT=9;ji0!SEYi9z!fzSIR_IP_sP>5Si=6-CFo1VUkgXT}F2|L*l'
    'f=RtEUWg0&9#~uwwZb5Y*OXzz1Z2=Fw3eBzZKwhx)PdNw85|0xdXUbT^=a%XED^3dC#$;9b_fDi7BqLW=EY~zrzYnER4IB?9O#UYH419GbkEPeFm0TuHZyK2'
    'T5&1<)KUAKF?Og|&HF)ZBav_fwu6^tEtm#hcUPW}RJCV2QHn0_z=$%%ex_<8qx^fj9f|mQ+_BG4@E5HEQ>`QmT3SHPjLy?wdLgv^FUqD~*li5Sl7RjaO9^WF'
    'mQ7e?V^91Fv8rx_REK*X^XWrHWxM#!r$ap}-(FQHnI*bFAaOLG;{c`=$YV>-J`ZZh+||o!3cEvZT~V<>X7Ke+Ebz5IewEPR&D-~SK^cHG8j$k_(Tga7&w~fD'
    'zVN3LGT>{yPnZ_>f_NOaQavxNeBQ-|9C{`zMz-6(%g$x~18H=A`8W9Aw8AoC=Qvl}L6mitCr!vSl{c^BP*8Lw2|`SKN(S<01lL|0{M4hB<R;Y6Y1N;Ka8jBm'
    '(X)X^eg2>-PnjzbNv97u2*D-NSZ=x*@;=)>z<YK1O}5*HCPag2yDqIe;6XFj>)BsB=Bnqh>MR<#iC31v$f-5OA$UKrz^-HQgYF1>0+sJd=@JQ6ugj==UsUF~'
    'rPdE}vrYoGDc_FLyt^6Hu=)t&1l&~D;0<dP)u0NRrNP_LLs+wJlHWSL3p}Yk+v$?7#hdVu_zm;%Hj)XWB6mmv(`O(~Di@k0kZ#Y9tmtsVW_~!sWZezEuc_Km'
    'wUzWqnOOtaTA2t96|C?3OVAm9i3~gUHemSh3?ut|vs*<ODQkPUjCKaN@KD3AK3h2^*b_jjJ)Y?ZX`8V=t@+(7)#{^3X*bL+<QMzQUh6jufWMWWH?&s5CcX1r'
    'rlr$6-3!+>RS#`-Y+%2;T5nH#$!%e#$GP{=n~<LTc~(_k|MUeNr-O#v3Kq?s%3jOXq^jrR4br8ngof$2+rJa{wp<>^8#P9FczWprU32&`<||Uee_Ll<FQC_%'
    ')cJHUGP$!Dba<o$uuU=@j@N#(C%s;a?9rI;yUDeM&K~PmFFGto7b$Ps@RoTfmMr|Pn>^;;R?#Kwbg;qwunN3~Sjb&`|Kpy>J$4fE;5L`(3h_-A!LFmd?vKaa'
    'PtX2HZmDyB_zYsp56Bi4nBPz3E<U5Tv!21mf<Zy4cZG#Mf_ov~Hi9|i@UMRNWh$c?w;dcHpgRnyC9<BpT@b7q2>?#7i#=g@L(tErVe5B4xBfyE^9Ll*+1UM('
    'v{r@iT-xW^wUX{2cRZ$c^jq4dhvBZlKCmECfKAMZ%{t4UT6gHJ(Aq>=Rg&4sE^j}p+_3><Qo!1;EquRio}Sxy*x5svjCKd>rH5R|_MujB!t0;WjM?J7yz8xM'
    'df#yrAX>VJ#8n9Sv(xJ5JJ=gvdn~m+ErX`&qe#BlmfzI~;1%tN9!_)yY~Cj1@Je<2%U^#QWCMOTyBntoN_MZ40o>Uq$I)Jr=E*A$lrI%Q>t9q1f4HNYS@SPc'
    'x_cRq-F2Ju_duQ6Ho{r6v{crtTl4pP1}&?`x-i@pSzbKRr`jTMuPi4{aOr4`DK0Ogn-{x6M4NHO)Zg&kNvCydR|jM39#SW=RPJQhoKs&rs`tj@;nY2Qhqz7_'
    'V>Y=|6{S!f_BWe6zzZ?oMhi<Df!*r#ebL~0w)JdwwLKLbK{N=ETE#u<ciR72n_7iSH#b#8sWm>GKxebMyfW0-jT)1Na1va_D$H4AsM?w-YV`xbgVoN1-m~?F'
    '8~C3Wv7unfCgefSn(h`>kyg$AeBlymyC{XuF|fL;q_uDL;(8}Ly}ijorBB}CyDF%e&@WNrmJnNnqO9s^aF$;C75GA)li@=#yb-^Nto+vA0b66;K3vLyoY>QV'
    'DGwHM^yd4Al#1V2Y+%<eI`4|pL%(QR+~!BWM(fsUuO5D|1o(64eL-#u$F8?{^w)I;o%*D;<&&j*apnd?)oF!o?DtJ%r8AY^Ynw_p{<)ppZ}{nKb<b!r=r`)n'
    '38g&zE4@jsixX4&(9wd<^dSZY934)^H?Bu#?*3`K$;OLmE)X4v2a26Svv&V?P);L*te%)bG(d5(Mdq!#4Nk^QwxhcIpDHOcKeU{-BM7{h{|;K`p^cP9FTSJ8'
    'w2Gr5$M{T1^<?!q|50=c4USb~y639zO8*)#AXTK>cjcEyPodksS?W;&>!{y-NieYSDkBm5lqd)GqoLPpLuh{nCh;pG$^LlBH`-NTRvd^^Q)<e}r@F|%llDEK'
    ';h?XA@N;$v6=={~QiBhp3g-oS-{JKO(SVujayBA#s}B$CXAoGh=9Mdb;W5&4!QShg)dl6h%YjoRP-NeJ3(}?KLCo7c>SK%q{)`tC+#O~et`4>+*vow~Mbi}='
    'cDHkcS+I;J+&M}aiNpCpnKW{sR%?VY<@zV&VRzi3S~kWng<>;~T+ZG5(%9VIWiV3YhffgnE~oO6&eY+!Ndn$=3v3JyEHe6R#;bSMu`V~T(s$#sk<Zw%SZsJ<'
    'H0s}(m_rKWI_L=4m&;E&xSW`PiB5s8AU4@uS<X8QF7UAV6Q)Yt8#wgfSIHaEkDpCW7oXm=@$M0<1W@M*`W7Peyv}df7Nl@)`DZL!L)>>EN#pQ4-1C%C;q9(5'
    '$qveaJe+1hP=UC^h3?aZY|6Q#cB%IjW!vqyv&YE~)a$g%{!3|<NpP*411J1AN*`O5s^jhE$Cn9o$MW0h6Ite)ifjj`KlrD@r?@y|_hPqmpT|Dw&4RSq7+Mh$'
    '-$!h$k|PsmYMhZgKW1e=_bX&}|7kw^gDUZHw^|e6ShJRq;J52Re@+{;O2gS!y^dk{p;yoTuFH$ejOo;7!*WV^tZeH1L(Pbyr+UKWvKr1Jy(V#NVC4%ox;9H;'
    'n5n&kQM*C6;_eCZ0BgL?cfbwCZpC=a<EN9GuVpofP=Ia#W(9px-t?U0Pe*AV#dEH10B$FUn}jC2wOfJ!x1M@NpeVK*`Wjf5c343+MUOd0inG5C^W`=g>WQmy'
    'hfI(R|EzU3;rlBdUi~*f4H|tk`U`FfQG&nfPs<N%2uI2lm&)TbG75iZ!^}?{kt|`{D_v`HWJQgb<l^WdHtjy7eBX;P)o31$p7?l&`=_EgM~wa)jA(yGhZh!E'
    'JP*cqm`2e4{qBnG*W>eU55gih!uE$aR0p~Y!rkK?nNE#lB=4`&J6uJaLAKM8xTuMghSTBoQi`?bu7#+b-dJayp$~U%>>pqp|5BZJrSsRP=UQjmg}b9*k8}=^'
    '_IZok?eUz^m8LVv+f4VpY(>vgo9S=cA!zkq6V_y1ml5*`B!6H+%tHCP7~Pg#BDyV5?&Q=33U+0sUaj5;x_?_?vCQMpHCfCX_r}@-2idov<x_Wn*BhGil4(~v'
    'Dz^@5`sS_rL>4=O02O;Uoo2FrT=Jj32^zo#{`8>y`guWa?N3IyQQwp4JkSQpaje2<1g<}ttfmMtW1pTr=$SOymCNTUEGO{FYEO8$%0S%2`F@%DcLguV4hAFp'
    'piu5nAkO;j#bq72qdf#a-o@FbJ2Hg}%A+<JmI1p{DQ<OhRC3U~cREdkhO$F=o4;xOTul3}ucKy^SSG&#*JFvk)+_H1aRudN{;>`QnEzpW_UCbGLxEcTS!29#'
    '_IAR71T?wR$NG<(=j+AhJ*vqW6$1zCNG+XQq2`djnA?NBj<w}hW&DEnKa!grN%ht4Or76o_U>&}bezk_mRKBP+q&w~=9pB2Z>+7YV6kYYBd#mVuz}aT%IttR'
    'ap>v*cNn63s)6~OiIIB``E9)R@-jMh*Z0=onciQ>F}R!#gHMf(-sIl7ftPN&s)f0N-gxKwGWG(gI6OeZ13symoS=q_2o34;0p4;Q)q$i1a|f2%m+t4L{L7WY'
    'DPCc9D;_vCP{fjMqP7}SFY@~U4prS=`#AFU25KK72fZxLPn{;{hE?6qx59nNR#u(;-ny=y>x$8Mal36%TQ=AIsWU#k_tnt_!mWADzigBp6hFu7xC5P!=3+a0'
    'hBeEr@s<hyVP*yAuT7UY@Zz}}HXF;nZXLWNSMc8WFCiBD7r$q^h{@b0-``0Lf{)W#JkA{5r~%K3vLf2Gbe~PA5tP9B<lsAhY7NIiMw8so;o}GtG!16^Q{Iu7'
    'Rx4Bh4?7QBdw#nJ(d6zepZX{kyF+3b)OXMwL6HKQ`@p)5eJzCJ+-bg08SnNyf9O$u6lPl&7}}!JfIr#zJ99Tr(+MKn=`9yQc@&N@t^wkNUpPMwjJNkqr$)fr'
    '+H=TgeAhV*@clYa5TuJ}^zY7TpH_Y=VSIa}@PpJl!*R>#XG{+Xm&3Vz{h{U>LEgG`wobF-tvw-Hm)Q&p=6q15kHOsb(h3+$f^2_UGfTX;WCqn@xY{#)9+t3^'
    'XO3=quM41u+O(4_X1~*HgM9n+H#YCV(gU~7b>v?cNJ`GTH*KrrND*~+tPHFeUV5G(((;gT-l2ym4Z)Z=KYvlnKsNMusTo`4ygAiR2;azlvasPpT3ktEzV|kf'
    '_hR!C7|m%-Hs(qx>11ek#w%_8;*kBJ6|0@pLVGnEJ1ki}SftGi1aB5z%a6x;$Ex}}{d-P~-tyF|_IuZIu_k(k$iHtMyi89UADnKws|^{Lo4CJ87S|8_9%xf}'
    'qe`3f$m{HFJBy+khi<q5&m1M-Z=3Y&V*ipw<D3`gupv$qdsq38;)De`q9(OdbK&qK{$9-J+vUmFtzvHz3X(TgTZ2zy;cFJ{*PjmO(YV_?97g!C;&K$}`F_6d'
    't5#GxU5+J1KA8UPERJ2BPuG!Gskl2O!=dFKRg4raMNiikHG*1Qm;Y{5#8&6GWR+se*5|!Zm-}p&kT1FIVu32nl~a+f%aFLsGuuqB`ikSwhf*K(>O{qwIvkYV'
    'O>bQ3Yb`~8^wD*_YBk@24lVuoqCI%`GSxf({wa^1H7TQ!kZd-2%$P17KCZQ9#1em>q6Tw+wM&WGNS%4woXZ!^EY=ibT~2$?XENYADE_*6dtJ63=RFmspT(KM'
    '?IjqGuASF*?iT%ghuCW80t2-Na;5w2Bm7#gKO@W*ADd7Ilk9}$9&B3mZnh>L<@F}HL$8ujz0w~Y>LrE1vq9D9%h2W!^R?beux+KwE;oVTpE%l`BBFo7&I?GR'
    '=+oqw9)8b-|MUBs3O8=M^&zxRJ1(zvw=qG4pL9}cGOP}wgo@L2?<&Aaof-vx#UWvmwX>csz=ut%rL?6<J;#ec9Om1y5%ufVhY0T874gNpSpn1Lci7d2+<}e8'
    '@Ee2Y2#{^oY<0x@qb5<=JH%ic1N5+?Tf%%1590<#r`2L#C(e3k9geDb*-~aIPY$!z=Kk@Q)lTJJ@xP0AxUSxgSN40_cGQz1=GH7LA&{C`fMw{;jIArHU-LEI'
    '(QW1Pprp~GzL2wK{X^ah`kIfKz^;)~eg3|=&+g>W;>#sF;!95*x6$#D`}O0rG8>-Uy)=Gbv29}w2|Q?m0!^&OAj2PSy@G2z!+#ew5A{?r<jzp2jQiuwY({42'
    'K3E$2`efg1KfsYdU?C^WSB<5z_&oYEd0e7N=dp{D_9w56HB7e|dHrZG+Ib3IVfB4lpF7x5J~TGFIHXf_bk~Z{97(pY)?B|m`-Vm=82ZcE(Cq<cf`oppitqH<'
    'QT4Xh8yAGK3KzEzY3eiCZEvZ?eJOt4;9V1^?B?}0d_7p<&4StIO`t3H*|5_q@mBd-5X<3<iZtkSc4LYxFfPsWPLTZpd;2x4<e_*t1Or>Tb_VZu9g<1(nVsYP'
    'mxbSz%YDRESN-!=V#Y;EKLuqx>0$lK;z1=Ud=BT&0;M&s;=0rWLVDWx0u2-M$%YeOi)xp7#UW7qEW-YunT_At?FE8yK2KO5Y%kFcI$W5J=?#F1`vOQLLG2cK'
    'J4pz8S*~_C-zU2rVo-*1;@pzg`iYPl<sP5VH(M0KbhS$l623oGtd@8g1Af(R;_PEIRfTe>XO?DPSg7{ia1SY9VA~CFvcjBcXG`l^E3jEi`4CHG)D7XN-twsv'
    'Ie-t3-u>HI9Vbmitn@6Tjt)^f+cn_PaP9xzGlKQjQKzTezaM-t+_>{qUBegqfO#5nQD+`tZ?~AvK+bQ%LR(+&ZcTW_t~S4AXFlFN`?c@T8><;PT)pgDW9$Nt'
    '6Ksv}T7&e9O?aOE4Z(`%$A~u7;mY|~ljU?TBjF@D9Ot3`W(Ji@PWQU7pLtN%B>^HkrJoHvsQ=vV?>3^|T)T&WHfjUGJ5RJ}KmED~wUGqK_8B%da}-g=j<c(+'
    'NXtEC`DS4xKmD*RY>$_5YgvN#QLR>cqwM$?_*DWScir2ec6yBc6<i%DHY`@b->cFGFedCzp;>}xhOM+1$$jx1AkBMy$11We=57@5*$UU%Qakp0*s;D@D)mzA'
    'V!e$3ug>9B3y0Na3xn<t^`nf#i=uvWkwfy?CTX3A#<0sb7dP^{(l6g6W;$2mwJrVAoV}elw1BkrtlZvBbhWL|E92?0v6(*X<Poo&mYGkGPKviBTy{UJ!~KF('
    'A`Tqi2xS<n*mrN9!dZ0~><;z!0RC+ci_R@Ke<#|v(eU~juBVIrPFXK=h#b3V+9QjS>4uGGhu@DYPB6n!TERcYcfS~2zub)3N7#9!H4J6gdoLPuws&RQ6F7G|'
    '`@aHty*Hu|yC2fYxo6}b{wa`VdS?gje787n&9L^Fwny`O?Zo>TnF;Vl;wN-|UHI<&0kmm{yfx~6dL_X~SlkZbt|I@aW09=9NDX5Iz>n?cr~SBgJL6O4HRsQm'
    '^~ksgkjW)Hb{&a@3tU85iaS@W$5Ic3Kk({U{iRLyyaHddwF@bob<oYVd{Io;95nVViAWD%VNBe)H^f)bpU~~5M>c3$pBL9KJ-T^Cw90do7=Mcbw6u~Sy-YjZ'
    '-N9h9zVGlI(XWx|cXy4AMWq>Bi?8Wjf_J8Rff2c7d8=<`($99b^Di~)kC<`rT~fKcrFWRw>s#=6Y7@)(4+OU&^E;w3IMu*bBU2&<YT4XtTu%pvLaYxn<38q0'
    'G@Y+b#VLia@<`mA&1d!Cy{-<kN*0SqjqhI`KOD}pHW#d*-Puu1-hFxXUnhC<|50?N&BsD<82&7#Wm={g6fvZvvLz`*FO)*I(xQd%*`NRO(z}-PyYK5_j<c=='
    'v~lKyGNdb2Eto_19o4G0^h;g6N9<^A-9|PkM(r-v$XkAE!5p@w(?d61yULD7gYElOYwV}zCuG~)dA;qAVez)4f68o>+KA*|Z7ts$<>ZhWK&_GtzOlt5b>d+3'
    'aVwCe_sk#cSr`l#p~YS*&Ny1OM%}u`u!eVd+9h6xLI<7s-NMI2uk#GOWrx|M(NF;WJUC5#!?KnHIBIvaisp++bQ!NVL>Kj&o8_hJ--s>m-c+|xs*}a&0J>p%'
    '<Yq~K2&`v_8@LPnbi<e30p5Tdlo=*yrb+X#|30oq-NycPbv%=agG%kAW996&nHEo&k%oVoG9mS&<;+HPmW)JcC#G1^1+O!nS`Iw=IGhX1emhEUavXs2?fu@c'
    '&)VzGItlUk;}tSB%KP|FdG2sout?dPLW`2GAaaQGOYU;t+vT`<I6lrSVBM#9GjsPRJrx6ad^N<9w$>z<?P7G*y&e@gYM6L>p-%8p;GPHh;68g0?NBpqmfTJT'
    'u>Ii5w|7ID`yQ!U7bN*flj~py8uRY}dO4#no|K2h8G?+r)6Xt+t4GamRSV3W;ci|{``OBH?$FLJ%QPh(@j5R~acDoHcZlSRcKgBo>ch*|&EM3=Z{Oann=yvZ'
    'tCe%V%?>BkEGohsoA^5yX7}Li_3&<wK9<)Vjz_te0*|xBZzW$d6`5_11EF?ZFO<WX+UT?KwS)gIJ8_dZl2^zoYt2{eqQ&RuU^X)Me=`;#q<FQ5@<F+NocEYF'
    '2Ky^~KAT0$UJ9n0XZ!Z-vZrdgcNeQv`*y!2UwpCFS@ZjjprGZ{WB)h~xW?7w>BgB%2r*!JCGwbK@I(#cPy3GaeoWS+f)VAC-WLM#m1-oKCtuc<3P8WM8k5I%'
    '{{r<bd8Zgry#9W_BF7*2>i^bC(kKTv?6|{7I$@?%fFE6)+ZqReevn5z23E#no9xkvfWYS4O)fWV=WC72Ls`*_#K7fYAF*bG2V#FW6Y+VSKQ7X%8b-&5m51xe'
    'w~InRqfQ!8yZJmr;5@IooibnL6yR4b9>l%~dXnHIcyuWiyKCSZGJFA*sfql0G>7_Z4xZ7qzu#}ZzdCzVegHkv=wR3y`%tYhI-9k7ZP@bu-Yem){Asmlo(@G@'
    '?R(u!q^P0(9L0ep5a0p<_*UNyPs(k{*OQDstg%gd=`XX=+h0CPus+tc-m9~G8o@(PlSaf>c<UPB-x?vRG6;Cv>-crqOW}0tyqw{o36(AwT-Zmq@|4OlB)kj|'
    'FhlQg?mbP)3^9IE7g|1rF%yGpu5Fk$-WD9<bNf!_WRvRJ9$Py(ZDz;rI)K(uGGf+anf_MZMp$E!)dBxGyF4rI9Q2VpiioT%=I8C0C#2Y`wOS1NR}Nf$jk<^I'
    'aF%IakhKl`O8xy<$CrI8m8)+~TA|0+DLRLi=0*$3?0d2hHwxg&HX>J>RDtwocxxXrq^Wi-G$p*n#``ntvyWTHR&HOUxYL!Xf)JQ#ccMAfH-hn5+a_bo-1i^l'
    'EORs3H#e7xcVRlCA>eQ`9~^I?4y2edwq^I<>H1Y?6i2)7lZLV-t7$8F50=$g#MS4^=%Q?oKL{LKo!0#@Amo0>;*ZZ(J+KazLIu?tqAs60qFwJ&eVkiMaC~b+'
    'Ic-IUPSl_;?v;CR+lK$1;AcW%!=zNy#W#4~R?{{*?vTu%uX!zlK<CuyKAJr?DX(>&?zJ3srYfjR%htMeo}(x3dX!g5bl99~V$>t?;n|HQLObkk%c6ll#}1dE'
    '%U#xR+s*D#Z6fpEr5p~I-H&sb3FhU++QFx;>h7-o0^frP=^TzDul6b4!(FbPeJoblWkl%LZBKX(*7$QLJr<nvE$Gwo4p+J_;|ln#Bi3I#oqqMGG>GX&LA%#h'
    'xX1`Te?K(j1rOFa=0C+}n!(*sO+ySEn~2xed?2Mi>M<l&-R{|{>Th*>I9mU|Q(f*Cliv{^8#~)O&d!rV1dEk^uy{wCTi0y>vH~QP_JsWX;pkw~nEffh9=#U}'
    'y)jV0=8(S=tI-C7@lRuo^fBUh>XKl^8yU~EJA40>tR<lhg;<*^JrQUaztPg+5};?*Z(qCFLL{2cNzZ%{3KYkcE-iKxO1UHl@L51HvL`&Vf-a@$S2}eO_OHVp'
    '34c|tppG@p_h7I$U2f{#v`B}RM}{(#a*`Zx88lgsLo@xF1#n;x^AqWBTWLmMHnOOcr5E^XGJg%)n!gwUJz05cc<MkpL++r`CS|I*XpQza+;!Lwy@#Pa<|SL?'
    'Fi1kL3w9bW+q0gC^3Wgq)%T4|erm_G?8<^0#K#43;d@xAnjJau9eRANRJ%a!p`bmwUAGBtWN-+7-c!BaPrX2v2=3RDz1=!GUyhg1HDYC#$a>G)Wp_RuP5|XD'
    'xGM@04*MidgdVJ}*S|&hHugeoyy5lrU&J&VD^><4N2xlC-~PEdoZ^v){kczNu#<MwWFX3!H4c9mMdH|uJ<bAokIj|zPt94y%E0|;L4L+zdhMfxcX_w^QL%Ny'
    '=uxo<{Zt;cXc|H!2{cbi;BU~dPJ8&w@<|h&3^&821+X$WPRt>FtGo5Pw{Ian$V(er3%e39R1m%XX44viGn)|2PLnRr+4D+g)+ZTPXc5K@9sECO!4$%GIV)ZY'
    'JLtdU`1btyH7wh`7+#*tV&<~#)iRTExj(0;2Jx>=6<l;KC}3W1Y%YJWw4nx6XLfiHc<O@^Z~3)*JKisXZ+}8u!p*5Il{CI@OK6u$otJIn_@;Wse)`0xXI1Dn'
    't~vWb^Ad6szO~p6sRMLjNVt_NeX;Rf_d+5Q$0OBy#J~Bc^E?{U0fd^Ozq~;j#ZfdOsrIUBbmnnoQ13h90a}>y+16U$CR}g7nNP>my3KxLjo)qNC}<30E?nC('
    '!f_uT8NI(LnnrlDEf|dzkP=A~j)ndfNO9Zmg>B+Q9!be4{Q0`zNBexDMDF7pRK*YQtM-#tCp(M@Ad@Xw9l7BC1}jrkyx#u=+-?e1S00W}_nOw2uD|9g$5U9$'
    'F#QSd`}lRV8br){+63p<Mn8agE1g^>8&f^E%<o5?9u31^5iB!gMz=1BPlnkZEd#y@q6uO|kkH>dQ+Bv6?x_c_MDykdqsy1^y2x>qZ|D6efAvY9A`kP9+`jFE'
    '1F%vm<itI1o24?qJ6wd~Av0zUNX)<T@1(WyA|hSIWmCP$`DS!4<{>v7t+U?8?Y=OLzrnA{G$57QyKtWZS1uaNoZHvfwl|OCPrU{2p&!64EkoKJkLl(j|Ap;U'
    'IgsRYvHngj_qYkP^^&vCKZ4NDn?ZVk+O?hSwnWG8wmEBPymP{hIsK~@`-&axZdq$*o&hhbdYv8-Xp}l--A!SNh@^{;Rm4@wob#E%X8X3@X76-3h3Zzml({Lo'
    'N&a+`C&p~Jyzn?8U!-W6vWASMy{tbs-e36GKINtv|G@m>#+!~up{e)fZec=Gm-?#dUCu|Nll{Fa40#PR5LlftC3!yM+&vq0`VJbW<DG=7M6OI$!z`CU@Vb<7'
    '0VNwiqr|p#=J%>ghBXi0TIe8`)%~#@=wG0GY>k!KjbgZcSqB+)qDK{#r?u@yAIjs#mMoS>h+TA?*=Ak+Oj;U&h~yzVjiwgoK5pp_An0g*&LLuT_;to`X&T+B'
    'VcnXLe(N3PkYcSwZeJ%ek$dX>2e1{I@r~(8Bstbern*~eRFVP>b^>Tfm0w}`eHkFF9z%a$Me5dDXLc63i?_Iu$Zg@b!h%Z<(d<ICQj_0S%=P^NW^;R8YggOP'
    ')~aq^+&U-NChDJF@ojteE7(*6KkQ)TL2kXOePS}cL*vMIZa@Pyb<UhT-WcoLulWjn&5&MH^KLQOUswfq`#^PtqK&6FL-op!Sr5U1(>#uRlZtYEOuu@tqybiI'
    '6?U5y{3DnxW7%3zqvI+T&yiebcdosK7h?9VJ>SlREXS4WIo>JnLF4LD733{?<ISYEP)6I$L@MFUC*qCXa^7{-d*W5BH?j=PF82soA-j9{=l5-8$Llb8TEkyZ'
    '`!s4xHS*l9)A}{od*kILjIq;c-g>0CRcou5n^h@pv`h)BVY~*w`8rrkR%@cdq)_LSEK6-*kAq9o19}kS1sw`uROC0|3VumvH|@_9<{Yz{y!7s3HR_BjpTAXz'
    'L3hrZ?ff=>z#ssm)apC6&T%I_fVED}G>X>I_K1*I()2Xg{M|4%Fp^-TSL~e4HDep9UO#JELlV43QkoqoWf68mqb8D`@SY1-enLD?zZgsJj?=9TKe=nb^Ja~L'
    'N3OfA2n}%f{{SbY@wgLa187c~qpL>J!z5`W&++4XPVuEqB`3AU;)7zfZX~-6DF@S9Ik;Y{wZI=6Nyi*_-!O<b8ptltt9b8FIp3TDP`?AG(b<2u!n5c+<APX6'
    'bFB;A>EXOq+^KJ=2F*e;0QSCk9M^}2Ce(ZKaK)N3zS_dKfZ~2>BC>|*UbgZY3duvg6-}n)wy}R6+c2gOvtTv1=VIP|xCe7tj>R%uo`*ebAe3*Cn^b5M?}qrc'
    'wQP(ovi^gcQ+csmCg+*X4{?kD3aehZw;{e=^lOSiHJZO1LdDFUH0RxQyV&IE>kkG`Kig=!{d{{5^1#H!hpuqFV;Rf+*Qqv@215r6-%4P~x!&$KG5&_Pw1)BA'
    'PfBav=Y%_MOy)dZd3C#<K~1R;xy>|hO2ggc1S}+<DkM9t{INfhmFp|BOQ891zA={K<K%+Lw63n(??y_NrvlS@@27BBj%LHFd>0p>$f}{WNuvQ<O!sinA6@{n'
    '>Vi7{V6V%Wnx*j2nN-L4@`_v{5FJ&Yc{p$t6xAP3ev}GI+F~oytbgQSy4wW$#nPe%&V#7|Z~x^AQj-XZ$5DrKZ224V@7)ESyqu|EQtQE4`%GoOu9;@`_mplu'
    '^LDqW1AhF?x#Q{>-`juVv60{bs0!0^IO_4`Q(Xi7mxM3Tm!52*Fl3*`bNClf4Ggu}<qA6K&sx^~vtgcDlzQja?bPW_rPD)d2jwk^l}4TW&ZqZJp>8xg7KW4C'
    ';d(#x)Wu$g<fW3;qv&H%-=0FxMlY$8c4&IO8-O8x4`M;uvW!j5t>*yZjQYjrt4F6kL<L@Mr8{Iz3wcEJuyKn<w&Y;C+Gsw&Mwm-+ibg~8`Fc_9N=TKscgy{C'
    'HOZCjYiqLgLtNRDaphHY99HpjA|Dg;Xf(F-qWy!d{KSP_{C0D0<UVSq+k+2JrysCExOOX~?z`L9B463g(xQn)t5)lj|6YG9^}4fOb}`t440qy`CW~pAHyefM'
    '^Ta=|r9EMvWhmZhtLS#gzd_u*)Cud*qn0>&<GX$+F-x5529@Prksj-OUo(|q74JtS{vO!)S8(9lYbypKiBfRChruVLUZm1VVQWkNbNZWgE-v`jfSo}C#l27G'
    'VRVm8BsP#@kI7|y9j7`I9J0&KBs9)vLqRh(tuwP=YyHtuIq~bC{^2404_3p`GdVvKCwlk0CX~-wjflyh0F*{Eqd(K8xMl7~@__xTPQQB49jwh1*CIMb50JR&'
    'L@72b)lMFB90ss}2xlvxQXQquI0xD*2dw~?m)0cNc_cYS^89FE{#SOk;?tK=ImRj7w*XBek1J7+ZQqNt1H{i;#{mCO2q`Wf+H=NbPUR(K(~}-6Y3H;C3$p3|'
    'HW3m_se^8jR5likKj~`HkLKpGc=+7~kEddPsd3}A+l$&Jv3&lfxyQ=bl~RD!Dy)&q9Mz;+u?FGI@92~DK@QB`$mpZ@<<c6yT%I2Mp~>JS<vUdmhU<YW)yR#T'
    'L^5suVctx(yza94O`~~OsW~vxysc>K(ms6~yS=zRmWX@bI>3}F7Gf6}&ZiEW9TsXN%I7UdCdEJmM$?RcY+LuFt{4KaZwKbe`QY)Q8kx`O1rq>z1pN`g<3$1`'
    'FJ`GZLSl|Du=5_);gL9W^={+><w|{p^?{ZE<D_~W;SDRAGlTqW!_Tc)EIJ35w}m>@zq^NSA01ZvU$9$&nW1;MTmv9v@5(CC$u|(~2G({5k#Fp78aBxzZ_BU#'
    '=xDt8L;OS5QShGzeI~uYL|KQTs9-Fz18ura<A%3l2T4VAu;G}&i&n(;f2+-La(bmo3`%%S1*+$YS?%^MiAFa2k-5Z_8pXe{>e_qgy-Ij<Yu9vRHZddPGA#zN'
    'i;9a%N&o-pI1wk=*~I3}HiP&&o8K-9e;5wwr4(q{@4kV^*;@eyd26<Ldq!m%^OMV5@FD8Zi&k`wgl(hN%PIX)fz+vsuJRiD{B73zoGCPM!Q7!$TZdHRip%9}'
    '47$PfHHCuN;oWOVrCW0^`vJVIPLtQ)&_*ZME2p+l6D~&9ohC%*g-))A`>YyW9{dn$*%{6FB*3nk%Nu%|sD*#z#nIg{?hUXB;Sdcyky^i8KIXbj+p5U(Ke5ie'
    'yHJLYK+1(qCI$oNL$)7BDS)1W7$Zuyvu@UQMHZt`X5PQsL<Oi8wAF?RfsY3LVX{UgB-zt(u{e_Im)G4n2;lGi_O%E}Y`EG}?_4hP!x=n%rUhNwd%zuswf`F}'
    'y(TL2w6wZ};Sj9!_5-N1@qpc+T7PHzX!L*gTi4w*sQ&gOhXuxnY>ouV(O{%S2rbsP&**xx1T4hE(e^D@f&KhmhbQeuJ+<);&FJhAY;M&7+NN$Lh$@)%SJL*D'
    '5<bi6kjdFDE3T7n)e>WL{3g5A#p2@NDpA97bvD}!hF#;1q_@OYo@2g~(XTNau`*43n7(wnhZC8z4`Vhs|5emBE75E;t=(pa3{Y?dZIm^BEpL5Kg&wwlqbkyc'
    '+)L?!1f%)vW9UlA23*}7g{S<Evzl1ZDICtT@w;7Q(YaUf2uk+P%7wc;DwWy;O_qfe-4*ES$_5xP3h%xSY8AMCzHeo8P3b)Y(qr_wbx%*VQ^!PV`?iS)Pm_aH'
    '-A^C2Pg}ZFhXaC3>%(e`1*@e$l{JT8-PB88k0}03NoV2YKYt&M+wA!v7GB$0A0ex54J*!YVVf6cwlyWv*iOZo@-?f+bN_Hv77O<P2@`b0C-csG-Fm3>y=x!='
    '2EW?M>d(0ff~5on-u0sW$R5)NFFIlL9+>5%@f_Uc>0Lq(QES+IxO=(sc=Wp$>bZPh;fq3VWh$PoCeZrBcCze3-*WwiT%NN6D41X|oz;Y_K0@jrb45t)tjqS)'
    '56b=}^1Z2w;)DG|zG2fafKd&@{u~I{vF>f;8}CODp<EkL>fc)XZ1}Z9uvRf-dJ5Mi*nZ|joQ<Mjc|&yT&ZH&o)DN|_3%OhLdsCE4E7gLwz#d)z7m%vIJuKlo'
    'cFrvw=KBHzKDt3BZTG@;I_Dc#xNZFUv(|ZHLg`|<SzZ?%qIXw{!nq!^^+I0v(3ozbzWEHNr%t881B@toWpDMIiU(})usbzpU=E+)$^a+N`N&{s(Hs<_+?&C('
    '2w!_7KCNs9)g4Tv)1aH^cX9N1-SJ`KDXuYj%M2s((-i4iry;+;6JUdfOnvA|3nnN0{)!|K_kju@HvE9+#c8_iS_BenlaYMr!|0>sMzxmRbV%^mB(au#;xD`T'
    'x)IkNzZbdiIMb?l(y)omjso1R_t>eTFR1QY+iF$lm{^<YtK;u=6zC=NU{4~Cepn8+AA~4Xs5T&U-yg%u1}GF#WH+We={EBC8hsf493a8!sVut9j-;~ys7x@-'
    '-5$>-g_@6QeaG43XzlrkB+Rwnbv`GER8*-)l|S{T%e%o=0%khyXIKLrQTc}6RyrUyJiCv(DL+VysvhmXE*9s=;63F-(4I==XDt74sMA;*${nbmKHs4;-BP_i'
    'u6S^*_DRzB3dt*z_@X!Fd@h^Iw|(jU+L!m4)hb-E+15thbcVv$=k1D(Vxd07zM#|+D_l@&RHkz7SG>LtoKQ&9ZQP!0Cp7E_wIou!$0-w50JUq>=1t-nwwC*c'
    '*m2dEfyCwqZ6({VNxk;Zb#YA4VpP2%ZFAl6a7lk~5zG9vEA-f7_yBq}>Vw&|vyJuh@x+`l&d^_jY_92_L0D&qiLM&J@DEt)@0Otd##Ia5=@KSph3}U*DI<VC'
    '2MM%3&OO1k9i8JFtM|e}Rs;V%z!sjeH06fU122aO>h;fYYr6JApk)q}^1=>Pm5TK{R==AY4Kzrs3N6r6QOUGNr`boOu5Y{7$8sK!pDj9MzYD8<)NBK5=?Cy!'
    '6CJ6(x!|wk4RJUOY5ugV?DQ@-HpM)3Se-Fg@np$SOHr!mGPpzq6Ed2)1%}?T*OAVQ=Ox?&8a-##x43=7Z=oY337%Q7aYt3XRa@WE{N>HuV*WI>sBzz^{_KLJ'
    'Lg_yKfLku_`)0d``AuqY70_Fxeuc)_t?0_v0zXD%kWv%acq0c|koA0is@!JpwR)hb{!O2QtoK6y5M;WkG_)1&tvf&^S>(+h692FtdVo>AA7n+~wg<nR>FtV9'
    'Ys&oGvC2+HzoZxJU$Vkoh5pyQ?hi3t@@UweH75t&Z!6(+U5(HEaz$h7AHl*}{kIa!bTr>357_Je|J%Q->I}w2x9M=Rfse_*sQr*XYSrdGY6X^Od+pq1jbB3l'
    'UG|7uu8s`mp2hXK>j0})SKk|Q{8-Jcbgt``NzLL{Ueq+oxLr15ZNK}>YW+vEjar~xkX35aGdj|T0~$hG@HU^<ddB2Iavd`q+~xS1GkG6-8)}^rGke61@BwNK'
    'n)KJW^|n%`GPuZU>k6wXx1bXWn|>YOwPgj-->oU=S1X7nSlus~>_M>+YMtz4-OxLHoY_*%U$rkknMK8Ryb*Muez}X-R$ejNcWKV|R-$~r7LEJ)LRCqbW?t7G'
    '6qME~9oOBrM5)WFGn+i*&b|GO2T*V*dzQ3pR|v7s#!bB0{;e^xZa#M1+E#gT(nn%ij%W8I-``Irr#825S4@@4?u`CTC8>jU|8Dc8Ml_)`5kh(nRyW$077e>I'
    'X<kJR*XQR8P3!T!&*>@D+?qZu2kT6+(5x5PudMjk0_j=3?(gnhSm^XCZR0VV2jlhp;QSV`xW$I18zl3}YP$rs!Y7Xu1l<y8Q7n4?eIQrYiPV{|y}Z-488=!~'
    'T&!LDjF0VIP=BlQauWEExXP=QE>WpOtqYW4+CHT=w3R+>`1ZS37s^PPC&B7{95nCTlzgQg?A}Ze`oy~)ZLa%GW7%Vjx_aA8Em_#KI%}n4%ZEa`ByZoY<fB#P'
    '&c}dpdZy(M@71e`z+R4xDHB&G^0<B4efv=yoDaN7H)k4VCDdW_#Gb*gPTha`;CEaJv;FRm{e|VJwtUA{IVrOJ6U;f9SYH!-mUl?Jq!c;Wl9{WgKXDF$%AYVP'
    'm2uY2U}OhbRMYFEEn3-C)0sa&X6%-HH~#Et-FXkwD}umpW|nOSW7WP~hWX;XQ!`byF$uGd)@OR#ls!H<uLY*369V{j#(D>WJP}-t5H6L+FGei~q(hEh3hvia'
    'QlP#5wrqtSVdf_S^Uib32De2xuJ>kCk8cOnMl;*4&}H=olodB6+>=j>CxlEvqAGx-k8`whWVb>)ea$g*mh_yiebd%I8=6<QvXJMH(GHo36T<g=uP{j(;Np98'
    '8*!m`#I(5u*6f4c8mCQs%rpsavRMV!@2ep=^U*<^yxcSu{sOA``5MNF5~mq`i>L3k<#KVf<$F!ZX3675^zzulz_h8eYK`;6-4{+;bEh(@y(^Yp_t{~W#Tu$v'
    '{+7?$V1~K+$V6_GK8FU)0leJHiydOQfd@IhHyrZ=ubBzW=dfSjyodQVsjCP{0P3cY!gl&Qfa(RIcfPqkDJyGvy`*4^snv7<O^Bxi2<W%>EIjn%!nQzFXsafP'
    'h3qDI^FVLBSrP7-ou!^7Dbl-Ya)ybKHcSPmzWFd=gJ0h_r&kO*x6P@)xIT(OorE`?f!I=w_i%uKwPSmma0h(yEh~d3HLxi50!+_B)&Gp|8n@K0LEbN%%YHRk'
    'pQ_JxGmEO05UVb?8r)y6@qN^2H*o`Eo59-OYxH;;bK@~4A0qYBYfD_DS7>%U-pdD{p0euBWM=S1ZG4gZl{w4id~i?h&~9)ujsPm0U%;{5ZF)e~YCQmav78@4'
    'XB3*O`ncdviRp~QbZbmT&{OG_XR0WL(+KP>k$AjO#@s@+*)i}q1irpp5%L1S&S>5UA5(0}g;#u@_Eyt{UmN$q^CR3etW`a5DR(fLBNw}AaPLAzCl~#3vrh4m'
    'EPuC=`ugUzrp8GEh&q?`%D-fR5RT7cIxj8mGat>8!qtYgs5?}?twLcQ>mWj!Rrh#a$~R}{0|=NL%*LgyaI7$WEJiboo&aqJ>j5X<&#v3}`UIRS#BNXfeh0pV'
    '@n-e72txJ3e^0yXtb>Y0+_6&P=5HvG;?xy!RQ&3y{F}}5>TTg!8<|8c@u~*VY6%!j-<bwMZkS;9aMLq<wo?A$?Y`j~+<UEgn1jM|zMYA9?flFEZ{>HGjw|u|'
    'U?{_(d%C^z)mHwCeLHELJCzRJZ&~+Iu?z1j6!`SF+j6TSd$j<aHDU_ri=7?rr~aw8&K8z?MJOdSc_O_Fh{@J#XSiC;#Lt@Feer@XTC-6Rrw8};F3BbXYuIh}'
    '(8_Zy1oYH-zxu;LG!V+#%UBgOJT&&td^FIKo7A3U3`C{YXd)1I5qD#^fpporo$S}^cVqE@2P{B5#EsO~N?Rk+vhp-rFJQ2Du{^E68_Eo(roKugC;q{U<*pKM'
    'jv90>_pSBiFdcbM?IZtOZwT$cdV?NyvW<Di!{XB+D=v{nQ8skJVZL#>%P`HBt2a_z?GZJd_x}8AV_4z+v*bkJpe5D?DGj#};l<QRO@wydElH*vw2K$2^~^54'
    'hxpVJ@Otj>Z12>aTc<z$h3ebAjfsFTT$F3KoA+X|8*wAXX3Wny@Ab;Z{kgnC_dJH-e)W&kxy#505BUAq5_X6Cd3EjL7{7V%-gni`Qgj?2cosp5chkx0Tnn;|'
    '%>D&@KEAJK`BG$82|Q}Op7pUg*4G5hauYFW)@-(QK1465R^Og!Xu7G1-Rk5y5+*J3c3$^>3<=1yY1z3A<NDy29q(krn_)qf_|VnO9B%Z>i6x$Q_)^!0NJSpV'
    '0XBCIM=7Wt83+jOTiMZm+{n`c&nCL3_j*qm<}0}qXxhUYO$H2Ej5ybKU$(c4$KB<niq)*0`I%f*W1M_@%iHF^cqdshhW~<H8+9)~Y1^Ba_k+-F-0JQ9kAj!M'
    'iSAly88w!NpgK0`bzI*9iamV7bd|a^uVmeO$9-dqgVb(J_s8g|UCZTZidOo?6-L4aK5NdC3}&y+i<0F-rT3yX%A3a)kGi(>KXv3R^nvR`s2-F>bII?!9r+`j'
    '0MB?lU)q>7!7A4Mc#>UJ&GAd$jnIJ~AqduOY`qrY(YFGvJJ@1yMik4!9B=IV-l<iz&E2-W#YGH-pKo@b)Q*SmVKES=L9OJ=ZQyCtLuoO#)m=BBQC7ST)Y=6~'
    'pmA*g_S&j%mMSbSvTS&NzVA?4g~?<Yp!DNUxaO1e#V-JH<qd&v8?Dj}Zc0pHyrI~w?lu>iSE{T?ibeV$-=OJYKKGr&2qx>-ujoIThX=Y~yVKpCJjpGaWNt52'
    ';8L*B?(oU%rh&)7h(6=A)w7f@GTS%7KR?Q)5}BIq4_rxy*T=Z_N*v?*s@AX<YmEHz*_hj%%CrGPc>t?mzHUmRMz?y@V4!Wko8#Z!gQL%ho?2p<wUT!*VWe5&'
    '{+MXd%d3$$Tu+vd9hOeelxL-S(nMYxje%s1On_EI+%B(eeZN1Pc)9GL=9}<Qs`ypffY&=d+x@6<dOl#`Yh7#h`g!fXj!Ce*);fQLFj3#Nk0g8`=DUK<_2>cz'
    '(v>1i<I}Ml_Udt`rWQCdE0q<9j>P0sBbTRqvsvBYUA{=H{X4xmz_Sop$6ck#R_f0V)O;@Eq{`c;SOg{_EKdOlR*sW<y9N>bx<!-8H?!l%{6LG2yk#e`J@b=|'
    '{O3nFtANsVc+lYZcz+$avptJcX5p-i2!@20={EX=b!(2V|0fZ-DVfw^Utg&e$I9L;=?6N~uj=LpCM;dt-NxaxmBtMt*LxmGXVayRa9c!*2J^{#doId-dDk%}'
    'DgMOE2X}dPLW{Zgsr<n$*CJDi<nX^>XN59C8k6|IEI-6#vdari`!t7>wZ_i+ES_F9h(|l!q_S{?*5;?MH$pzkfclzKtvPerO-66x;5O{_B|yHloA6p4m6O!L'
    'DNf2Nd3+l^PO~Mysy1rQyLvqMg?XyJHbBX4^={Ct8qB(}oe=4;Dyvh@jQ)b`Fd;<T$QVN`Z9M?T(2^~Re&c+u);>7?MIze0@y*$5>J;~9pJ<Tw>o$tc>EFjq'
    'N^HjsWkbcgwM@W$F?^nPg1Xvv7L9yFxFlG#wA#bP<i)Wu+j*L8dTo-t;-hHSt7%QR!!J?c#VYz|?N!gF7t(x&{U$73BbJ}E9O312i)Cne;Z|j`sGiB7)`w^H'
    'M!U!L?)hi3)7QBI3Ipc%5o82i4>pzEzFRrW2f*PmZFiZA`4k$0jV<;pC%o*gJ6o(~W)Zfe?YhsJ>-zG0M6&6a?Gmq+>HGcV=rf_NI@W4Up9NjllW*>u4LsW4'
    '_J3fsI1opmx;Sv2b%Up*yLl=i-e1l-_(eL^-;+a(h}vGaCr0bHQY+c|Q)&FMhY_RL>>wn6Q;&dR-HF<>DSo7|Czb($<Veg>D-<<Ia-Lbm(k*R9QsX{(uZuY<'
    '@$M;*P{*UO;xE<cS=dZbZC2~%+{EI8iTkqx$}o!aC0rMO-7y6hx7%m`LTveZmo*F@h9T1HP>+v@K)O?#hSl$5KLvxs>fD}#cr$r)n?0xLe$y2M7zjSl9gRcp'
    'KSaHA``Dp6r~2dCon{6;cQ1?XA>U2W%Hyonzk9kmWYgMmOswJ;&bfs}kM+hFNc-qXSk290e-FFY7b$g#!>gWh&ZTgkmB(V7w2S%x?$^fJ;1D&XFtL=SS}FT4'
    '>`SUs&1%rVh{`Yn8Lsw!3mEPM1z*KxmXGYddv#M9&DSS`_0#c~gRRkH-14HFzsw*dNL19o=uf?9KG#LJxHig?516W9Eq>zak=g2}L#v(9ulhO<cG4hgZ$nrb'
    'A7P=aW})cx``wm*b`)#8{AydpF<1VXe`5OlPI)z|kwp68y17)q=kATau7)>REMtkOHQV#JS%?1Qm5&GKN|%FF?u#5dTQGCY;nX8vmvh;<(`c{JS#fyfG;j~c'
    '#}JYLS|#@T!RgbvbHeaZe8b)Mesa?zGq#F2X7frECUJ+kblM#PtQ=SUeyt3C>ZRU3Q_knTGeRiW=4czrm*B;dsGD8ps_>a{lQQVy>rdVd(w}=428(C!d0c}l'
    '$(i+PV}kJ~CwlN<tF-V$t4Qzh3z=K&DSOmh|6PW>QCJh%eD)u9IYapmdSK8=3$E1cv4&jWLO_>w(3^Y<X|X$tH2NnR2A**^zizkE{Vkq%n{;a-du=B;{7EPL'
    'gVs{uan8&m4x^yAlThnQ0(1N+$8zPx@Iu<;SOU+c1h=cshWtlN^m!KQ><I^ziiDg>rczrN!3lB%TXipcwmsJ!p4yJe_j&R?VZ#kP;${h&nw_WKx6tM04z{C*'
    '(>YCR{gzto0$W1An*^TJYwyYBIqDAEz3_?p58DKN$w`_*by)O+rQmI6n#OF{g)+6byJbE&&j(lQ-GjxrHH!ineRMT*_e6mu(t{6h+P!4Bw7KIeJfeaMzub<W'
    'Gp9(FJE~iTr#3RT_U!YCT08pPX>51>?;#YEzkbNn<Fft9xW@>J@z%Vz^T)^6F+NZN95jqoK+e)f`D*y|DoiJF#)l|fd$!`1pQZB09uc+L@3&YcY;uf(zw&GJ'
    'ejAd>2H)WL+R9JZ@tbh#Xg4cg^firl{^255a+4b`4X;Dn&V}dSJAP3YkF`N3>Q3j%$8678?aS?8ujlZEXJUi8rVa(XSc{i@l3qcuw>iV81=1=vRYI|o+(&s;'
    'zW^Y>am;aRq{m^RrU2W^=CG}f;nd!hlLI_Dns1S!@jc28JBM#<QP%u@{nHEV&&d#<+CT!`r|gh{+RL8SoRs^q;OpP$Tx3*Oy`YJM+0;rwKJrqh{~!4P-44UQ'
    'K~jL;J2Ux;RVWsUV{Epk<jI!ckJ<ckJHY2>^ENvp$chzI`r$Q+IGr;S0}%aJ^R%AY83@jzLml$1dlIFpnp60tm<fa=LlTdKI}z8|UKM)kTjIuZCzsTu%1UoB'
    ';O6c@`}_P=dCW!U0QI4B!Re#(V)c8b^7$Gxm9INAZ(N{G2en2mU09yJWsAQ^_Fq%opN1PZpegx&<bVARbQ9qcTR|SxBLQ;S2%8Oar}yKTIv>JEc~9)|Jy(^K'
    'jH7zy6HjmL#%~-<^^C0quor{ZT}b!Ck#pwN-af4?F<zXlpWpT)nafl1mAloDISi-V`nDxddy-?L0l8n-s<WN+%~yvdRe1E;!<=37!N#X0w0=gF+6ue3uopTb'
    'ySlQGJJFt-7MC=%g4aIVhf8}oZ7k25WdgOj{m&g>YV#e?x|1s+TWI<uH|ctU_$N7QJ7U!`=;3cST~tVhY6RKz*36ua&>Tn0KtAq0j<?^3mxN9R`@>(Wzi-q^'
    'Kz<qCb4A?Q^hfR~6K$h1vApVcGHZ`_uSAA7S2ty$=O8>vmx8(dhQr|az_&KPkiq^}rpNOd+J%+pdUak-JN-)K6(^S`S!PS9wcj0UWHvbG;)-6^>5`RMY<wQ='
    '$**!X+AZe*SD%|a-`I!sHY3Cl;Z1QRu1+krewsad;s%@G(yqftNN=K{+K=J&=UmRilQU<aXlZAwVAmV$H`=B99h5T`6^c28biC$cSL!uFvOm&cLbJKQC!07r'
    'NY5+%-YD`XCc9E_>f!5)Duc&sX4am)cVk6#q|QY1KpzVh({_FekdO5}&Iar+(r1{7>>_ce7!r0*tKOzNezYymA|EBAR))TvicO-q#kZ4H4%5(2RjX%o*0-s('
    ';XK`DWQSRzih_>BMs4u`CGk|Z{M}NY{BWc)mJ9iGYK&E+XzWL#ecA8FhndDu!Du&sV>hM}C6<tNVvz0e3kO(gAP>SdHdNjcG9fIzp?u{k*izJzNl)OzXeXC?'
    'G)Kc~sJ+j(TIKu#fIWG*+SUzh*0+r(%m+Ekl)S_}Ao8;KjMv!@IRn!Y-vQdq-lw$|n$&x11Pedk?(zuBL$ZG9OZW(YlL`cRulFxy?@;^pH%+fq(O5wct@pPX'
    'rXEa8VuyUg#wX#SxIO(UO17;cL`R);GN{*O&bP5@a98*huz+iLy}UJsQoZ>aBxKmQ6C>NA-|44G?-<&)w#p;&oFR`Yv)C1u(HyzODS?99;kX`*@!jz*V$S_|'
    '`^h>us!0}8R=>f*ew)&5(v9Ws%8uQ*61d%JPcrwg?*c7vTM@tx`<7xZ<eN7-YB_Z=;u_I{=|X_BYf*$`>6O3Y4s4!p&ptQ8VPXtb7b@4?HTcmiZ*&GkpXtDH'
    'EkBiE&~a}Kl|J>m2?7W^bq94*z_cqVGdVIwh_#KY7gc8HTcLQAnNIt)3d#|K-D7yYLoQ(1%Thc1Zo5N$R9gHZtNGZ%9M&g98(YQ27p=Cp2nAjj;(e!Z*5eBG'
    'r@{lCNX<>>S}ueezQ`_5S)K2RcE?sAvlW5fW-wjo*!{M>!Z-vu-3@j$wn<qVp)B`MZ8FF=vyN^p@!Q7}2C+qcZBsP(v$xsFy{~cJOrX}OqFr{U`KG!e7dui}'
    'h&^0uxR1v&JQfnqkZ*o<l$AxF90Gn%Tfzq5e=CZ=eQn;OSZjQWAb8j9p#PNcO*U`ggRmHsSikHIe<<_UEIX{y38>qrLN8jQQ6fRz%L-%K<#I00U)>!*eCPOw'
    'Y@27R!spa-)jV&j2lPtgT6W>7u)g_or{~JIgLJmC=e?9V>y7x`dyRLU)drZNuv66+P6^yUJ+gEDLDlcNvg@tt4Oy@{wMz}g^j&v53);O@5NnI(ymqS$4<vT='
    'nw^E(__*O!<}bTNg&B9Yp4l?2HPDqC2`6{Hu`@bWm5^<Qwc_*{YR+Q(FxQ@O_M{Lg$eV~QDZS_V<oivW-i--0RuAnn^zM(Pb$-h7X?(-wAC!S`KEh0JK6|?J'
    'Rc7Poxx#GURWyCJea(9fYjsGWC0$S{S)TOsRj;2{<(?o6Rq6|tl~?sZBOJ@Eu!-62uybzr(xJ^2tcvRs-oM!gOE`SH0)9Ap$cDV=r60fabzNxjlf56VXMuNu'
    '>N$FX-m6a*VB0f1ENj0aZ8yhX`I5@Q!`~0DWG}|T+w}JMQ_ZbAdlt(PzlSbRbO{3UET36w!0fM@@~3X6;VGnBPdMvy7`^y4xba$)rUX<t(IONAINeg3y9kP3'
    'XGKI#PiZmlaWW25Nv&qw?em8QotPK{JihM&qd@;{8iZ#(HX8NuN98_k-bk<~>XmoPJr;w;{eDB&WZ=MkbH34=*p{0b#V?KTkDL2GVW&ifz9BeTx7s_d72S=t'
    '6^`|`2G2%A;<0&@b7+%#S=c+Zk8El9>iLy#)zNPG{)9u?$eLW+sLg*i?x#!5f81N{f@nRt>0@fl5utOKP)@(Oh+koNEk?3+U5>@qEo%eo)3Z&|Xs3#eAn8Q0'
    '79ot1m-l+cYBmp!o;h!)m1uK(!}r=%c2xS%zfM2fm7FQ}X7Icpd(NQcUz%@!0~9SlzwpxMpioM&wB*XPw&8QFY1!4+u(wmDm&M~5DP1rxX?hz{DxY?pGdadu'
    'zy9yCukDKN)o&)uf+(iZM<ZcZ$W>Ze!MoChvL+yZ@p$?;L-g;;)Y42q25ZCGV$3?ykopZ4-oF?+RQ*_cnQe>QI<JukMpp5Zi1OG90`yG0FUUwT1OsY;)V6N4'
    '%RD*Ud*-E)PCi0!*_a^98AdGWMpxuLq|3Pb(rcqFQD=eW&8PdX`p2TveA(aaieTX|=9|BYXrbKq%(Ch%H?oSO+6h<W#{nAbYOf|1-v&THCEU6pJ$@P=QZIWX'
    '5iBs+UN5^x^`bG|9V4nGK<5Z=7|$;w9S(dv{bIx0<D|`x!RmRvCWnlh3?_ezehWD)G3~-TD1}0o61n1!Gv}Q<NMAfu)Q5|!xcV&KgkO2k^FR4+emcKKdy5O('
    'E*%%hMcMScY|*U^B6hRNzF&L!5PQ`tTEABhVny79lg46IpmKMLE`*&VVUZLyv3q!IVzozie9<^^B%E(fr{C<v@_S%=3YD(pzby8HuUa`pV}lIG(EWZ76ZpNy'
    'bLTrTnMkQE`e&lgp>sbJtBdiJ{+wF{I>5f=;l<b2idz$@n-+9SVYcR@{xBPI%4;`z8NYW8uokU%Wq5v#?xixj_dm+0v+IxK7Ri3_9liJn^a`2KuMP4Mw0Jjp'
    'PtbTbJ0dZ7=Ya8rSb*@Xb%KXnGFIo!$}$^Z$*FqL{XZ9&_cwydpB{1Ngzy+#VO1f}4P@NywGR6QvjU~*SY^A|x?eP?WBpxjex2F0Z9dPRmQQ~dq0(}}=Lrhu'
    't*B#`X!W{_2wR)7gIB8a`;Al+&F+a&Rr)iuk5nDgfySnHjniwR9-}8sXU<c*96s7v6r|zm@!&M~VbdR|ageAzvLTj}SQS{fQ9(C95ZVmvO4dwlC#1CVab7yJ'
    '+xCF=v<)296laq&|M<GHWd)UF`z-`QpoS5EA`l>hs3?;-qC7auEQmOQ`t8@#xBK?#(|!AG7qybis>;e->tV|UBJ@Mq!%fnfA>w8OmF(J&Q{0VghD^yfyd)a%'
    'Z#cc(wh2(LSh4&i@v1IJ-E}bRkLw8ILt%Z>Tu{q!w^Gnfp0PPDKgrp!Xxiieu`^{S1U+XtIuPT@8Xj|!FSV#!ztubQ(mdNeXLpfP67hR$9$$4q=4514y+6T*'
    '$iP*;%wF63>d&J8T*u4xOL`RVqkC47>JfY#$n7e6&DU^>#>jLA5e#U*_S1EXP8MHfHsWe~F8vX_&V0|<<zme<$crPek<AEA<oznBlIsoKY;v}Bg*leX%=HLc'
    'pKyayr?2{G(TDy{4uTi33kz-H1H~g&yjB}o)BY&8%CmV|eQ<h;678GNm)rN@q~6zXy*WQb*rrrDbWuw5F2O^&mP%J)^(@`zSL-o%=QRynQ)|S%6~!E<09CsE'
    '#I1G<;!@oYE?q+pZs(Tz58HAe42kgiSKBwbmVe#||8~#8{Nb`q+(#eowy_zu-qlc$Fwlf1Ili4+!vmMUSAPl!CY;t1AkhY4`_<ACQLigriz4(t`A`dE0M6hG'
    '3;bsv6-J_3^n3Q#MgN}<1Q!?QD?6GY{7h;t<D(=ofBYcdwE`bvH*77-Ha{bpJ#6VJ%aT1?zt*E#vk$cv;wl^*CzB-ySGCem>+qHF@wlpPul0&NoirZGtp%At'
    '@qE4kRC=_T^J=?iq=`&3QaI^U4${&2`|BH5P=cVW^Y`I@2;;Gm>$zGxFaI3Xzu=_vP9uW#<&*zg^#6-%d;4o;EB&`s4%X(T_R0SLFkZiIG@$P^wB$-%z4zXh'
    'cMovZ&&bb<8&thrHm-k{9|s`SHum2j-;_}*nBz7tF;qE_9dEv7Gw#n86SvA-rs1;GZ!F+{Lhx84Yj|vawrki3?iy3zOW>Om_FsMQQRVtaT4ewE^?!g%K!*JG'
    'G%;>jHbDR4=x<;dT?n;5vNN2c;OHBQhsWu!;MIGyT*K2A31H6ULua3E`>)`h1|eeQ6_n=hQa1>tZl!b|nh&_t=ZjVawio<-Gu-Uz-F4yqcZlnDX!=%sV(2du'
    'zi@$l@14E#ptB%}{|-T228jN}(S5hj-|OLm9`VD)Za`|ZBefTDF`~(Tu`LD<(3}M)uc8_MZ;(q4jA=w_f=BwX*m{=PG{S!ayE4tA-=TMS^^r!%hkRFge0jW-'
    ')E)94W;%?xg0N2%w{?_u=|^2_B`0oLM_fEyEZy`czY?KT20ZMJ9b_<!eo4wJtycHnzzflIvof#z7s&J{r#_9Q8;ikS_~p=R`fuQSb2mVM4>8{~k=t)e_OsqQ'
    'XjOmNG=2Qt%<hz$fHcm-_E@{!iuZm!teNHEU<L*Q{?@$mcO9J-o5s$n{n_lF-Z=JhubmR6)IUBazYNQt|K@E9enhSRoYJ?4Ii6pa2=ss67JoPE`Y4DNVtlF8'
    'CxiG%frbLuoh8(o?=t#DMNexDl*S?cTo9}lO(*j0Zifd1Z%p6BiwK$orjl3uP}z=H+>eVv=Xovft*W}m=qH+o_D@G8^3L7#_D^?Vd$wO*q-n47ll5i2+r`A>'
    '*hJF2lMQ0v@;up@2ga?6mr_k-umy+k&J7FL?;Z8q06U@iNtgs{Bvf9v;&h~$h1Te;CMB7;t=XSWgzImi{QhjgUyvWbov~WcJ|wUv0Iy2lUR#6Og1Vz@akKIl'
    'D17t>JRJ>RF4dNangf~i-Zt;qeBR+0Pg8~T^d`z!WvcQaxA?lzy@Ykc^>}n=tC--EM{ISzbfx0s+w@N@Ehh8p?p`C-^Z7WBkMdSV&X8MsP8*M7+Mz>e4L(x+'
    '`K*`M?MZdVFJ~?%p1XXXR(p|Tf9iu4j*)+caQCH+8=G<Y`GgucxU0Eyj+;JewdGN|aqZc@Ce(&$C4_?g@<?D114S90YtQcL_8{t~Qms<_&Ub@8fB9eBmVEET'
    '+?6J~{-a7o^SM(gMK;~K-)>XE`V+W&$*Sx1$3gi(Hzm<EZk;7Oez|qP{#IUZF+D%Zy1$<}G!waxMp8Me_Hci_JoghI9+#VC#8Yqc;cZ#xp1pnz%E+a=1J?6n'
    ')qWKc_43&3)Yz;#F|!QVK}a;;1wNy?rM}ja1f$x$(O4S|-KG@mdp1{9>%&Ij<=nOySv19^8_IX7psJ|{mU}_gV7olmPPo#44X{D*vJF(rCbC}MKGM!@+@;zJ'
    'lB!ujXL@+bDUfo+`d?<P*Yp5z-QNq8*|pX6<$gz89%s%VO{xJh<8Ib=QRbH~aPu<*mizi`DdbOggRW+j3RF>p2iKQYsrHlLMhj{-#4YUBKFC8E@og!-Pbxls'
    'znx&L3U?VRkAwTG+gJ;)ZK<eyx07eMy9Qf|pHSmp1oAZ4j^kVDJ4o)}qf)L~Zl~I%8=uFtf1Hw+U$~<LDUah8tk17&D~PE<YkS)td*pmvqB=BWH4;9)pc`$L'
    '<J|9LTS_C~;XS++&a1wiof7gWCG)JPY}0-=1OsGJJ`Z>6&Vi|=T%%*%utSP(fwLIIC|){?7igqB+H!&|`t2vD1;Tb0?^a!mI8j<w9FK1nW}mRIy(YW#sRIsB'
    'yf`f+*l^W8Xmkn+Mjl#OG#GpJ4E=833s2ux<D@NIra#%=qx>GRTQl8N4GM1$6qjv0r^Q1#(8Di2M`VXp*?HX*duM1M<R*NE@uZVfjvj=z`x4f|rV9%qU9>?>'
    '>ynGS*B$MF+*z}ELL1`y;#I$n&|ponEjOfl>B+Z~^OpT_6$5<CM%|>nGEdIU@U`=%{*->hdE(rD57PK9$Vpdk80%N8Cvr;DSkBjPjpzbsx%^mPAhfrdhSBC7'
    'IjauVJ2Nl8ati7>O0h%v@-Q@sJv!jw`ym<iayhBb`#LOQd??1^ag5s?y~FXt&b3_lO(1*+w~Dyy#)DZ9<!*MrjJo2|o0agmpMFpLm~QrJi+yk4bYlc9SJ#C!'
    'CpB~4>-Smu@!a|Cr1@6y^#<kQM$9w*V}t@Zf6x-N^6<7lu+9+gX*KHv-&rayThS2z%(PNG7n)q8vERO00!t!V4V%0)+3LD=aQf6tC;O~ulh0)xgM#b_mV~&v'
    'ecyBbG`^y>#dR*Z<Oo{O;&X5eRRR=kv*y={9_+<WWxPoj-wh;A(G(u)w?mXvvx9tMh~hA@$hAy-xXf5W>YX3<YLvwcz?ad@YLosgV~q)RP*$p?ton08AfzCX'
    '&usHNG!Gx9vijPMZVW4pT6gT9<HUU@B|xXe?d>>)D}8A~-LJP+F4#MKH|)}0iH}iH6*r>faOWX|^d99mDeOtAewxPZ;@X`p139}D$*4+{yPX@hs^h~)f9K~`'
    '-B~ISm5rS!pX{i(`Flo>41Q<BP3gNXlpB*M-E(Jn(6P9T-1s^bl_W%Lm^4D*Grb*`eK}0qhJ0_lWGJb!;ubp9jxDv@-r`@!J)F3PX94A?W_-*;;knb<6mdQ)'
    '&ABg*Ig~E1F=|$mb^>CsI0ernC)M8jskeyU5I{=R^$t#4phVSXP_q|8&NG_RcD>yZ=*iU@3rZ<?WI376HyDFfLTheExx+yT`=Uon8MhN;rassGr8x1InRBn9'
    'o}!4RkR<x*u+0(UIDKT&YIy8j#c|!kM6bNS!^gQ52&wK3&P{!yt7z2aEQ}YBGnhdvj|&#q*1(S6a8BopbA%{6`O>6sp5>Yz6c1@TAU0EIJQXf$@5$@8S0kRP'
    'OhwK+r)Y0o)jf~Zt4B)>5B7Udo%hwR=sWAq@|u9?$E(+omB3{{ygm!XaSg9-)n{}vd#S))md?^PM9kS)U`ctJz8*LIF}D(_8*ssf`Rq+TKC7GNT8$JzX+9@&'
    'a_D+<Q;jC&FN^oH(faY}9026i5RRST<6a|NU&Ci9)iEb%jZ@=2=pMnEL{)Q7!`fw-z@#>QY`10jTgWSt60xy~!>Lp$m$$~LY(4d|Jcy&ueXuRE2HJ?Zb^HY<'
    '2g-FUrcp0C6!@N;@mLq!^O9@zOS?rh>{p*+PcrCwyRVch(sDX~^0WF2%q~=f?u2raB5(%5j-IgnQEt<YhSQdN6rlZ}IbOMQ78x*ejLOSK-_BWpSS;~FKc9J0'
    'd~T1xLWTK>joa2Lq?D2YR(6F8RrH5Lm6q3UYYtXkEbs6{L5c_Iz5<?^KxFN-e=Th(`N?;g{RG#-G@gz5$>5ZKUW~G7SK;6VIJmqyhBg+)+ch`BCwZDYyf?tS'
    '4#0i5YuMEqxrt$Zw%+QRqN-B+ek!k5Iq-pt1J7&AdCA8V>2P`Uu;XE<>vAc;a(QJ>uWMGoC!MY_--(#EGMoy$9fnX5<O1Xw+ptkN<R|OUmX5bF3(IkAI#xJ+'
    '`{B-1d#A8>Q;*1xi%$C12oFn^{9K=g<?R!)RaKM$sdG4;D^k>aG7*2B^iEDgF-}oIox{*%9#OA0-w}eaqV~V=@okC>Ii!3X?9UL(-Mne@bz4+vRG#X!R4<t2'
    'B<QsnUlWfZ%`J#cUxb!qS!)<j#kmhWN8n55Z!H87eCx1N@wBAX`DvpnE!2UlyC+LxdZ<063NWJmfskm^*+Buen|lt*cGA)(965E$OBafx?lf$-Bv~TNJ##w_'
    'YWY~g%f>C-8N2&&z-v`WK1{lV8LjTeuv4A>W=HpMXL*lfIG8cN*?EsJZ{LT5xA%G>Y_{j3@-e^BdvECg?%p9(CT;vQyg6q6T7U>zz1H*G7;bt5c+%QvnG{Mh'
    'HYN9UEZ+Ld>f_X!v6n%$-uOQFfaczp8Jo@eb!z#>ovNOlh%eDf+{zeI9O?p!Wxsjemp&37iv3b{j(gCV6oG7TkCS`}q>tVUAr@415{QjZsZ+mtyL&(9Rup8D'
    'x_>X9Yi+o-8$OlY_hKlRj-7~Uxp6yXZ>C)xzOua>`q$g(0_LaT-OF6}3^L?$`smf=%~dJr7q8E~!67odi;o>%rH>OrGiuy?s=R-_EG{LnN`)3g1)tsd*F>7h'
    ')+xT;_PbUBw8<sd_(R3g4t+Ln>v0VJe4Pwn7a_oKnqiNDD^iVH(Y##23GzJXxBmM=W!2dR=aKn#_oKcae_M!Dof2TT2gRur^(tgUKg{o%%&Bv`>ExpfbnUgO'
    'uH(nNy^dZ)dqO|UVUAayj<(;frq{|W>Xm%U6h;<ryprqy)%v!(X*7->+bhDQY>aKW2H2Og9E=y=6dR**gLX}M7mSxt8JoPuWnWFkeP?16_e3$ohJMpc!udb|'
    'k|LG2`Wwa_=X)`^>wL^;KX1`Y`pR^fs@>wMi-~6A$->ZMG9oS={6#|gvNVb+?R(QZZo8Z&1`l(^NaS}mfY+=%s&9w*cwc(Sv!(>}u7;|true(M<+8`v_S`FS'
    '$R{I;TWQlCl_guKdKlCFngfCz`Qm=d^SwO!TpPiJB8f7rz0XL%Ve-=3jy>Ogt<G_+H+JS1;V>MoB&EbyerqTVGBNXbp(vV4#O&eCc`6w%l)4Y5Z5D{SUN+dF'
    'K1qcqmttOCRbCNkBrok!NV0f&{TlXjqU-AI4Cp1jWF%e|&n4BKboG;%F7_aEWP~#@@>clP&Db+5T}p@i5!|_QbvbA}ubd;LrCK;28g7-&$PvJ~uNMDOPXbqK'
    'vub)f#f^=K$~4n%b4C5?V*TE(-IGN$;y%+cx&>CZ@y%|sm|dAe(_2T*o5Tyh9{3Z_HfmA5=at6fz&MO}(d2zCY;&8dkJ2gjJ`E<4g6<)`JvH!=i+L;XW<$M='
    'hJ;|=nF?Je4qiBl{`!1l9W|WK7I4hR>;b?`zdWbaewP;8*H`DzXNp1PrRLSRC7u}J{zBd6u{6JPT0!R92aZqM)rs-0a2GPqstx=D*R9{MxRN>ZZq_fhwl&^W'
    '{7wQ*nrax0!_g@AYEzlYV~i*$BBCs7e32&S{A(mH@9jd?a~F;37e7&wYd0z7^b{F{8j5eao;N(NRq#a&kY%}dG|f6X6q=Jmd5E;jU&G$t9PJn_FJ@oOx|`t;'
    'te~7@i`9r4@pd^Z=YFiZo#BiG@%C#bL8i66&3adCT65a48C7@!E+1))XK>JXR`x}^d8Y2@Hvf@(dHRNlclX{Z&C`K;3!U<6k(?TXtEqOldhbR;bniLE&?^3&'
    'Se+_<!mOpVjBa&!^Q)a$H(rwU2M*rnZF8vbl>DOyX}kBSId{o8%^Qt(ox6@#;n0zNI|aO}2A2FFc(|`o<hdoFZHCi|(m$|#<HnE=d+2L!O4M4}a|xz)yW=yU'
    'FrPX?Qo7OIR+J*o`g;F_=*e$Ip6DL6%Hy}96R1MQPXLVatO6&ypQh>;J*hX4H}kwUSsbcOH2b0fac(c5Q$4^OWPQm1Z)i8C*_gVo)CSkTzVG|WVFP;g<`AW='
    '4^d7eTSwyCv$Vg*6<=XR4|tGv9pin}coCaN)sE(9SxP5Nzq`0%!g*6!(0C-hfEMJe=a`+NBU-9%ZXILnK%UdeWroFoTZ4;zhv=wo<NK{r<0agoe&wPvrv{zO'
    '{_$@IMJwCwYyW<{nYss{`0BX3dwj7;E(gkKv`Kc0sjoQfSA{5UMrW=KgH(SR8s*(-!93>L60SApbFMF?S?;Ds`@(c*Ph#Q#%+|TI`i7i(Tc?xgKxz|OU0bxY'
    'ee-xSrMf)Ef2sR9l`8Y<(BIF}nk}xBG6t4G2R`9nes(%P^+|gYR@bY;38{^4{XU^iHyzqo>hA`U_GECe-#1pX!Rau)LT%yA6Wz7bRzX2IOFIRq>S46>ZzYX8'
    '7E|#ou4+YWavy+i7>{h!gx)6!ot`csamXHmS=OXi$2S%g@m5Fn`$>JV(fHPQ*~aMdZa2P)_<$dLyIF3Q!@o>uvz<MaQh!>}xMwsF9|+#pc%@J@bM%3l-oD@0'
    'TD5oj&xrxAWUcZ6hUUcYF78~YLzRh33JZ8*Lyb}W0ae;i<+&HGjK6hpuvm_{>!Z8pl>Ar<P+i_{t^+PozQ&h7QA?<$fri)$(R94e9@3tG-<Hpo*N2U6Nk?bh'
    'oshCznXI&W<EaG_3mqziJZFdDW{5jZmY?|lIsus+L?!9hQYxge+=kdh2J&~`NTc}-81r>(Nc41X>{STm^wFbuZL;%O8B_4La({v2D*v*^NrY*ZEYQn(^g(>!'
    'ywrdFR*m;l&c$vz)ZP=XD0)vpzTO(_D>v|D{_$zL-s{}eHdY(SbBKe^*Ad-2s`k8B)zRyf@{{1|){DWr{dnB3z~g<x%#C&AMx#F7n7ta&{arWD2h8MaV-Z>G'
    '#^UNYhP|<scB<6$`J=`#Gay;ye5eVVHkPaP=3arEsN@xpP7jl6iEo${|EK~)Yu^7dZ%7=ck4gvI4Jb=azAkzt3&N?6>1qu675mw2By#)#sj*Qj9`|^@DvjFo'
    'v#}TsM~Hyv_jf8$V5b)0O*3n6ck5U+R(ifUD_>x~`m8Tz=^7(CvUx?F8DfUBlLF8g2OW;qrPG{A{Y87d?TPepaV$Z4#Gk-##GFSjfcB5?b5^6Z+eYoz_xem&'
    'l=Ai0G=@vLyuVkCk8bVNedBQ5tePpgQi7R4gOlxYFj9L5r%UQBq--;NczS3lwb8014y_jW9dE>IL!pFH?o5adJ-HObu&(rG#}Q3FH%ud^gVA!;=xoV4J{~RO'
    '&vjTVw%PZlw!Bc!`Se>_tmnl^uKO`OwWrT-YqF~cPd`7TBNe;O2RxhU;vIAj<d7`7DOoCSN4+;$TZn+ZpHg@{JbMegVokoYVoEa6=v=#VUybE|a@bpp1ol{7'
    'N0YT2REW5Ki1o=-AhdW`t5?JNrru0?n`bS6@`-raKWu$5uWDW0!*0Xj-Ux~vT&Bn$FV(}5VNQvRui1+=<_q-xAiCtB<#(d@`U>u@7mR{N!7_!f&INg8<YR^y'
    'C5M&g)ZyBwPY0j+bCK*aVGush8g&pyk9m4VZFZe^T*fS%DNF5|;Ah#;6j2&^$EgpsVwY#4cSQ!3>GrDNn=Lx)3zcMeXxk<%M_U2cFsTvVZVf<ae~+c?;f+ho'
    '`08Xt^u(y1|7<onH&Nek_8nUrD`M-ZO5L_c^j?sSt?RY??%Askrh^8+kwdfp9B^oMdEn<qg~+qhY>JtzjX!V7{hF<%k7IMmd5?Pa4K#iqzB(o;favE$D0IX*'
    'Qg2jllE2!~hk(=@@~vzjwaXnVZz28gJ_)|SyHnfh_0FtcnrLRUKlyVnxnHXeg<-?@$KO3WCB6l2D>7o@4=QcBAOJn5T6{szc!Ulm(moWp@G%VRy@t*}GccwS'
    '%ePCc*``V1t-f+&^m41UUCaa|&oQKRXu!ze*p%c6m^prvUy|a@g;wqJ&~i_+^ekv*HEfoLlb05AQeTcbyK%d-5?8%M{(QxiXI%9cVEEd*N|GRbemAk{;tg5m'
    'aA<q$hhJ<*Bc~w-e7mcwoz6>F%*1!sk?HCE<RG~M({1ZLc50F(-)xdpoInJ;H7CS=_UsUQDWZwp+9rryZeYaD6W_#c_$d=xtep`y@=chLeHt--+tluN9_ThI'
    'C&0$n%_WV$Lq&D`QRU`Yn!|Z@MRPsO7sVfg{}^uT)N|Z&GU&Q6M^D^aW(01wZa>^p(Vb(?>d-G1l{?tPJHxU2Sy|d~uuIQ2HCC(J*^sGHZfWlMwP(Zy99qh?'
    'Xvn~e9UqtI`!u8ms39Nf!gbV6@x73V_pY6){2X=`=j1(MvZj#$Z5hP(8w7>pKrM(_i?;0nJw|R-_0$=bJUu_mDXFWq6j|d#1tymk&+iF$Fi9ZbpeMmy-}vuX'
    '2}ja=aB99L&@OxDB-z~&hbx`+K=#V>leysrVqI#~(`Ow74DBFD+m)Pn1gc$UR}dKkaG*|r?2^B3=4Wtzdf8<=KL~Pp(y2#AX;deu-f0B1I^V~0UTxlhZ`@=n'
    'y(Us^n2W^Pzk{DND*KDjTTPa3``jF;??h8}*V@=y6yg?d+~p27%?EX>Kg*8h!hlBb8Jf<Cshw&2%eBDU71}@_1fdR<5!zqBT3g96O`fbfYPwHbD1#fwV-3dm'
    '=4d!a8qy4X@~E){)h7X`I;f|6I-QlS^HX`Q)cE&Ep|z_CJc40w|Eq@?rE;^`6N%9l*rqOPvuLuCJr+^7;+<w1M$(dYd3Wo;EN6(bBU#v{c@g2cbE`q;7QLnt'
    'WHFn~C&aI3Nql2?^km1<L6jB18hUgZ=UHcV*gv?b{#3fY5z}q4ZMUZ8?(Mm?CWR(>30gxbqwN~Y_6r7V;R#Ifh_FxHXe{CKhL<0m+f=z)g*bHBWy!0X5sE2g'
    '0T2kd3MI&`zs0_n5$hEndr@zhuXczh?H@Tv(BT<8cAYdjw)X>J9_GUS(8&5VZ3uVHFRfK+6wt;0Tu$`xkI#6a@0Bh9ZBH6HWLlzrV(%t-U$dQ*?yGLokc7mo'
    'ktp%h6g6Hj4!?GXMn@j|+qyL^w(q4{vg5(L)jggc>B~b#SAYT^5yaG+H*SSiB_ctYOm85A@<&g>yw?9+hbHaB`%+g3%3Dd!kFOAF(MQ{8yt%P6s?<RZZ@bsh'
    '!m0TcM7h$Nvv~1#o6<e0x4(5DntS8pb@|#&V4_KtL+_$&WD^~6TFP0qlATRf`h8O^M`We&!_)P0%<p4A9xgwwJ-lbP&I0mp9VF`tgP`_+z5A6rau;<puU1Rt'
    '>H%Q@wR-MU*V;2`ZidE|N5XifV^M_m6;Kzp0YK*EM$%q1_q#H@hg$|c_=$=jKUjQH?>v@SGPkxlEym<UyndnGi&EMtLEV0u3k`+ZS9aM0<UE7|UL<#ulRwnJ'
    '^5V5LU3a5Nyymi{SQ;27v8!~FJ9X{=z5DnGZR5`CoL++PG|4Y1Ct%IY)lJn}`Yj&wCM~#`wo7WsUA|ruFAVd>CV)OrDZIc4Q=a*<)<nKxvfjn3byxUoA$Gwn'
    'Z}Vfcc<;nzPkAKtiQVK+LHOen%ZBq>0Zei|Mnu1z?&W-Od{oDCtYKb)N*_h{yOgh;mP~zx45zUQeC??iWP@Y<J&A^u(POsHSNHyvtEAiBuauVi_oxL>WZg!N'
    '{N{l#e#=b1<8x0Dpu+@b;>Ioh5+1Fns~BBTJEkA){KsvhH8cDul*&+XouK3G>o#u=&iZp{HqS5Gct%#zv4#-EWzPNn?ql6^b2g=IcCIaQmR0lS-g!^Vy}zki'
    'kf9ZN3lL4Y3SUnk&ZkIhT;$bWj9#73dO7!P<?Q%U!@tHo3<km`cq&a)^7uQJ8zX@jHtJWqyHU>t={t{Jq!3|AS1nghG@+M2b?&L-z?kcV&L-#U_)2Xys2Y6V'
    '+5@b#w@jQGNvKwvoQLxl#@4>zp|w`?uK$cCB_Q!Qm^FB@4x|ctUQ?~<1c$AGFQhDOs%LhT5Pi(Y$fXkA@2f8aBRVkQVa~m1bh8rWO1WqH?IlpS>qGGR6!+?~'
    'Y8;^r*l}8mz3biayK)+C;p)^W2jYxgDUH(py;_LF?N`s|-O9e(nKa?f0-0zKzm7zcZHzs-ylOF0Rpa$6c-+$u+-SF1gqYmH_Gr=uzxVpGx+`%K?#7K$)Efbl'
    'wd5Ut6(~nHdjE<xB`2w{gT`eg?V;~_dyvCbp{K_e69d2r-E>c@P<5Zc;kN}Rbk*U&pR$HHr+*xDH@S%ChNLhfuc?rCXftdTVudq}s&>xm&lbJli6N(->vY9y'
    'a9{i})!aQi70k=b_FA&i*x%w_uc1inM}FM>WAH+-+;6sWby75i&vlN#fh_@zqcVOa)sZLWRy;T)u3FhOGUfg9Q*TunY>#(_L)g;V!Ve@}-p^Xtd_Zh2&s((@'
    '!dMJD=LJ>b58fmC$?9;`oq7!vSbAnxyFl)VI6jnBZ<(6#m27)})L4zGjtjv2G#O!bxm|_1uvXDKlWmdoxYf{^?`}k;-@H5t`-Lfk8JteL#ak>nIp&tnqIb8#'
    'hmZoGw1LZn$yZD@U3I0R+;ggjel#^%;m2gWt2W(Xq2_nG7w9EZ&mHR6$K$0s6f3q*UbsX{nqXN&n>P6M#l!5rz(#crw-Eet^cxcoFBumXQNTr$^bqRZ0|Y4%'
    'T>sGoykOr4d>B6IV*81Uw^J_+%azum^F1DaM|!P6Rds$p>GN?#Xkf%u`(40-mEXFa>_6b;3$|<kn>`Pj3uJwt%0AZnhF6xDXl_qx>ql{xwC*BcioSBzPDUo|'
    'o(cXdH&<c)Ty!pirF;$-oi-UQ5&T}9PC_!7v^#`Zud2x{3nFKJyT`EGwQASRq1)+4CF=1@EXbW_0FDvg_$;j5r}p01<=%cz5B(W?xwqMJvn%mC5FuWbvOZt4'
    'Z>T*n%$aegdzLRQ9_60j_iNoYL^@kXt~2#8-YyOU8m*6>x?Ofp-I8StoA8~=r*JrZ2e%L#eXjMOfuvQkG-@hqrZJq*(&o4Yzm=3)`}BMiPOequv|z<U5vJy('
    '_d13t^8lW$-HHbqGw>9#eq4oHdrb-uUTMxK=@PlIyn-xt^LouY)xim>9lNP}*A3rWcvK@HS2wZtreWg-m8IUJy8xzlB6uxZuuVN-{&)xniN1!H>ggn6zMl+L'
    'cKp8lM5wKlA0qwY=CcgizfKHPpU#8o6GWK8yH)mpWrZ9G*PaWq#RS~1CK+%tB=ZF@2U&IhC~s+dLI&}E!kV5#-!M%|9pThiutRu2Jv6SO<kKde3YS9MaK`w<'
    'S(_JFN86udmC=zKKIuD&_N@`OE3E4nz96jL{b(z0eV^sBOzgD0?as{8oE89ilTE8Ubh^n{a&DCz>J-QaQ|_|5wpU0MhmeXCf-R5y7KX{pq~;jRvEg`AmEuma'
    '#xrD#4NnMp-9E`Qu2;Qhv)kHk8l6Q`fzLu+$K2QRp#pwOc-R97PB9)0*Wk3C$g?uF?=hDFfI?tIY;SvXSPrJ(yBF1-k^&m1Vt;m8AD|P7YH!`&A%i9DcUCL&'
    'IINbg-1L0qS9^3y>;y?PO6_ZHx8)RYGqK9p7PzwGQ6^6=wgUf@?QvWN)B2NO*Bzr+w-FF^I*{!@ujqClzzdQkrt>p<>0QiPqm~<Nqq%s%Wc%8<3t>ZDC>@sd'
    'D|R3*$~@bfGV>`_EsusP_g+d#Vb;Dc5A9ziIIAe*0DC^8cl+7bz}Hr`wAj==0sP7MEO!B<ypjp`UV<C?I@6GEZM$1qi()aY&KmW4ceWnb)~J~2Gbeua9r{XJ'
    '-C6xapo7_GyezH8MQ&y0qdBwp6m7$JH@e@n;VV>5!S~snF)sGKmLf*R3T{W->2b53GiQ50S4SiE-oR!L^3bZ!(Z^PLSqp7U;f6>uWj;PVS8Uvl#3OuOmHF#V'
    'gDMt@=-W+RA=IdXpNi2gUxh~U{?w|aeo~wrs2HpcM0Z_P%iY;4%GTj;Kc5y3T@D3>(LK!Pbd{lShwTy@YbkQ!2~ZEEQ<$p-qU4d=S?;gb<he$clmz7HVYs;M'
    'KC#6c&{6DnN3YFw(K(kbfxe~Kkc`WxK!1)|debz%%;t14j$-^={_#(q-|a7E|9f8S=J%XRU%=OL%I6#Av+ZeYa1wYc9rU(jNN?W8=Jx@|wj%h|h__!_-yL$h'
    '^R*~T<ltT_62FbOf-3+%@vve&hTbD_Mn2`I@#Qbb<kmzFNtSm2`?PJ({Fq-lwUOVMWrk)mEy<T|6ZnjDtx!1@&A1gTi)M<pwHgH%f`{~lE-SQB4X%QAYopF8'
    'U6u#CXC;mYt;vzPTHa|<3|GW*67Rq-{G1~74b(ZY$8G!pY89=bFFWAoRO7_CKe%$)w1Kp*$?`58J5*#JeXQnO){oZ69uabS98B-bi&;z>`(!iz9+cyDJE=EL'
    '__?**Z~3lA^?(`tpC%4sDozrBs4@@&AyTcmBnOYjr6>c3g>Y}lI^G8j<~>}CW#=omljoz4F|R?~f@`aP3?Hw*&EBoq3gV!8?MDuuYtIV58gA^CjmK|TWWS*v'
    '+(E~^%Xo5IPcG$Llzr8Lp4T4sJ^kALQLN;xD639*Haa7OpwF*p)*4MOW>4;^gm&G)=Dd~m?|&P%r&`aCMx&exnk#xbS~sqROm{9Q@!0t=QSQ|qDUp}o*ZJaW'
    'BQ*0R4nkgfc)Kc>RZ7R&?%5)>(_1q4oZfFI=WJK)f?aL4G2Jl4b-UT>ciDASnvtXvVY&A4wpEqeU8SW_!hqIlhbK*PKiLrX#_}94H&3aY(s5_=<WItZ#e#|h'
    '_2VwE?M=7N;?ND`aS19_R+U+-P6pWg@D%w)KMvAX($u70oMh%sDSmR@$r_cR=dS0$@&m#5BTc5(Pjt~3!i9w#k9JimrN$<usfRk%S$!&v`4*a$W&_tP-S?Gx'
    'BB_t(^2=@Ps@PU`Y^kH&<}G`&ZBg@@g*Hza16FVHx!i|tjwZz@XBJ9_c<S7_ZD8D8uJr{jmo0@ld*&`0&puZS37k*3!e&@Cp?-{7Uk+2dvQ|l1OfO>}SY6=h'
    'H3f9W1;M4R58KxP8}91573R};vBn0M0lr>nN!gRalPA|tv+?r1&PL|BKR&J|RjF#$u1RNp+!Hn{cf+YM*$pFw38^ZZG{SpR`bJyM-}l?)7K`kV#@vgokuyGT'
    '_}zO}EC19Gc|U;0ZWacE<j%(i&m1AOo4kSb>oS9gVlS9e@MaC02pluh`D4GkA7=U9a70f~5eHHl;rPpfi(BJzk)90p$Ir&mz4z1nl(+2h+GJ|%yC+Sj?(pQu'
    ';&pj?K4K;wjDz9zRn6-d(wZARfR)vI*kzANYg?$&RsOZ|<t(T!AlFh0@jNJnaZQgIyh$2dUY?nU8xdJ{ccOL<@iRXi9bJ~J=8J=^({NJ8fx$t&ok~FUM6$t~'
    'GcL^HrIN--zrDBhSx;Zu)jbI?#xHob2hsU_a47RZ<+ZT-t8yMnJ^x|NV^%p2t*&yP#Uk0Mtkd<99+n0S+SCaA1vGW%NCYF|Gu)4TiCYrq?jwaaqVefr(V<V9'
    'XlJvXFmr&kpQFyDw$qgB8aQvdzI<N<_h{_=uJq#ESt=(=G3Ij7G~eO~!FP@D!wG5|%f?R6CBlx6>)?81Ext~4z3I0l*M65h(~sXrzpXzMF}M!IU|U^Xy7*dk'
    'mb7`VmnouMeTz&)a_ysAE5J!*j&`!HL^ThtxZU0keI>}b0sriNdQBjZu&Q3|T!)C>5*BHB+ZS|Uv6-|#wRHxLpc@(sa@RpWoXAY?+<Xjnzg=wJf}(R<mY<k>'
    '=G6~4ZBx55u}{@O{VX2k<#t=St%U7vU>5vxph;OzoKj4<N(V@NdOXt*jM=x5C9h=v-8(-YOaUhh<pl9}QIrBAbX}K1hbzrhvWJ8Y6UWU7%<2loKAS4=p|4dY'
    'Y6C=WHH7W0XR=qsj8*F(=gtXb>=XmlyDk^lfey=vKOvP#bAd_a(2_T4RgaE8;xPBSV@|C8xEw~GHvMETx{n@&B@0T=SnqsKOmx2Q#Ao?}c=KJmmzaYNu`W!<'
    'TQf&uIOx0iq-w`}>oE#q-;Su7Oo9FG;Pt9wgUw`HR*}oe7x&2F-FMqt&V3K262cPj3DAba$~5wb7ce&YdFw=g)pgcsEK8>>+qPPubxM@lYUPv%d_8QR=||9I'
    '-q)aVmhNHw0k*>sI`|#<7_RlO!*q0Gde?^hkfYt1tf#A{i>z<=$cM20;C(A)fZEzx`%91DXL-#U&+TD0zJFfC>VOh3<^rvSFD)L!ItdnV1%B31W%u0iJ^sdE'
    's!i7)EpGX3pjT#CTT|*lwu!G=RG8U5`c(@V)6@qj8-To(0tO6Ml<+IwC*s<eq~gAE85=e5{t|gNK&R(+;}JA9{>IBI#Z)$Wg)r)h4pj%Wr++ZBl?3zSRjMD@'
    '7lwmWi&@qQ^mbIim_w|L9dCO!vRl+L?E~u$oY+J4C55nrARA78&;tdi9cpT12F-yf$FMYvfpTKEX0bkx7D@LrE#Qr8F5DQ(nR)F)KgX1$E8j#7M>x=F1JYt0'
    'V5-%Pej1a6zYF}vBF?3`+Ju_uGavdyRU~yd`g+Uww@u!sb#~;<^_r(JT%_-=`XtXT1u?Qz8!_yDZyw9#UVAcMMM*T<i{NtWk=)(_i-CDXpHfBWk0z=M$+X^4'
    'Cdi=PmaC7TcRwKB_23w@3$}O*z|bg-E1l1%^3xzCy)xdo>8oPIJ=tHas?-4@-NoY6r>s;=_LWV#C#*pEu-44)>ELQbtA3renG^K%i@R}&&9T=#iAeFSs78@Z'
    'p-*kzcnnIV@*K%cfBCh(-jvTe&Pn>YTxSDxO9bL5=v6zBbimA?JkindPpAKKOnt!1=tOSFpLi?T)e_sgOd8-M>Q^iB@LF4ORxujJ5MKD@$~8KB*@_w*x<~Q-'
    '9^joL`>31;c{lF;+7^ztdCNbU4}Co9Kmmpps{txK%f*rZY!;Lk?{0<B1o${4d8Nkk7mPV3?}jkhTe$IVZYyEAy9R3gx7uwnKS_h5wz``WQLiTXF4E^Jlz}h7'
    'J!k3wZf*Gh%x3ENsDD5FTe+JMEpRt(t=!dC`H5PVtXQb7Bm2woYQ5#ief>1oVFI+4N}Js)_rNL*D-KRQ#6g*Uzjcn2HY=HIS;nBRqrgI3IS$!r+Ba?dU@7T7'
    'tSv6`r)(atZKQK&9$-UI`~2ZT+iVlcOe9{RxxDJOM;fAk55=Uo4xZZ%v(p|lW4EstyNNi|nyNK!bllZza-%0G^tYP5mT1sG-?gle&u2a;oT?Z*9~1gt>A@Ux'
    'trTU=OW}>yBX4)PDkJ!l>?1Ltp_kPYJxWQo0+T+cQO?Vw!+9Z=`kV0j#=EVh^}>d;15YH9m_xPCC<u`;`(Cc=_WZ1b)~?-Bajse^aksl!Xq|S!cjxR>{yfe&'
    'cRUJZt_*o&h1?32lLnt9A-k@KUYi{gL+h}DI`z)89uYa@eP@$XkY@e+XAL-%mTCIYHulP?=E7a`Qfxf78@!Tdh!9H~)+Tj{Ta}|(&$BzKNd|j&Th98|B`C@d'
    'wB~gkFh3R@aYF8uXHj_0J7akTI1oR@)`_0iEIxb$8xu+jG0vO!xmH~R!45l}_z2x~sq#uWqG_;)tNCDLZ!-aUqY41|f=;tS4!Iusoi{pR=Vmu<lawWoA3mN7'
    '`|DVkW$?@jPtGiB4KaGTTMZPJtb=b|jv{n%xq%Ov>J@Mb6s;b-;^5ooS2M@PA}}yfIa%{%);z8uv$Gt3!|&u>BJ*d`utrS#rkv-nBB3AJbg7qpxJu6|X(8RX'
    'EU|vWK-W1sprcR!xTy;f=d3><;tyd6%gc@RX0+M)-dRD~fdMGDpMu8YebL+h=%I7ZrjN%gmQ`j?DxUnZN6hxUe$)Lgc3$reqPKFB{l0A_^h7j;l%1GR=5UKo'
    '#a}=J!w0q#oNj6(13H_$v`p&tMbE1s(dkI_ngKEax-Iej8OmMFdLpbZO6TO0l<S*u^|S9Xs&%|9O1s}hgs-&QA{R?(USE`Fn`bFbB53OioH($a^A_BAHS}X@'
    '+zom%sUYS`2u#Y6rtK!m2@%eVU~pF7<Yktp7Uysic0Z^MWr8wVkK(&kqg$8Eeqxldr`ZT>6PG9m2TFOTFTRRpHb$J0B;|*HUZdt~8q6A{ZZ-_sxlJh7d9qAF'
    'N`HTPYrXxlfs@St?&HQlU-H+H+?0BIG$OBD<-!=J#ijJRZg%&NH>c+I*(*@&++pvnPUmp6i=Rd%IltQWBdqZn`?^(3{O8dH(5u)&81T9mD)o2$!S~4#Qd=)O'
    'E#h@w5WAC1KO|t5?VIiQ=aBTQEvJMPZ{Of798>|i*p`s~eF!^`L(<rAlP>RsyR|E{t&dYoo9Y-o8t!$iT3A8M_Af!%1#^puoA5AvEW5z3i}~7&jIYU&Zq}ZU'
    '8K128!$UVsEyT$;5gJLq<4OHvx_PRn`FPRQ1+yFwXRxWz^*Tfrg@n-iv1&EmQdoJt7@1d#!;-00q$=4*2m*8B4;X)0mSQq-GGWmg`>5T5!eHNjs!cXgD*&nE'
    ')h_$~VQj`QF~l*kwL*j8d?Fu*%)6}n+?peA!66-|P2>`{)asOO4*f-WGkrk^VaRUIMeS<sN9Fsr!tuf1a9ER3>Zg%Aq}AhLwHwjCsW00<TCtJbhyt3#rqP?-'
    'OEIw-$?x0t{yr{;z18^0?xN&x&-7YqzJ<ei>N&fEeN;Y7^Hj?_2&3>X_}FxkX;s)CC>KsEAXh$EMD6a#*US3Xi}Q*SmYz-J{!YOebolU#@3HTIwQv!gIf~iV'
    'c38t=p43G+(skA6-vmJ1klk~bF6IU@0&0uyWkBiOPqzQewAvYNYQiIsNu$<fC~o++2b;rt2r~CM-EH9>jHm0M-I6E2Dy(d@CN+2wszHN8Ct%BqwvBUQQ!CDd'
    'o7OHCdaT~lwtv1qYs}fdkE%UiI#odTb~1r4EZL81IXiQ|<MUN>hi9Gr4d~l`N-j$8t<JiEf^AHO#i`~sZeL<C?}dOd3XkGqDi8Yj;wP!HfhV<I7Ruqlp7MYz'
    'Uz+LNhx;8oSa^5oV%j{912BjOGALx!_-tP0!dWM)UxfWI!JbX(-#WczPS|3Gc;v+qlxW!N*LGyjSob<J@FJYoDSeSdm`%7zb58Z_4nb0MsR8zO++YXANVUA^'
    'cV<p~bQ6S{yQ$?5b6FhT-08MeKDf4320C|oT|bBGr&U`+3mvhHrCTNLx9UDCaHzH%4f{$q0eWj^bJu9$9=@Nx5tKIknH7TZ@}&_Y486fuW&^~%2SW^O>hy#+'
    'H!_gyQu^4g+9@_6OP{5h>-ZC9guNp)UG>S-8teH^`u$b3w$bxr?qP2;eh;eEO68-D^E;|qQ**NYEc$4pWFmukGcf=LzQnPHYbTiQ@#I(S{MK|vD>H{ER~bh2'
    'TgN9n!J#H!LhzvKNzj>q8@(Zz=A4bpTgR9li|npv<whI%e1%5#wUf;tSg5RU`XA=ry{m0qX&nClthK*`OD~Bbp-H$0OiLl9v_L4Nx1FY`lQ`fK;xtZxK<Q`y'
    '%|(*sTcCTN=e+M;=M=}5Mx)VaG&35F7B;d!%x^c}x*tD(dA+{3xY9Z|k8Z9vcHeyN?R3^x7M7olkC*+W+4Gk_?W4_?#ontoqs7Oi_U`Rc@7M0L!;{TYsr~fl'
    'r^>IT*_YSnovSZTv&A<{TUV!RrOTzt;n8SuwP4M@_%T=M{4RX>QJFjRAAdP+RrV);e|xlcU3<3vZ0X0w?a}9()&BeD-qMeL*Z#fqwB2f6on1WHd$sgsVy}6X'
    'Sy=kI?flZ(?4-8$`>yo<V5Rxy>8JD4-stvA@#K2p=2!pQa`iZ0d@(uvbz?rBRQKNQ-!2u8KY#eP_tQSepKg?vZx0S$ynb}~{mtq1?XS1Tn;&1Uy|!MR>_2_G'
    '(DqIipS~D>c;%lx@e3O_rOLwDt7nTh?(6GM-`kVj+oz{<v(>jNyUm}k*Eg@PULS*Qd~CmY{ByKcxgM|mm}EcxoNR(PdNDreS~r)?{O-;8(bfCe?H@P2OMm#G'
    'w0?B@es;BRd)PWU*xQ}keEe=Lzxnpb?DgaJ_iCrTVK*Ny-gpOFAJ_a5Xar|B?+O>kXV<IWceB6Ui`wKx?PIrhSzDd#{QU{c(CXgn)%D?V{@KRS!R_zP#ozhe'
    'x77~|{k_TR+WWcpzd)?K=&dfT6kpvIz8`pxMxS3VtZ%=q+%2E{>U(GH*Bklm{^|bko9%n8$A#nD@2^j1^M_|Y+ST7bZ(dnz?)#2y?w`MX11r<h;>FdeJvTcx'
    'kKSyZEmUuwzW!KStL?p;eYSGjy87uXSg)O(55KOL&Ce}w>0;^SY~kC&w>RIsv%&UhZD7u=ynWLCx$^AYucyDCp4wkN%oPq+9)GHAZ!NV-cJ0Zx(@!54j@tW`'
    'pYI9>U%vgSbXxlhdyC`ktHPs`7hlYqldD7P_m}F<YwP>^PP^JaoNOJh<lWNb=kE8y$<l|5!=oR!g@v0fYy3T5INpC{j%$yLqu*QY_Ncn+y?n9r@l$u>rd7Q@'
    '?LK>1`o8i0{r-a4&Q`bm>gd_uPlt!E4i}D#=bu&<_qJ{y?Y+O)T+83Sc0N2?9%Rqf^7|{MTiSp7q<X&c=<knbTfK$x=e6!esk6V~yq+w5di;HRad&XDV*Y(n'
    'I^CZe*EZgK-@m^8{<6F9x%R&G`0?CoE8FtlK0f?VwfD|Xiq<AZoa}q!;o|J~M}L1_|M_~qvbgi{U{D>Jdxz%JH#c_iduQ+6<8|-Hlg+<><h$8Ne*Wt0`=;}1'
    '>B@h!x#8Zt`CQ%p_Mx3$xVzdceVDB8UGM)`^-J$oN-GC<vmf@H_T1v*ANJ=*R`!{<TRXk`&~oSYe>^EIfdJmwvx^J2hojR+zsy$`oyptR7f(jjr@i-&-d;c6'
    'Y`r&MeW*Um{>To#eVVJ(x;NSO+4(sC^k`{kE?@cfv$lKu!#P;FoOS!VtJ&Y)`<?X{3)Rb)i>6uXcP3B!t>M;Eb!B;O^)g@F035!o&t9C^Px3#S-sGA6t$(@h'
    '_g-H+PY#BaAD2I$)n4vdx3ACkFHa`5-ObzEACCKXd+@&fWxTRDSX-$q_YO{Bt<Sz&>n^zOJ@4rETJPe;FXwYUzyAGke*EUi@O*gdc1x9$?X5>oI)~?z?!o%!'
    '-^VXrSp64EJ%8?F|B?S`E`Q?R6wZG5H)gN)+TK2VXI6i{-~96AZFBZ#bAR!qy;fcKmgdg)4=<PdM{B*)#j`oQ4EJ+?YrN;5UNzg3<sZMl&+bfW=iAPwh1TM?'
    '7r#I6nw`h1PmdQ~eSG|+TD&TCpX_eWefxIzz4`8E@p|s#?Bm&UuYLLPF1z9l-c~zj*IREtfBtxRcC@tmY2SHwc>ZRRZ$Ei=QMrbJI)2n2jl15HA9f`>_qp(^'
    'U#Wc@uN6MMIDFQBvop86bk%!wx$tRm$=vns2JTv`l0E$V>8xqG3!D3UFE5YIW|v0CPhNJn{{C#a8;|y$<fr}fw01mcy?nR!<mmkU&UJQa?q>5>Gy8F|u)lh|'
    'zG_yNybr54y~UgD((TLf>dnWePhOfIK41Q5&CQl>&20Yr+~~*h+qsvE_U>_S<z&zQSi+@z^V4MY(dFvh=|XnnviRZqkD>kk<zn&e*0Y-Xy_UVIE$tpWS-qZn'
    'v+!=UcCc6It^L^h`DWC9w|a2C{P=p#St#v2dHdvjYrOem(ajE*KYUpK{&A^Q`*rAmDsR6&I-Xs7<BqPkUw2CHPFA1hJ$wIMGrxB8(%tt@9&dkpJo)|Y#yr2W'
    'f7F&f%-LJtwm17<uCK=5o@Iw0YYUgZZl86EgUzS*_3FFA;?Mq(_j38**~Lx&)a|@kU%h_3zq9WzEj=w3xAWDT^P_KTx3|l?zdM)P`}r>?mHz0_=FRu<^7-Gd'
    'KV|<u{Ix$h`LgMr9iBgXz2Sdu7JIYR@7~VY_*?V+`~J<&_~q60&4PP-`}31o`}^|q#}nt{qc>e==Y6Y_KRmVySB2kuoqYGvkNlgtvqOK*pMCW4>YH_YGx+j)'
    '=XAICZR>db*;{Yv=Je&T@^p4GdUxr*z8j1-j-IW&yvzS8UOhei?SKFF`^vo7EcLeYXKxoizI|LffA;C|mru?2i!UzTI5$6bX2<W`-*cZ%zn|PJeXx(lRp-}T'
    'ZTz#aIPA6F-ZfvlA2$w8UaStD*<eGx?rxZ!r-O~9_wUxOcQ>;OH}2%u_QKBcJE#BZxG+8&G)JTL>vikfo6CcZ?drR%<vL&dtM^NGtM|D0t#!A*_H_1%cmASv'
    'I@{U2{cTQGcZ;>{;+xV+^|O7wXZ3&Ye>f?<Hdp5I*N;B@`n5JZTrb{s_fGR?_V8lk;NbJpyPt&*<EIz)`O~f1?(SuA|8VcKTeFV7fBE~_)6wUjH`ZvW)%&v9'
    '^Saf&h3^NQH*e2(_pZ-hefaz6;9&J^@$jf(t?t-`@mkiK6urvt$(Pb?^~L6Ce|#{$+56R7IQ~@HsSckVuI!DUYz+o)SAG^hF2CMCY%Ps0+AF`aFFM`3z47ny'
    '@Mt!B>2x0N)RxazU%u@uoxJ$?{p#;*Z`R$J{rLMNd-Y^{eEH-<W%p$}W18k)|7jjqKh!EG)~(wgWzWrWy?I<LtTuPHYFqV;-5$AK-_JDaZo}w$L&G)PzTtL!'
    '{&k*%M|`8#8G7T916AhTk#pf^%{y!ZKcBp*9;wzw<3Z2K4(l2J%o{*yvpf`4GYoqeg)0gIxQ^4)z5w`>O0BkcxC>x2XLi5Sw0rJpKT|ep!?BYyGFOh%X%3x%'
    '?GA&NzSHY9dyd@+UbV)ZQ)kpX9os{E``YgL_<HDh7qOS^o_#TBA`oAD+W~k@f8@2#wU;Ajc;WVKXwCgOb~`qbRQuc=di_yzI9BhVhkyO&u~GSaR9Y;SjV@T_'
    '9b<Im<p*BRZBLB$ndi2lCLllT!>22EbOxm^9pmcE>pA(6V_z6&POp;(asn-T9e*AH*3KNGJMQ)JU3X-RhK^$Ztqi-@<H}f&Ui-$_cMPxJo4|*mKgwg<NPXkW'
    '*70HUq*gty7;SId9}(D(3u^{ay$2O1fKlEbIBge(;0AH?hS2;vcc!4qjQ|x7{uvqsx9wfDfI`G;^TaO2LbJNRLo5TMn$5i0dRICAk^ypwC$nr6az^OG@rT3h'
    'H_elyYAxaG>#gI1%JE6_VC(o@C8@yPcBQ#}T-iFHMiUAgRcg)ct=E;LPkVp=y_Ht)<e*xuz1gdzeGiC=9~bDO)|G@VN4_TYJ6t5K^Wjoy6bP4!lOggwffnHs'
    'DFg`@N}x)l7jeQQ6iA>=yi^K#;ssME6fYPfQbLh9o#KU(Nfj>_rq&V`ir^ZjRziUUYQ;;XP%B<Ag<A1~F={0giBl_HD4AOEa$#yMV<Ck?oKB%n2^7-5r_e?('
    'l0p@|NQ@q#k8w)qpOa~zmk9U1SfuX(&;$a6KPHhNR3eQCp+ae72o;JGBK$dl6rlns#0ZrMlVb%7gsa5~691k+lUSh?vc$@zP$pI`Mx1zwIDKMel1UUR7N*iF'
    'meF2?NVJylF-)I?5^>@z#0$kKlK@F4OR<pfJw%k{c!3y2c#4DzMJ7>+bhhTlwNkUT^=iKoR$0P@*X~{I)*d3{*B&C<)}~MXwfm;S+5?zj?SH@wYySmiSi6rG'
    ')*iqMYxl9j8gW9$=^9P4W`<d><vYVmQf_np$Qi&t_Q)~IfBnaR|J<&DFD<JiUf_SD;Y9m||22n~mIkPv>4Nczc3Clxc3bGvpl45<A(&K+FbrxJjI48Kl4)33'
    'K(F7)c6**Z$^!U$=ECda7c;kD=8PEB3mYnqpv8>azjXQ|Z#cmppWalqYEa1x+H$Vj&R}Fz=nvE_PebDn8Vylm(<&}5l4a8OMqGFvtg>vTV^5YdrUr}*LW>Q_'
    'Y!l1SKRUfLBk!u8$=%+Wxy-oV1G@|?K{h0F^@eGHoe6*H<x)e#AFQ8d-?_4=+&mdNp)of%tb&FGcgMLNI71+hm0?pSgZ&YZ3<s<_BLjv~CRR_FyjILarcM(I'
    'xniMU#=u34B&~SCOm9U=D6M?BOuRA?zG0z}92u$Q#nqINDy@WvDvU-csST*2H!^fa<6&P1%eAR{Xd^C`n$@GqA=v#^y`FjX;Y;)AxVrOUn`9-kWzHxrG;&7j'
    '*M$OoJ*n*PM_$9!K_^6W2(66lfy2%S9+*qJH+KB2?4K%AFEp%<+s4@xyvgyrvFbh72i`Qvx8X6kpa)2G@@mMM(80ZfqkZebK6je-Da^O5Xg<ec#S-ErH#@7`'
    'AEu}^-#)W_-}UD^u6^3~{E^%C>wz0$==kli({zSIZwMj;nVBUPx1-OWw%6~vr{f|0qPZ%29TrjSC$gyZbO0J_4FJL5ml$h?!mp<Y5mEY<WFQE-ay@gjb#jtv'
    '<jDKu!wYy6@(P}LZKkPpv~^rLtXb4irnq?ga{|aNYjE%Fd6;N0jhZ-*nqF70X>M98#np(=ymUbzH9x|?p+=f0rsGmitN<`o%v_iw+TBw#40+slN4`~$tQF+z'
    '%MCp8?m7K2&>7}o7SWi8w=TJA%m|VS+`K&)IIy_XGdstyZZ^29XCQm+&JVkdL<S%^g4XivVaFsfLcd{k$+{-XI61Hplm+Pn2B1c9vPlNu7sYav4|FJlq4&dS'
    'kDQJbCQ(y;Ae6J*8X=pAN3b-a9Aa65uFsr;L*k2G6-?nqg&#;+A(Kv!K#9dS3ytY*&imeQl!dj_>e&~qj%|45Jde`QZ96`}^6JF~z?${yYMq-hz5am+G3G3z'
    '7!uoZDho$uzPPk#TzDO~>$cg=S2niJE}V|>3K`3&-Z;Z`V=!*@+_urS2X@Qt0gpMp(H=S-phd@MIX&-+9F98|?r7+`#%^zX)A25i69@DWqlV2M6JEqj@9fjl'
    'o&&sl>h>K2W+T*TjX`bkbH>)dZl5{%(tKf_WW$HUy;}3|#JZhnHv9I4(`?R^XD&;tP0${i$V*MY-RaE$2RYYHJDYiIoE+_Z&hG<>`@WOk>i|nb-<)AtgZ;G+'
    'eZL+JZ5&jI&vWCP9`a8A(j9vJ3#jSq=)rTxSvP#gF%GLW&~oQT*Q5Eb{h67W$~Ay8It~wmi-SV*?Rm#(+Y_jAVfS&MV02}x-Jy4p*kW;hp)|h&a8JDPu<cM8'
    ';Fxg_hR>NFOpKE^TcxFCqt#xumlju7)|_sk)LwDy<;B)&Yhhubvuv-eEO!g=W~sfnwzyVYT<a8y-NogFZfT*_ZadEM(t-mm9O7~ZI1h%1dCp+gHI5H=bB1(j'
    'WB<J#3=Mkz9h6`64p22*ltJy@xC1kT$ndrQwO={h-8-x_KZ2RCS3NW=V}?5fA5W?uj<-=`C;Z{dzwH7wxDA5r1fbo1?IWAdkghOO<|%VK1H;vsVS{sqoaW7m'
    '>-0KJ&}-mz3Ep1V*P(Zd@Q%m=>ckA0-9eEVGE8T@{;B8oPiN%5Ku)y1y>)zCm5r;mOAl{*VS3w(Q`)Xo54LL6XxmH4ZLcP@y&7)2IJIq52UXK2wd1W%uPVpK'
    'U*L;I^5nLQg@nfGrPg}s;jJH3_N#}n0bl)-#!LTb$nTK-whs3Ww)S-f+^tqmDny7jh-VyBB7{F0j@vkg;myo;wR$v@qvCNK7n29#ET9CeNF4x%kSe>oGXeiq'
    'KM^5R(~I$@Vd1WQIIhg3@<qZZoCS2ynm*Xue;2fU@}^Qb(!0I%hixy1+g_O3_NQufe?|?0TCFXkE(AbM&BmOX8@Ujx<|OOnn2I^kqnv;ae_vOQYkT{9e^-uY'
    '8rTl|Kbi;Cj}?8y539$uH-J?ZI-D<>iXvbZ$k)N!3eW%tDGTFTP;Wm~#M``lO&ue51?y)Z^nAZLa(iImkZRWS-5XGP1%R2E*RWoIK<+!keA^qsAA<@THu)21'
    'XAdEv2f;Y}bW#C{-f@QWB)1X7nceF`rvli<^XEp1zX|1`o~1&0<VpEt<_vlpe-o4omoXcvYp$Q5eH!uZiT2s00A)<<#BKIEXH3{|6OU-UO(j=ARj}8au$)1g'
    '?V&fw8Nh@&16%Q%180alDI0HhfGo7k)UjwIgp%L^8iRAU-yt^N-#P@o)4pIm_(Cmduc>`UP5{I}`*;O<J?L1?k;k8TTUrMS+M3fIkK9WKbRkik1%~n1AlM+W'
    '5G-#B11tE3DyRYCSxBlmN<Y+j+nu@+c@5V2i+bBQGkb2=@dtLFY$fFLd@-eJ7IB!PFJajW3M%l6F&iPg-cr{Y!YJaNHDCx&f>?QpPIyG^zI$Q!viyezRgR(!'
    'gD8Y`oj>0@kak@YUkx2827pDlq41ct(}pxc==8zt(m)o%beP5p_Eb($G#obVOWW<)t)7!q4sAmiwkCpWw!HpWM>8NaTX#)qZf5Z}h?UN@CXL`1aFPW&CCo{#'
    '08(%c-k>E26Sd=92eJp)1}j*WQ78xah>^kC^%;gS6CO1FM7HHjqmCdz<}@TYcs4eSp2HZba>9m1pFtpFol$zXP#gAT-;z-c;|RSZuM$?{GT36Qcnt4QwJ@=j'
    'Z#N6}<0VYtD8ctc0kq8!3aaOIq<&LUf0o*7tQ)68?+Pqk*%c@_u%QC35WoPzs9c?a_$2y?HtREP&<YZA!$JsJ$C3+5x5Mq785+Li(nt?&iRfR#^3ch`-yE6e'
    'IiqhC)oAoD>-Z9B2hV|p4vQ$rmVOA#$Ub+{;B@2FH;jIq8EMW$+s<3qQUFJy6y_21YN?MQI-owQFa=umCT!fYu`U=<ANQQF<Mp*NX$i~GlHWwbz3q-B7CNj0'
    'mN^=FxJnu@5yTXIjx6#u;|uWf25^<#b30%iyS<)sYWKt!R4YKA0R8|&u<zy3A+OJ7bUeGh+xJIyzwJm@4KXG;_whTwjFFgsdjl9z;ZrFHYN6N5nkIf!^W-1%'
    'X^N-7?*a|G695NA(LqIjiw!lhT0<#Q?`tsRfGkKkT|3l=9a`#OOZxY^(j)M{J{0L=k?u7xZHG~Vhe=RG&@@}XIoH1i=F}85l&Jh+68d0jXhaEs|2;Miyh{iD'
    '4!{E=&)BbSzpLyBy%FeV_j=xy(}87<rFPry8?fSE^`SVt<82!q9CBNpbuWUFBh*@05LJ;2+1iyi?sW`UTxl&J(KEzAx1n<hDya^!h9bxtIP9+VjVviwIpfn-'
    't#X_*oKbt;1VF%@%!Y`W-VF`deL_CV!(f_mj?qUNW;GfzCo|==a@a5qCJA}M0)$$30{>^Z#yvX$TIoF-I=<Jtbc~jRbRcOgIzl0i^B5*Lp$I_yL~T$gpzTYD'
    'Hg3w$3U0{$8Tq`@{DIKE18O-9?3F!%iGPJ*icrKR0|6rsy)KrQ5W8qoL<iN!W`-ky9f%l@F~oME?ga-YiZRB05*;ETGVTu@yM2ag2s^??XP)nb1}va8da89='
    'i<uC&9kM*9&D<Z%07AzK79#vTqs>g|69&e>DNf5XE)*h!HVPhb!+BVUyiXDT`hVzEbNgc_g0BbEK`rVUt;mot2bIAeUu5x}+WFFXmpBor57pg%7Njo%Gh+x-'
    'naxC$5w==hsiDaFigm-)QhJ#>k@mLVefYl{UI2#b3$G)%qL=Qgfc}5A@Dz0!O&Z2Xz(R+86#AxREC^F6+?^zjh>PMA$LXNzc1e4h0Y~C%P$?-Sct{R&7<S;='
    'jyrVPBM<<si9tefU57S8VbMo%N?Uq3yS?%0nONrywWi@>ECqxnE0viLpBy0`2-8RKnW}95IUOR6#S|<O<ViZ=L!|cp)^;VrYyU0wcx-HuDQJ-Whl^Y}kjAuH'
    'Uf84d8U7mgy>@#%a2;9!*}R-LwuC$l4I&D8m!q<wC{~`~QZqR*xVC{i+a!cXXHc{SOKSTJS8AL^)MkV&hO93TF@PO<y?{AJUa(jU?9rLn+X)dY8xbI4!%Udg'
    ';g7Vs2U;L&1c<L0FNYtAwb=SLam1v(PD~Io#^d#+P0p%kpWp?h5(IUkNl-Ks#9-n=jtZjYap3CcZ@71!BXv7NZ%~H02Mgb+*M~uXbzBHKeH7LWujRl(jnCUc'
    '?uUotpUKI8D9r9#;-a06$c3ndW&S(J?eTDk^s;Cjj7llBB>u^QDnOd4T}WO+{|N0Qvr&VUYCb+dk4P4t(<L}t$;qPgu~7jTGZ~TCB3WQuj4|%V4|Gs`Kx37q'
    '9U7A)jNrx4`8kF)3d`Cf36Se}0FAZJK;2`l*-{d&{2+mTSo>E39X+zi0v$b>_)&-x^8eniZAgiYwIbGMN{#43PlLlQ>4N!ZD<%VACp9uxG3szi5n=bZ!S5dj'
    'GR6{=xNNfUPnGv#K+T8IxgK$mH}0vHSO;jp-WQ!CpxYx`IsLgFx$ql}SRYk+&FdXO#6ES9km$TXM|fUfqI>@%6Zr~A;$1b_&a#ZG)<~iQJ=m$yunPeJMp9_N'
    'b2`8Ti9?=XK%*2;KG7@Rz*Pf#n6z#LBcOZ18$z@u;WN|7CDxc@gdV_`Z?=v<(#BeB)RGzVVSLA2tK;<0sTu+hWBW+u2Q#98oXT1t1~u|VH(rwl{IOAGR;G%+'
    '@H2qYdNJ<7^f9!)8+I4wlM#WMOM(fj0-5~?m()-?AF0FI#LXvAncK9)*hXu7Iv<B5B=bF!P7{wH+>*bMWCZDTjG>-oL$C{~>+S`p&Y)=;0=#icg#DVqmcM2i'
    'cgD;#kXbPRG$^vFHYf-orxX|}1pmORsZb+CHf{qle9c5Yatl+z>6Di^YVQz&xsJiy=*MAe<BS~nDNxOa=|9|{l{B>@&Wl88Q3w|b+k*NG$#F{w+S<dU_OxY_'
    '_l{IteGi~2`$O0s<^Nr;rJ2N41s)ABm}J020xi-+rV4rZpDyR@@d?>udhkVpT^6^iw%Q{;Ej={8!vy%Aqd#*+`B3_9WETut04Z$EhtlSJR6R&p*w|tSI+<9E'
    'qdyGZ>@Gck*gJc>5i(2t@d3KyW8>IChq}*O{eI5C<Mi;yxfqOa%ikM3$9+BWF6?+v?yy<|C|Cz%EALZ_4eYQ@Ic1pd;qoYs51T(}<azaBZ-1vru~OxKqh+UI'
    'ajPOWsExaaVkE<u{*RH8&D=d?)`ktH2Ta)LNIqEU?mk%IPMO#;K<nN)9cwS9tf$dqySl$$*{(G;8S;Nl9RwMXA$qt)<AI$`s*0P3!M<~R0f@@V2M}oMxbnYZ'
    '7(F=UVN?j!m@??JUrsUBY{U9uI}ZbrBzoF5sinn&h>0gig^R`nJ2tfYr%pE6afXGi?<<tL{|6KNx{;`hq|n?O#uwE`X~shO4$?(0P&?vLTXBrA{08XZ&^(ra'
    'XL$4A*3dyr)$&-)G@gRd_$b+rl?)(B{Rz7=LcA3&nBs*?7>JOd{e;q!!kaQVdE@|(Y$2r&E5~>Mfsc;`-}tlvhW-~<OQ8c4W#i<`8x+<GYeo-N-@K29Ao3jU'
    'ayIdyRL^MlJRgk<WZFJ$cvCRGI1=Gr47?$(=OP9lkDb9U5q;lvuW?C-7srRY9F>3Jflby%Pd-4xWHMy0`Qrh?aXK=tUl5$I#Dxk^#H@p2c;5G}`UduBOrPu)'
    'a3ip!4C<#H+O{{C2+WL*;|%b(_%w1aB+|yf8Frf#ZRiZY_D^bC$F-dCdhc*+AKe%$7-_vyT!mT3LHj=NwjLH?8o!L&uXMQRYbIxWrDIC`#5;xJ8TT&K<6(^-'
    '$qU7g!jj`3N;nFTd%OG)s2BQgvFggIl^uRUfhnG1Ys=RRFwb7Ca)4dp7*!dOOq-<iMkwhNHq!3lmfVNF8lvn+^j25!)Q%J;xNE0m93Le6ku%Pn3CIVhYma*)'
    'aq2A;Nd$#RVCdz{h)zd<SjLc}2Flx`(J<bCsfWj5EUBO6!*jAx4m%=mVUD;R2bqxNasUp1nIa{Xfnk3}J^M97qVohQBSnh^3=jUAAuvbIa0iXooKafj*UrH8'
    'y^eDNLdD1TE2V<j2qJy5F&s!rW--vew8+JEPqOVok9Ep_%_u+h0HdcnfY5cZ@VvD69O@eKWR>uyea(ob+x9^0p@jPTHKT9UaQD<k2L)XF!sCSqCR7IzeL&N-'
    'N`-+Qcz#OI$qf39?Qa-G6aWG&{JN*3t_bFm8y?T8rqOdR+>z>-V5Bfzp+-)$qnJWUvnHJc#&eEZXxX-RF|dcUfsDdMNj@sOE+rBlh2t0@yMIpm+b$h0a>b^Y'
    'b1e=Sso*l-u}3=Pp<SdKpR7bWDRQIOM;EtNiVo*PSL+BR9D|p=Jue%Vl2tDa5w<ELJ&@+-$XQ?cI6lnzTnMyq!vpYO+O)lk3)~b@@o)XebghdxJB0I9oSMWw'
    ')TIn;z$BOr6`~+cD$_6<^>QEmq4l6Vb)Xq&DPp6mPr<NxZFeLA9Q+r=UBVjGcf{C+0uW^v@UQ?ai}+QN91x*(7BR5^FDgLV;uOP@q!1}hU7_?4{@#^HIET@y'
    'BGxwm-w0ZibW;JeqNsYWVJG@a*r{M!YDS!?6?J7ftr?Z4;OE%x3{l;TH<?&QG(Q+hib+b!_jMK<P&6lgp(W4IvwDr7pqVqGA4DBf2df3vicV84c+H*0NJlN&'
    'Bw8UdMY@Qd8D)_+U^IpmPCf)Y?!zL2Z8iceo0$*Wl*KinMSHfANMaK&WKaZSiV$J}qzXn7Q;0pjI9o{6VCka;N}Cj4#c^IJ91kE6<rA?8Fo9A5vk8H~v==`D'
    '7*sYCG=&6|!P5jTETp-B8V{20IA0}cVcsjTU4GygqzCURvjnv^xy71CeJv1NiL|?m8hr_ClT<?mZvGi4y=qOGhF5|d6LH25Xq9Ri7h}*|TIdwRdZAV$<MeOk'
    'b@@I6P_z|^l$IC-$kYoBxicN#m%fL_&%ug^eqB%?raKB^P(wYJdPdM59=W<t55FrX?$_Y5qj-M<Y(lLkMb#5hp;NYTrtu8*0@vwS2a=lKgyxZ$*<{k!OAS)Y'
    'O!E&g>3e<DTTVfnB4j}NgARiVpoWl8dStYL;14-Th(V^YI~UYA1AE0Uu~R(FAHeeh4c7f=o;?TkF2?oz9Y%%A-^;mFK7t*+BYk{9DXPdxq(-6n3340{@9~F#'
    '5d!N8za}*ljFJYR#2x_ifzzR7`%VuHZb1<e185}UktGhGzGQtA#}&~f!<s0?5?9L`o0VrP&zvEqMQF<5LZ1tdjaAeSUwi<3fDy(RGU)lEyojLz?O`3oI~|*%'
    'IBL+N>9jot+7Tcy#BvyRLpgX*!xq~-(F2{Nxki>>HL6iW!z(~^KnPSh9{HydipUD4-t-)_O=zcO)}VKK6OD+Wgo-Wmi44#~y+0O-97*26tz$BzSjh6GArF%X'
    'u^?7Q_#ln4V8HG(9L4Z;$v&i^qx2mZ#w%u5&qD<;yl69Q$wHXvNzXqVJ?z6KlEycjYXTIsQ)-qQzw%%VhtDypkYt<S=ppF<w9PK}nhDM4A_s|L6@i+>!^yq|'
    'EGVhXZD3l_!FXjum5n++HA1#eIY2y+Y-L<FxJ6L{p6>1fJIQxBu7FJ`X$uER%xsRksp#ZbB1dxvCrZ!h$ln9dh@9c2)8z8f{^HMZB8s&`r0GDyA+zOqDDiNL'
    '$fq-J9C}8(XS){|x+c*@;W@-e*$6RHEaxV>3}U_%Q3;)<akCa*BlG8rn(Z(AvgBP;e%d)=XQhLay|*b`Z&HdzHS{#b_QoUM?Ks9tu{1xwQe0h!NlM$AEj&tY'
    'i>Ptw8L`JBFW;fKhyX{sKgnjZBMwh`%G98UMz-++1C=uGC3e9y@556^Ni~jKSx_?w&!8rFDuSY_B#uqg=+)qeDi{k|6qrU#MKdH=(o8B^4*R6p!T2nc9_F)o'
    'KJHUTIdk`UD1tw%D^IfmkOf7tjzcRPoql1P(2Tkc`lb+-J|-Zyj9al0>G$mch%NL`gK3T%&X<(A25i+jrfq9zstkLTsg+c7QONvDXV}FEQx)t$>s7bw<0=}M'
    'EJ4mI30vn9iUww0;;Nx#O^S=iN~Ss_SF<V3kFbh1LYC$^rc}xl85Gq@M31a{R{&icNRevR1Bu#*=)96FbtXVVDV*Brj$VKlj{m>3YV;$nWTynYl3+vWjhCm{'
    '8<rK=6^U`sR4_0ju&4ZzV`$X}5$3GzA+^{`gNTL{lpJSDKr{s;&HcxpHjTK;C8T3SdJbgshB=)80S6~J2+ar6gji0qq5!n$SK@Blg&3M(R3pLTbh<X`IwM(*'
    'U0~r&uDXcatMhj}!5)TqJyH81!AW>63|@;&k4i~~8G*+qBb!_^@M9%eslmQcXe%gj??z7tkkFhsBADWayQg(wA*Z%+|7q_q|Ky~0fg!&_#RxQwxcRR4Aw4!l'
    '94nwuQ<@NE!@eMH&+8Dvs&p`CMA?uZQP4-9Kcd)XD#*Kpt=oh~2vZ3-#Yk7nn_wh$6e9W|dKQA4N%SI6yD9DQ5~%VVfC|N{59qsc2_t*KBRyJ-DU=%E&wzjM'
    '-Sq_DT~F{?VT-S*{kvojM^r>G2c{samfAT!IwLm;)R@OoA>;+oLq=EP-~@A2osoTjQ|bOm`sW-Q>qHW|8lFik8ijH9{};xv+q7qy%om`6G?lX{MQ%+~V^TC2'
    '`W7+75|x^|<~Aqqd!X9{sIj6LRZF#~ZQL2O?$>_qLm-}q6Pqj>l%8A9#VI@(%-XYtbSXvLVom9Yz+Gd<N7YvO?~^=w5dulapx6XfKynG9Q)j%Kv4;P}r;-Ag'
    'e1ba$H8^^ve3bEH-=OaY$G+i5R7l3FCPiWC$LP>d&?Z5^22IARZ0MW;1w4NgEs?qrrpd`>YtmG+iR~J(({;&9hbTuA3cIEN;}7#Lu;CJHg@0ftsN_-^qyRR?'
    'CKForc*p_YX!g|C49g3A%}+u+pcjH(3gw<;gb?F0T)(UYyL8jwJ4P$bM<YpqfA6$#lWfoF!axk&)3Z@z&l>diEPal6)-17o7l>K@jrJsh(bofRr{kdm0jQ8|'
    '<3Z^T;UvAXp*%G#kB}r_?<&77Tf!n;4SM3l@FFka<y<VWNcR!Jl$gAB5=vB~TCT?l+L)UD2m9G~fYxXoLnm+CK~{&x1KtRF6udJN@*SYT?OfFp=0<~>Nc@r<'
    'gBcALjWxleuHcHF4+ciQ9SPBf4)P4cCrJoyCuv%$Ruey(=KWYCB~2n$%MQo=sK-=j@9?Fr&4ETBKSD4`8_IHFL6xZNi#wlTvEVj^%uMojYe6AbcJDk(hw^fm'
    'Zc8GH2@J`30Utyf8F)o21(XU$jR1C-MiMvZp>d(TjWCJWwJE|uK2@UM@$*Q1r{t6o0C;|EA`4Jb%WwfYUp5JP!sukR<Y<6AkcQUncpAo{^r3Mnu>^`L6nQ3>'
    '=<7+@$l5JG%gLFrUlaIC`nh;p6mN^T00<cKlvOT!JuxHVmuXJ9CAp~VB&*4dAnIi>^q?5<8uOCS$9Q;oYXDEh(rZmXRr}8K(UnIjd?;yiYs}Z_4SHi=B<cW3'
    'GX&u!LO(?~XB&@}*?~m!$6XLyfq=pz(zFpG{VB*>v@noZB|eoaMxz`Fl?Zf1@;YF#$lPM^^Pq)_h`(%>&2=hVXO$BPEPvD4H~5Va0H!&Q0qF9Rn!z&qL=aNj'
    'fbt!uFM>WrsWY(mZ^#RVE>rH0l#x*<VBnY(waiFDJ>8Qlrm$FJ8`2l1>B!{m;NJc_pNFnWE1&Eics7tPToO_weKeI+Nu62YdrELqsV0-mEnWwkLelz*E`r2@'
    'D%6WKfh^FaO+hYA<Ouoq#u$*C-b(&n=m9LR)pJj6=^0I@N471Dy+{{REmTFY2)0RNle0JATy;huC!^5<Ctf5jExLZusezn|Y76QCATv2y;=u=$r-#zB3ofVS'
    '7|W>$t1KtXWh1PR>{C#u4<g4x<wj}>G9pKgR-4bvnh}^7eUEQLE=^)C5h_jPv<iIw1ghkK{Y>#v?0qLjesItQ9pkkaEppNakmOMo+92cYG`VlUXX+Q_iR$R-'
    'T~v4ZP&VhLNjiU<f)SpvV5HQRfsn)4qb%F^$|0hJEk;_=Y`IJ00#2JK$68(Wp#e)nDTuwBv%<Q}tdV#y_&$C~I>v-!jXh2v{}e(bIfMRyCW-V&f|*8|C|R`Q'
    '1jlKF2pUcEPP#m`#k!}dC#buK-NgWkd?OXE>xr4pTMG7urIy#cVCpH1BV?YWQZ`X=<P`J-aT#;8v@j)f3!`$L8?8Ft_e8(IN<dxC)Wbf9uFX4$b=pD{OQP9e'
    '3ys%DzIY}gkQvPYKia+&2-VBWjaYCfx1_pR7ajG@pjn_c$67{QKOByu!(V752z%cFaom|+PK*^n6ai6O4Stl<7%_&rtez8qNEgm3KsgB$-iLa}rArt&E=rUd'
    '(a!p#fUMXT*?iPG!@I61lYx)w67K-VH+!_9qOem0o)o2p&~UQxj9{oVDNrsC{Df^S+3@uw0Wkt4CJmR2JJ3k+#KO3yJz&D5<!KbnX`%QiJ+o1WA_kvZj9`NS'
    '#Xv&o7Zw-j@t?Mc8Rp1%s%$1kB#Uq=)U}f`I>KvG+o7nL<SrCiyW%otfV`%d<&@)E3_b;I;E0-LRQZp|gaOKg0VmugXX`-YJz*#T5eFQR&s$2;kicX~AVydz'
    'CqFe#9gOJ0djiF=984tIC$~4jnwtVkl8TFl9RUodUJhA&%1lIEpef^D!cj}olmoWI<l7XhH_Mizh#NwAYArA3=!BQ!Tg6;}SJ0NVsM(iWBMimC3@msz6rCuP'
    'd6?IONJVwXrsH51Nw7j(-$2j3P4<B@DqGI!7)hj`)yt}gm|m}Cx6kQziwrl&-d7P}g~z3AA7h2f@XQ-Fntu{E7s;;}^pyg~gt>tCtc6nzOo?|wsi<O{kjdh-'
    'r82y6kvF6QSA0MaES<bW<69m6qNov~GH{lI@nLv|QYW=alekh`jRf|F23I&XN=wT$?s(A$b~92cY^V_{$cmwA{3&AA#n?q2DhoH6P%v!hNWX)X5`&k-%_`;&'
    '9dIG6#FmZNj}v%^drT9yal&dmZ|4N>WIjgCiqjoxn*Aw48v$EKoIs338YS?J=4XzRqbaQ<1gL%pAEPX!9E}<xXXu{rb4HjMvQZmL`a3koaL6+m2^fnk%vX*x'
    '2z()eJ)%J)7clgf<Wz{bZ$n`zdaPH%VsS;c$;8riM7F~ss{t!LO=WLuE;S@)%%_&bqvcfXR;TQy6`gt0^ji>H=gFT(pxN{i0@RX|L5444Opfajq!5<m6s$sy'
    'rYYqVnsv7kIol)<NUs~YdSV)A-4hs&@tR&gxF|wHQiVn0MGEL+x(A6!A7ypTZj-@i52jOsx9&cQIXKI0j#x~Vi3C3d2c13VtfUlpRI2R_HHo5{Ob{ti_NSVg'
    'x?n=)3pUa;SkaBN#Ir2C`cWX9bp7gXU+MDYN9E!zi=WcJ%zGXV$A9=E-6@^uism&|gNVyG8}jM6N*Iyo!lZf0o;FE}6d!pCiDSq<fNh21{%```53=L)Ng+l>'
    'pO|z)|Mu<yFp>gZA_I3%7*zsRK_rzwdT8*JF79ymnDz~2*C<^9^$5&OGjsr3vS;9=y$4TTv2x*sJIhijSgG_S3Vlg9sghlw3@^>=D)o*exX><FPOd9dm1GH{'
    '0H>*1AuL$w(1R;5a|G_`qo$A?UW9o&nyhP=jj-dBReavZY6=eqmeM;%feQY}y|C#rUOX<r)TV-p_Gvt-X(!>#KL2*1PgvxoJ6$%38q}YHj)0XZ1ex#%QDe6a'
    'E22gwZ)e}m&Pr1&YE$*SX(rt%D6njGMNBO1Cw^t@I!%s|;PX0-;Di1GeYKRm#t~<Av;l2mdrf=P1hshtlc*V-<0;7a5sqG^C^Q*OGmi`gg34EkP$+s%Bx)eb'
    'tI3CmvSBNf!uP;D#XX*4p-|Abndq>|y>ljdQV2P0iqRqod=K3C$;@EQl`ztm+~gyp#*H)d@+ufp0Hmy|TBe?mr5Oo%q`szwD&+ORlf)AD*j2%f9Wnu~Mi}=Y'
    '+kE)$Ui1WBJRatcfh1Zmseu=2b)dP><QX9Q6U5+CFi)Rc3c*XD8@)`5_K~De{*Q35Pw+ZqbW5iSt`H%FNRtcGoG$%9EH5cHt`^6J(YV2_FI*6p)=Ly=Q%Y*A'
    '4-+x&=8?})sr18hVNna@5ix7O?Vys>4f;e*dSY%Naq%V$mRFK82=74_ddRVqL~B@tt_R{mcoj{j=7ie&FXxMmhYC#kqU?BRt_73@RKqT?1mWuQyuNMgTCMWf'
    '3W#@RvcL_xFM<T)Q-nmPJjW)B$rs^b3Yrux5s0xcH$qBAu7zqzVkTBelKuF=e!Pb)A=<i`k1U&^j<8IZaiD2#6BR9oo3VNY*^9K&a=C3P0*h(b<khwunU;YQ'
    '%Wtj}OYr{{po3rvnnXAg;~a|?c0!0S8vpSLkXD$4Tp;#B&QF-%cX#sO9r=p0+M<&)-Z>M>F_trGlYt{1gVbX=V-EwUI1L$I77IYiae<Mhy7;4E7HY^Kc`RO!'
    'toM}AX8MXBz914RtJo~3+jS_%uRJM}mQ^Y7TvcvLkhUJu)<#}$f)0QYr=74ez(?_$5-4J)dFfw?1Db7nc<LFx-Mh3=s#AXSj&tdftXUVCv@vzdg+r@}ysHfp'
    '0}8wYXMHrVDfKL?ghIQh(TJv;F`Jy%NU@s{_|cPn@}_o#E_{i~LzAG13(Mkx?$OmrKbqK3J4&ryIGw@NBLb<u<xmzJWO?3q=YwRr4-Xf3MblhrI9JFdoqotp'
    'M$Sgoay(-aP#|f4)v!XbmeaQ|)rcmZ24E^`#$wzy)K`7|qCR5lubHS(N6F7a7!;=-Kcr&nO3x4!{VdW?mUKVk6hadV8SuVCjv}@*X_pzeH*Y<#xhS5A&Qz6Z'
    'V|u!a=!v8t8%1P92}QmeGoE-O5@>}zpkkpAS{F?#Ep#r&_iW=P5nUeC5O*2njJ!lqgwMKWT69U|@QS*GDDhgP<T)V|1~CaFz(z`@9WhYpCsn5Sw*Q#dL1(34'
    '@wSp%I;$(mEWpWhLgI39d6-*EhNX^g`QrSR5WU*_V!07clp!;#W<x7Y;*xczT{xT~ujQexvTl4N9MIB(YJy|wiRQ34D&9!5v(plAkl7tphSaUTtS5+-cS3F{'
    'p(@}f(fR1-@R@G9M~TNfqOgRwG!&Gs?e;K>uArvIB+@IEMpZsb!)@_l8h(ykZ7q-7vtA)%1*GQk2U^9pjmf3Z=AuhhiNtxOPEfL5&X)<MsZd%B+0Cf(q2(y~'
    'gLEU5)Btrqk&R3nmB4ZgQZ=zVaYN)`*bqEu#?R7(`W=j;20bvo5~}|LT`dBi>B88P;hKaI%0!t|La5pCOdttb8Sr;JH^_zS)0K?LiX3_##B7KewqQIUCJiKW'
    'ToaCTRyZ-@#Ta;CiA$)#{h1h@Dv*rKq<UyT;%V8#WrTORAxIZ1CM7Qx2rOH{!pz#Zkt2H$genLD)j@YCnOiZ?zTI_3YKkYJ`ak6$l?F2q?t)U9VMwD8$?%gP'
    'z8`E2gc|;DWf*bwl(q~#?l6n7Vw{Zvs)dIpl+`km)AFyIfBomNQTcq7FD@-|Mm7#i#k+5}&M=eVE7aPJ>J9GxV2(5tgOr_o=fWKgUDw#{jc+>MrGW|C=Mfwx'
    'N|(!3$G9x5s7!0VTKqbEb*m(}e`a^QD{&pxNQDf|W3Kq)O0!luKEMHMZtYeMYZh34{n20l!TTD;V^9LSc4FP$h29-kKJHaNh}R#Ec8|AqDov0$HFy=+(Uj;t'
    'Q!eC`^rautCq?Tce{PZ4PtS}wp3=oh#NQpX^ZAj&+yX-#-pv;P2}B+bMe&dZ*}+nBl>PM|acQK8o&uU?eBrl;W%36}Gz0Z=Es-6@fS;*U_)uOE8(DguVP3k<'
    'mDS{gWFj9K;Z3>7GG&p8OgeZnWr><#=S=xlFf)Ck^kca~uDN$`v_B7o^L^K!Z+A~kZcS+|^*UJ*yo(*VW);mwL~EXsnX?C$euG*JI<yE^CM!^Q0^OWQF&r3~'
    'R6$vpW`o=3xdUU)s${0DE0VmVXzx&oRQ;?s?idC+;H+>Dn`#iKFVZ=JNSJ!dbqTJ46u^{dnH(wX1T-*V3T7kK)`=C}EHskah#$}|=b0|r;e3o0Ets<&MvF3-'
    'ke-FCs)>twCMxovD={`!{4FL&D4<g&x);=R?2(1a5`3yl25gw?g0f*c%K<>GSdyNraAy#h=!DR&s4Qo4L!QS%8BAqQlR0BPvQ~=4$Y(O6@l#2lsL=$&wd7np'
    '^w22_jd$pJsORbqWfG&qOV%C1h@7C4)9JIs!@PJG9#ljrN(ZLq6~Y=4SRN*E#+-%&Q`f?kZ=RMvK@)SGzew6}3AIQ@C}--x<~y!^+V}jC+xD&7^D=u=&V{F)'
    's%a&}j8M!UX$Tk1b*Wxh^~O4@T=2y8x-!F_^10$Q7AwUyz1IqOopfkmH~h1%z3$i(@%H)i(xU$5%o`8Ir>CXG04C!R7@RuNVbXCrd(#Z+3K1fT*_1dzG$>g+'
    'C@d5X3)pN`>yrj2z65Cavk-1D5;^UI6vv^La@yCWL~dx9kUby9fXiE&B`iVY>Uvep7bcS8KC;$u(%ho(;B%xwI@`NP79JrAC7MO&oChNIk;O7kWw8ZFl)rW~'
    '8Gw$(w`KbxdVEBQZQ<QUu~3M%Vn+IsI6pMkV4S-HM^rhn;&2Ru6B2wvbICMfBc7ASdwA&au%^^S$t-^)h@IS`oGFqoMI!JJO3V{D#&lN#Fn1ces1k`&DOA+b'
    '0Iw%;85dALL(7DU+T}?lML+3fS<UDWq#Cn&DQ;L{NEo}WPfnOHZn(0X`yko0^&<GH)(r+DwrDE!2k9LXq6u1MI<lq|bD&*&V_1`7ie<v;!}FeQd&<h1dZIAS'
    'paF$8Ecw|iN7PtQU<L#>N91DI@z%vCA~1m|sC-rwRvblgJ<xFvX?F#RFRNW3k2fqvGAzN!EyP$qq5}D1nV^gZB*c_G%ib%tNiEFg4V3liKBP;&SqXQ$G8&VI'
    'nIW*Y!jm!L_JKK>I(j*>jg)DQOpo|N*BbOGF6lIK$Zlkk1disxk;Osb5*u*IRg|q3Dcc}At%q%sx-v8xb5`*I?Mw47wdt_d8d~EbYd0e)7AKzCO-|jV6VOa)'
    '<^gP+BEA2~#8k~js24WefQBeHn42D1>0Dt(*-x{bwFNa@#w6h)Ov3m;hWKsj0OHJ0RMO@`%-Ql^oDGRRl}N-?myk>jD=%Sjt<;y$>r@3sh*Q+oOXYvTDA7TQ'
    'SpLD_AgP6Ron*sIZA8WgXuJO^Iv@xR(Bc7POMx~(3D(IWA}_2BMkU&ZsQ)3%VgG_yk%e7oyvouX+db=_faQZ3Q2UXk!c7W|KkVRoV50)0BrSrMKz*8ojuuXx'
    'BC6*JXA9NQ!sL^M>D`Drf*KZXFWy@!7YGOaeXcNHFvHqrWGPY$c{zbr!7`LA;Vu5X9ueeXrNEl$9aSwyIq~1E;*5S&M*We<XAov=cIcvgiddf_(xd$N*MCU='
    'ogaanf8hXUTH(rALb+Ybh7Fy(UNMdxn_cpkCCmw*cSu9@h8XN3wy5lmP0@fO&j8z&e5>Tq5q{F+YV{!9M@nC%*Hco8a@?|4v(s@zB8spV^X|`8dTHH;k-Aqn'
    'Bv=A8lufUz*Nt1)VBSBnN(<$P?@Ar<54@Z@3Qc{NPQ8`ZL=I+HswY#+FJxi314la`yuKN_08Dx=eGYVug+T=1`i|2P(5MpSLsRAEL~HrAweYm3S{qg&t?%sr'
    '?U3&~bPY`;y{2ybmt#7LNA>_3@s>2=@daD)o7O^EG*d^P0E>veID#TvjB^2r$kI1svLUR23iEfJ*wQM5k(Z895ge*w;q^F;QJFH4Mm?VH2nROW#h;^zg`pQr'
    '&K%<!41?xw&Fg&=@65On0RVAOWKx4fcMA7AP<()p#X^}5MI@O(nrBxY-P3)@&>|Sf+=09WznFA$_!w(GV4FyDxISaGvL-I-5otjpFZ5lP9q^TY{$n|-15OsQ'
    '!Z95avO!IjuzO%`4hP<lHk`%-e*}HKFz`-Rw<WIR#Z2!UB@PQHFiDvtGu}O{ZX2EpZsdqvG@RudiUEA7P+HCx*5H4%rzSVTgh(HZTRpd}ZG?Rp`{Q%Rcw<j&'
    '|IE$!#^lVNtQMc6e?3n==wY5(zg(bAHGU;@?)d><sv?|A^FMs-3ZUbJ@33i2Mi_04szKkm!o9We=nPi)j)LgV^L8EM)rL=)Xp9#mKuRr1$J9K#Z0#OiDtSQ}'
    '_Cy*`geN>l6pA@IvqvF1bMTz6l5A)_nK!Bu-+?{pc{V}Y-`lPno>b;X*F>&hKT*X48`-Ua-3H|MVc7b<W0dCcR@v*3xek+G-ZzCF7lhZhaWfMo3*}5TPVo*&'
    '@=bQ|4i?|RTUAGnaagTE%f^-M(>>2U7+Sid23T6ek|H!tr*!5HDAOcxD23x=*5!cB_*&^aSVlJIY4ycTH<Uc0<IGDo+4qQ}IFh{_pn?<w`aI{`s%gw=`5&$u'
    '^2!oQYKgfO#4aC#gFd=)j~4#9ar(&5h36+Lt9*r#<XFzBgLxRFBL=S=Ar3;`=lw;5sBQP)g)$&ZM^jExJtqd?aBf;Ow8#TeV|?m4#kbQ|2=>hNd2d9Ht%f+?'
    'knMGiclPON&&go)^k`_)mZy(*Nsv2N&bO}D>v>nmn`#yi5T4!G4&MQWJJZgv1!!?tq0X#lu1|?QNQ8{AM%Mvm#h_SFylQ9Og^jzfn8~i=_-&}?P$N9k_=98~'
    '-iF0X!GWYSO@PiIxXQ?N0+hIi9N30Wy@~6|`O;p#rq?)gh5^Uq@xNf&=pCd_SO%#DBLxx{<W$+%$1Bqh@HF`w8|INeGL8b4*_tL118GLc*8KLF+dl`r()DSB'
    'nPmzN&?t~3Lf(-bA;g*L7DZqBL<=lMv4LRTxjr_}L<oc%S2l1K%^N3lc(NSr+uFkX>Qm#B+eetkICYM=`4igyW7$Q6<Fq{Q90#7-TEHW!Lw7Lx$S?Lf#=_#t'
    '+QM>ib%EA_v(aeam!Chsy1JS_C+?eXdl%2!z_rguM2?Z9#`AL>r~KMNel-tln8%r%XKLhiYP^WFY^j!22nF{+VeNKsOA%(SkK}_%$x;u7BrFGWh5(8Jkys{>'
    'uZrG6wiqXGw(_N=W$JBfb;T~NIGyF<qP?)NP+Ds_t4rNtYk9fkEEU_`#lp&}T_~<~9cOJ}#qPG97W~&Ob(f0W)umENGRn3%zX@}N)&Y^am9D44nSiOzB)d_}'
    'CJJ{SqwA0|&yfS5cR(Yst`Xi9us$+~*P-b&!gR182{Ck<W{z0?fMtkz=;yj&Q>i?Kln9lrDOCp;S*HhfJBfKxR@TK#9*|5sgPNEgmQ-Al&LqWgZ9>UH2nkb6'
    '2_7$4#ApU|9nM84gcZq7>Kgn+2E_ZlkjqhrF<Q=<ed(eY8q$1|GKyAbU-1Gj*(4a~pe!yYn1kDoEbp|ZHe@N+njk=&nu?Ru0C+<sQo`a`EuI~RbsrZu&8Sdb'
    '#EFrd7=p6Gcf5gxNXL*s9YJt`h^BQ&iEf@nVA@`~L$7~9*IO0m7fSOh;Ykh4>M7-d5p3RJ9P#eIY20pXlLk{34Kh<e;e=*+sq9NafFg9n3QSo|`%`yxHg3_B'
    'XL!$3;G75!2k}}KZ8h~W&*6t3mJs1zKywXFXi~OU?WM)ll{KeZD79A{dwH?7+JfoXS+>_!mb(Rbv(#Q(TU;wHu5}8<?&9)7x3th|w;gABX~B`~84QSaF`qVQ'
    'imB`<FP(zsB!*)hq3Ku58=VO#R<QmmN_WS-9!EgHtVXFX;li{S@gjlxkB6rd74vN=<%&*jsx>n#DQu<oU<gOP4+u$SY{RPWsL9ReJ;k|hp&8{8^bjg2LwZ43'
    'G2{(`dEBKMqlSy%y5!yCg$qU#Vd9xhRE01H7#_GpwdrEe!&RIc*Jll{_y8<WQjkbf_!yT~werL4)|6p_0s5$>c4DkvY;gt&Am#wVx?n|C(t8J`8J!}fqoy#)'
    'F5HpLRAxvpRfX6l<%fj16hfrevP6W=GQk72Hvmh57$umknIz7@^+C$yd!TssFo~MmrQ}5d>fVkoN6_te+)KBE*AEC)T4)-)5RPymBuPwxK2qJHJ2^*c`6Sg}'
    '$i3$vJqP2FG4`cCg@i=IfV3`wnSrifbh&{<c0e#YG8MF--=Tmedcg7tSA~w}$k+uA_<=ewj~u#77FJ!t>caJ@Fp09>L~vM=sc?oXv@p&{W0ZaLp#!w|sa24d'
    '1=c=o0gtlxx?BvonWB>@_?PrFcNh#wFnQFvfhYn9%rUQ+=18(J5wtA%!|el214Wql746PETM~8)*g-C9eQ$VSWA<9|V1B5*&aXb-e@#Xk51cK68c_scOtKUN'
    '!A#Q!R8nT1RXpSEN%fEuYx2~Vx+v?N`WhQp8uRQacpd0R?L1F%k`e31g=3?o-%)m1ZzAu98_+GKD1JZ{pfZ|_LBcgZmR6hF)#FN%J2vE5)FM;rnM<feI5egE'
    '1N~qBF04ZC1WAk@x{sCUq4^WkllG&608AOjsiH6I(U{A7ojmMDU%~?;m%cjzS@f|~D!wvkX#;f&#M#KBIqZ+vN|#>rgc#=peYveTU9%lo6+x$jJ#3$q7N2v`'
    'bs^RBta=}8eQs8dcPhsxRuM)J^fli%)D6Jokd~uG@sf0syV=b8POpo5qh=ZAJf7v9SD!G1G9E9P>ZeAqDw93K6`A1V#T@X8B5V0Iv)PnzR<-~72LZ5u{RcC8'
    'HxKp>n@7j6lvyhU9=eaE;#!#}Jq{J!{TmxEmJF~G(!u_Yb{a=y3E+uVTx%X}9aj!(n13QZ+o*ubFfF3vF^==q*zMt1s;o0;Fp$vc_Uuz(wSWX`@h+fh3^}lJ'
    'LOHYKtK-U1^%&c~&0r9*OX&NY(Is={4)G8=T}vh3(Y%9+pb{R?`}h_-SN37?8+AEIovKsj^mLefXH*)<D;vFVk;*E)c=W>=I}O6G6QBmI%Nk-siJ;(J#`l6?'
    '256!eDT+mF+&OhdTChF6?ctSHL1!tvUIZXt;;?kx7N%hoJ5zX<j%5^cMlpy&4c*OKmStKXDdt+?py()U%qw&0U|#wxKjv`jPKjVJPw|X#Xs+;TUFYI;5pUcG'
    'N7Z4)Islq2EtYXxA`8!RMH7Bfd~73%#!t|a$Th&HO&GSs0%fg5@<PUBgoH;!ZOp5ym-)^GaiwyRg4i&qlfRAod>1M<+8Gknx!`T)@KYw2Ijq1xC!aER@zsa&'
    'e5mFaoCs4iHjHAaP@uL5y?8W8JyWY5Y}Kk%I4n`_YYI2j$oZVj9PR!6_g3@dP4x)Se7$vi0Mfa6uyy>dQp@np9Tg-TM&4B)+f`jg@4U~M7Z>hp6XQ-p)T~b$'
    '^=rz=m)WmwzpLzI`05M7Ybm$PtzQScxRfgvO!K~Wcray1O`Y$~6&Z;n#c~Bx5mqmHhWqr<k`L*aev3wqZqQ&0kYS-;AY)pV1WFwf_j`m$qTN~UT}^M8EhlYR'
    '7-M2zA9XNTI4GS@2ld9_8t)G6`59Z6o(q`S=j0T=M2{!KgMNsaA{QNuOD4q;)_a((j(%&3$H!^T`*^uM{$J+UnGfU$&3Ct-IN{Y+ZaKV_X_JzR^L=rlREF8z'
    'i0{5q0JXjY`|87&=Kj{9;2_@0jqT#9wOXTM1Zdl`>U>2AOa?W(RCb-Z04lUKvoR-Lu(Foch<1-yR8Yn4ixQo^&P^<My*|3mjV2a<Qw(>Fb7picTdLC?T^ate'
    'f!A}<ks!L6D-%ew3DueewdiK941e0dOS!lj-NzM)YUWt1FzR3z^L5MRP*D=k*~Q$VnS%+7|1Rd1=y}OBbD<3F!NpsYsok6l?%c{_(st8~wkg&>mg>@rNN(h)'
    'kk`YegK%kBHiDB8oQ5!b9OAyUVO>ZID=a$X6x!>mGiK;G0Sk7524vq?ewlHv!@f!n{UdbmG6&UaQ+Zy3+qY?-K+HZc@2NW4%<NlYH4z#qEzi%F)(mk+4YqUz'
    '^WD3ekDvY#5{dM&AhH=?JhF<bNkJ3glQ`-kQC#Curoo@2S~AQcO)WsJKpo@zd{kO2aJm9QiX5rFaWVEm+qK=1(mI8Biik9I1PP>_ltOeI5WNhd3TTY9K|3<='
    '6wD%sw&i)@2t=<Gd>UPO&qrrNN6A<6=8C3HL1+O+Z5!{DaC<$2)WzpQsS_TA5pEqippT*@b>VjUbQ`7O4bDoXi)^6l#3y|ogbU)eu#N{7!PWwMJLpN&Ku36J'
    '8-SXJiZDgaWnFRf&ki5_6XReeip@8B$Cc?K)69vS23EePOeniUCzzHatP$m@g$)hK4Jc0XWg%FoY5r|Wcu8EOa?DsNo`x#T70Zp#`kT@%o0GfB)I(DjhuC5p'
    'VrPyE#Gd#RlGO6NUe+_GQ8RM<Q27z~z&(u`YMAjQBtTt`UV=)><w0obsG*3L4J6SsxGu?}4n)mBAqq$X1Kql`!X0c5SJs-s4$*F0g1Ip|qm<kvkVS-&n$}gk'
    'ITfb~%`V{XGETn>uuhDUa2#KN{^1*Q#+uP`Mpx)tBt;1GZ4|g}FuS*K4m<KXWSn9+V@g008-W05c=AW3Vz7NL(ozT`OxmjytA>`BFfy$oU1ub^U0lnR3b|4-'
    'S1RR73%Syg7-QnQ4XealoL#^=rR5EjfADsdUzbcdJ6qn+Y7Uncn)KL2&F7RhKQvP10$OS#jOF!{G35}h^tqmq_HjcVBp&ximR@iU*S-M099hdMt?)LUY(_hS'
    'KzkzUIO5brqpU~%LoL3MCeXtgIsS1{0kvMKQlP&}^GahQnRN%~wNj8#^!UB`b2QP(C1yiTUYv$DQ_w>ifI?tRsV`;1Fo+RDyhMZ?nmp>3txPTfsfJD)(My`>'
    'ji{x}S)RkzV@w9j;ah@bZU)}4q^U}~8o)MVbjVQ%2|1v_mYFw>#WlqXxq>(gC|tXNel9$|Lkd`6co!l|<~l8<!bEPfHm^Bz)kP)65`h=l6h+hvUTZ7@;>r0y'
    '!cg}s1aX~A79p(=B8U(=oSI8`7ZPK0OiS}2jL2xrS&K`B#KD)}6UKHnn`&8WT+x_YG6R!_@(Cn~_i`-yobP{+M?B)vM|Zv}(?xQlLY5R)c`y8IR_U<`sLJc)'
    'fw#aq)=#*`+u{2T)0(->Y*#;J%8P|UE_3pxQaQ?$m+*PFT0N;`$_s_UUC`R}hG^QSHuLFCWeYl61lZeK$H!H829Ya;1T+fm*N(S7y{a4^f5CF_;-Io$J<OC>'
    '<2Xb;CmW(!z_*|~={1*RJ?1$}3aC^^qwDJYdBeJ8TcV8r=EPl$<SNdT<-$8x%w>pyF?RwcG0*6NITMoSIqe3+OgVVYWk^70%Jk=M%Ics8io$ZUzxAqmth&jI'
    'kMbIdK-H9DJRfaz4~XLm>1A=w&S4%-)Z>Fa4MDE3k<h?3Qk*yn4MNxj3{Z$%f42IF7K4xS=wPTN-TfS3D>UkqKx^?em~?X%3GR@!D+<NTdKz6eQ-ygdQo#+q'
    'p0ZJKJ&u~FWSJ%#uN1Yfc1v(OMChiTZ}E)~;Vd5_p|!aV7KbI{?#0fB+}+Ub(zXz_dPe*TY}zfp@}858cHFLv{nIucgfFO%`<88$vh@-)zb<HLY$HiUP8}N-'
    'BS+~ckY2*^remfZs};)`|4_LP#97<ON0G4vzt`oRq#*$vWsYPYJq&mdqc2k`YJNd8A2i9zarlfL(v$08bh)o-&cZ-K1`i5hG*yJT(Zym#ye+|3^c`6dHxd>L'
    '9|yrtQoq3G;A6+}@y-h?Kp|m`M4e4`rcPJsB3X5*#fsNbxK%|iUA-!po0e#_%<x2?dCo?blmM-P+ddzwjgo}pplJGIu3Mk-iVU5BLlN#2olgz~Y5Y;L7>>fj'
    'P&XWa7T&Zbt@I!vWDL7?ewTFNER+bbNVw0@H935WB9%Z%2*n5?QIjscqrL5SAC4kgt$^5wWWPuq0no_2P*M^W3GA08;h-Uhj!J&Jj;0&S88YJ7y|0~Qrzv7Z'
    '@0-?~<?>qJn7=&4TEaI?H5f5@6D122ym?Y?e?@)ANk!<EO5uH7Pm>I?aA@})kx`^c0<C8GeK_NmT^h3dZ3>q9eqR_tAqcHl4v_TO9Cx<sxVte)fu~&Hi5B`?'
    'zG!aX&Rj_ZEG5f;Lc(EgiK(V}XQDbLnXkpw2vHLdb~(yRrImQ#j?iYI9H0^11PHf6_&kJ@iNwgspGYGP;P341#yXhTA+iH|><A9ryByZ9+`tr(I{{t8(>yL`'
    'PM<x-QGguHM~7A%aq<b{kEAnG3m4Sj)A~OjBR0A}N^8NGsGbuZctncqJ5%fWr>z>ARS6Wmcg6hwi~)l&QW$6#mB+Y8DIK9%C%%_az^Z$1c~0kKnqTET;|MGv'
    '+0SfBSLY2eDYAzliXtpS9&u8aaSwW+D^cb<al}XrS&}NTE^ArZP7HpHZpP5NVkG^*CgwoNtA;}apSF3Lq_N;mW1W*WYu=(Xy(=*Mkdj&pVOr7wMl7N4I$f5t'
    'T4ygYd1|Dy^bT*h7K@$8R((l#iJSLzM~G<bkU&Ern?#*|N|Rvk-wZp#Lx*Ya2hUjtLne(3K?`h}c$A%S|50Zx0_on^y6HKNc=K&amZQ+No}Ls>k4z%ca}_hZ'
    'v8C1uk$-I?WSTG*QH#^M)xHX607{^89*low>EGVvH2a2r>iR($gGkIAukhkWOfo5htX$86vSmIbMxt>SwRM;Vb?(2&XAm;kwZ3YZlX&yYO3srbfJIU~;jX=a'
    '2?F!fW&JoIEJtyK*tkuz`xO*oSzK?X?^B8lc#mjjGUg~y4vBT~LV41y+q?C+O{&g`%bnqPMwbvBgr|rpOqqU^^GHwkgO)A74*Lxg_IHYS(UK@!4|$v#bLutw'
    'n^@t@oK!MFWJywZQe^$(<N26=I=JmO0yrrFPk1NjoTexMv8<r7?)PdWW^9T9DNA>R7>kHMBDNr>GzOaDe+^P86%yxDo?R-7zjI58z`@#*5bAY`gve!=>E9Lj'
    'w~?!7SLxT9_;(rpU4?(~%M$%srhixPolN2!Zz#&q^%Sn*`XItcJ1vKd`J^Ecfgxm-<pOym9&*VEtl}zMIY1|P$t;`Ytts4=k2i1LC322{CX<+=x71AWj7BYK'
    '>(3~a4oG7KtIj^S0gGhH;;EoAdg!*dM`wy}8dD+1=-05~@bu4d4~25#G%UV2C4_NG<}p;Os3##gG?hYmP?sJFA7mUye_&trgHD^}RIf6XY^LT03;CBw(iGBR'
    'Dcd~(P@0vm_+ie93c!f-B*Brbg(Iidm&#Ezm`SaLVyBaR#?gf_%C+T~r4RB&PhleC)PyQYYF%Tl2P%73FUCX6rF5=P*CX+^r<P$_+xARavGVv*)>is@_&y|L'
    'M$H4FI;AcOjtA&ry-h0wJ0+orv;d;sctvL>aDa)KSYNu(t&l3O64clis0XsApd5`p&j~xX9E~j3oO8PD)e0nWy)r4w@!0bmtMTPXJo()`-<3tEqxBNcdICKN'
    'vogMk&zHDbBncDV4wH^|X$j{7zj!%0<6T|9<tls!r)DPI#qtfO<i=?Sni)#OoO~fz)6(;s>v_$SBHg0lOo{vX8^I>N@_}%A-*SnzA2=aRIF>XyJV;}B6%mnq'
    'j6~l9QaPZ^DA7WCrGyyseLRSsX?b>3Ytd+lWI>yFk^#6))=tT{o^a+#11nF?l!~v)ygkZi+~olkJm4p?XJD<}bsD3IBXctJCVVe9pM0b9`Y?;+SsIFL=IB0l'
    'gUKW3BCtqqE6y8R>OKJxiy;#PJ`PSoieuymFceJfljlxl)fqZ|d+c!dBVM~Bs!+lUV79$oN<nw>W^1SVNu{KVWoCSE&Uw6YAZjQl9I2A`+=Vt`W0{+!#~}?('
    'y?rG2*3r@amu77bKJHo~W*T}~`FvD4-aDuq)`SniN;|_OnTz&j_2@KEDaA>_aKWKN0R%9on5|_Jr+CT#-f2U*?#H_Ipk%HvKsuR(t1a1EvS}3;7t4X3QCg(='
    '28txAZ3#)V<A(IKla7h>`L7>oj7)E_ub$i$ft@_Po0h-5UJfL6Lsr407FM0~A<qm%vpNZ^61`Enc0Mmd!C$!`(v9z<Qi<P!!NFjc&A?lkU}RGzLLwA?O0O*b'
    '5VQ5PSR0u>K0ya+kB7b|>~U?w7(+G1x7b3U_T@#xTnse(cz#~F>m4M&OG?rfF3H3Thu&!+NoIHpzX*_Jm`@VyD2}<%i$=H)k*~2XiPw^eC53%Nff*sm-SjY_'
    '@=s$;L=Tc<O_+_-1>=89TItO^R8U3b(hSO_ng6L=nqj##lPs5JST4<!>oX{qW*WH}l1novmu8s$GY^wX&5sMke{h^V*v1Q;XP<V89NPK!2jDrIt(7dpr}2U8'
    '=7V_P&pJMrf=-^1{m1<9C$#*(UcMe{hv3)6R&LuKjd~8B4eDYdLCgvy5A5fR1JA<<e33%2STN}vzP$Gtw`Mt##UF!u=#IvmWl%UWC>tN1|8p;FJc~k<G%yj+'
    '5Yt*<!Y2KoIM5?3N%-CN){(U+f3Rj~iKE@{f_q0V)cOps`_7fPAue(%jJHd8dnEA8U|L<7$dG;ruSv5to@C0%yAfMBgIQlOO9*eK$l{=+(v@2{G<bWu*m}8e'
    'd*@Bg;fT;9pn@nGzTgYi#!ge7wbJtbV$h9558LS^z>>A`yEx>I8G}hBB`k!^F5qY%BFDN55rR@iCd@}N)C1w!d(pNB(@(plT_zPj<VK0CWqe-J0k?IuKP`DT'
    'wKyoduG#Lvw~#@vA{03!(c%lk0|R|F<T^^)L#c<Dq7mIbN%8oeQd$ZvelG~P!XRgk-jgmmndUp>`Vu@!o5-qU;84wR3uZzjs^)i8Kh{-bth|#z`xt|f%#6BM'
    'F+e1r4kko6EeMGG(~^AsXlXH-8j&C`)ih2p7<-ELN;uCQ(gv~*iIHJJMNu+1HgWG)xHwNjdHhhJMH_o&O1u}zga&V*HX?Q8(1^($_kM9QdsRtzzGXEfk(5u2'
    'nJ)G@h;GHK$;IepRFR<%BuOl~Iyz7)R!?)&g?4eL<&)+T@^n$1i>7;zbF*2!NZ4~M(ZDTkA@Jz(E6{Jfs~}v`N}iAFUb{UWPy%tR6R;}NOeR7Ljy4LU>t(ta'
    'H@MqSX95-RY-wUi43zRIZy*5eySP(P&k!!oV}}B(Q>VZ>@|#7>7M=}=aVRF469(fUUM+%<nKk$%Lj^UmCeM-o^T`&OPWU%A<w#a(f;Tl_Dw-r*0M{37V0|hs'
    '=UU=|DhoxRY1E?FNkrC+?X}~GfNjF@V)#S)ZB-;KpM;5SnJW)%&{3*QSGMV(#d*PEbb|pCs12=nhLPvbOEEJ#D_awnWJOkzO)K<0G}ksG&ef#RCXYmxF#`RJ'
    'ADC|@iJ#IzN%yy!b}aNT-G(~TDrUSOtUO*6PeCu`5;_B@N_-8?tKNkrOnyqQQ^odlfjxIGM4>0f{Mm94r?Z;~^Ag;aJT0eVxLJ@fcpB-YbloicbCIE9SYZjM'
    'eK@Y92n{J(q`aaq+^7(fGCn%kp@B}63(-|i?nT^+1-Z<0VD+So|B8q#85nkFK4d(|r^TZYyeu}RFm4KAL&G4T&_I}FNrb3elGhq2?O48$+gEbMD>QQQQEgs{'
    '>nruuId**|k5E%OKE3EQl2UX9o=h)xcu+3#nEA(=niXiB&nQ|cCl|Go%f2Pf9tI~53wMD6AX6WPBxNLR3<rJpscd}f_)k_wy4;np;^TXM9m~|^_lD-v!;ok?'
    '0INr;qO=QLd7^0+_e(+TQst(w;8hDsX9}8l04z2$X}Bou6Q;6{XMWn-t~9rgD_aNh#mPanT6?os;ol+?l&DM4g1CfiskkifMJ&nl<-kT<OtMnkKH2~aRxKMb'
    ';T}=Kwbdmq2UWyt6kJqlBm?EMZ9!Fy_`%k%K6gMG7UQ5oML3EW9pp4BeAR#&3Mq3kU$%}9n<up@rjC$`9u|m0M-I^LZOI($?Y|>EYSW5-`c$p%M~)szD1xPl'
    'V?c9Q480Vq4<HxckBD||U8z8!<GmpnTij4<;fCmN@EZm{ALog3f}=k{15gK`=2DjWL=*T{n)>Br6C@Yd)n)l~Cj;_NoL-N^?t{B8)NKzvb<WZ0=;t)>+K+ya'
    'V}{Q0`#o<o9}VgWslB1i8NOgW5(&U!J`@R{kM_tL!C1*0JmCwO__m>ki2iU01Myqv4rNLgf&P)CKIAmti@KscVA^~L#mL=l1UVr{RUN)(oRjY$Rl90IPl$<<'
    'dK2u{N&Zbd91?J1sS#%PIqgVrie4C^N}kUUCm1xbsE8?$wH>kORY(>;gq*MPqM<+EGWaiCKCB|~l^Z$ncHsNs@DoDtb(rERzL*y}dL}_RyYJo02)3$XZrJ2#'
    'J>@nx)drz*l+U+&jy=rM$-UsExExqVE7(TR93U8!#Y=V|C^g4<PLqdej%?+|R!;1sD6<6bQ;HXRiVr*NcQ?bkbgJ{XeB%~KGc!jqXJV}BIZi)STHN~93=%Ss'
    'PLr+>q{I{@?AfTsWE>DBQeIvO@*~qG&CZ288oI8r+Z*3>yvvMl)UG^Z+jB9B2U8xMoH@=wUdDubKD>D&bGGmW9Ko`oj8<_tnInsWb9W+|NJL`G8?NyB!iDAL'
    '$<}@)x_g7~54UQ2A1lrM%GQpxEprn4uz)pz4?E#PCm)WEjw>f8K|!#rdXpxmSI3J;h+;u&@tvO`d=d%X5W32$EHfVGg8ShqdMZc3f|x7-+t8wrXwsKfSET^h'
    'w3gSF6Aq9?dibXeh7gy%%!cMNR*;A#(JG;|Na-*Z!Q~=b9#ri(Eu0k?K1CNlBQCdh=_zHV-99*FdDDV1qL<}i;ve3~(6j)#f|)tMnJ*?3x>j6ql!fz_02clX'
    '0D`0}Rsy)Zs`l4^;_PTeIY=uMV@0B_+lE<t=5?~6Aq)?!5RZChvT2)TdQw#}@%W+)93rQUHyhD4Ll_UpQ<7r#&T+2ed%D7clP-!=Q{mi;#Wi_#Jo0qHZuZop'
    'R`E@|Mvzh2`h$GR&C9js*$s%hwdP)}a?pJ9cS^XQOnW7cQ7*475u48u3o#VU>cS90ddJ>Qm@+HPH`U|4zpIC-@q{H)OYj8kFnN+l^YGyI-0YOVc0q!)G%7gu'
    'bhDnkwvVoD>9e9w0i{0Q0fcJ(MGN!=PD_Gjk<oDmn9PH4_vb?=GAUl&+~g!B?U;k9Exb$YUIBIH_`^1O*+Nqc3(5>GS(oE5+tQ&V5<j-XyCW*RnYKs5nPJR('
    '^BpD{9pNnYn$syoaEY)J_6k|Ic=72Jv!kdSPOR$)MO_aWlY!s@q*S2V5^$S+H{#TS03D+}d-l!gpg@@!lhP&Uk<vI6+w(rE=QHK0LZZ6<AUtT5uw-K-8)+SZ'
    '_Izg~l5j>B6fLq)TmUO?ehse~@~h}9&WHFluyk|lMkyhhFxa_Evgs1;d=)Y;P;JnO=iu^#W6syQ#+zY@E$$Yt>l?|?LQ_g2_{)-r1x_75HgpNZ_vvwmb)n?w'
    '=QogMuu##7*B~I1;1+YTy}4r4P2C;iy(Si?qZid1aZk2Y=YmrOm0l!KP(^Z6M|dc*Peo)1CILCNQ=&2@Fm28WV4?8L03yv-9o<mg)PzPJ=6Fbfc&{gdM?B)%'
    'x}Xf0$RLXAga<+(lc#Azt;vy7A?@kc7Bk!gmw?W!Dwl%-%+*YDUE7l4ckweg`b3Em6R%-LBL3u4SGk{@&o*c}a>`>giJ;1KO}`&G?qh*I#G6SV0Fu*UnrZ?H'
    'Yv10P$;ElDQYD@2b3Y@8Mk2Nbh(k6o+1?GJVPY3KPp!#4(ZVTWM&X}&N8;hG%*>=xB0u2)MLj=X7(2P<B=pWI<YJi1cO1586(W9$h&lL&cgs_D60MN#ivjH?'
    '8~RASJkMQ1|1ODV;Ms8d;jyS^GcC^^c23+I2a|}Ixon2Cqa$aygSlEtm>ZrV$+m5<l|`;GDhCtyfEc$*-e#y#gPH^-7H=T?AJO?EKAQN<PCq~a7U%;5m8ag?'
    'oydwRemBMp%sE;aoEb&U1Wn+a=%B~EM-R9nJPcWQKKgW-H##Bs(!4w<Bo1F+DUt#8cwrZJ-a6L<x_MsQEjBM2GA!e?=e6t}XiH@L&d}=_Q@U8hy|is$fR@|C'
    '2nHDuTQ+**whIr%wRPil&$(uv#KwGdhbgBE=Ewy-68=9Q4YlReINfodohJI#n^P{{oY!x<ebAMcbVciPy#3Z0K7ZJCmw)}oy+D$IfF7NZdu2sjx`IQwbwC#>'
    '$waB})UtgC9!g6&BePe4CzvS(yzB=*FVa)X>3LU8>@B>?_&<lRoXWR+<{NJVnqP&NbP1g*+Vf5`>ZMk)bO&!`g4O_sg=8F-;y9dvzU(9*QJgQtkdXMsuvkGX'
    'WNO#|i{(NR7Nx?&u_(+hJ{*f>#6nL>8(>l_C8ARNlR;UD4+`G8I84B$$he4nxH@YjqOp*Gh8XY|7NrDwBw(<>7*uw5_4ZSmUnu>n0h!91w1=aQL^4wpOQna8'
    '#PT1H1Z}qJ15rrfho%4iKoA+U>}EPK3J;zkK@T4?B5CA+!gqH<l+h(r&DZ<Y>M>p}Cf>f;JKU`_cenNq;pOUlL3!&|@RaJn$zmHh<2q;5LVDIU6enFC<;Hd3'
    'G{WMBWf?P!(@a^ech~VE{!jR<Es590Y;v*ThziQvY(PBE<I8MfyWS~7)l0+6EJ!$G&Pb_JEMTQbm11E^C7Llans)Kn*l}PbB~K6CMavYxN;O<2<+ZA~dF1u;'
    '?D$bGNzL-8VUe1#VHt&(+gK+hMRvk4TpQ1gTFi4a2E3yqJR1zz*vO;IH;vg@qZCq1t~HnKiaa_;UI{i1f-tHadR^@cKg1X_Gc&Jy9;&D#Bg%L4@KGEm0KBtY'
    '8+#jHYfUyxghL4Lxw4EweFmRq#M`|BzuPOwH#L4yn`!6?-WXY911jhNN&=vobu*fYZ(j`b&pe-I8bClo<#}j=z|?^MY1%AbJ8f~<IRZ8tsR6j>bwbMO6m}j%'
    'GMMd&Na~aRpCOq~L^7aV9uN+yt7&qbjgD}Rboe12isI-O(=<c;<hvJOR%6b@P^N@{c`6qJR5|I&k+$8(32|YcJ9rh4G42nYo*fD2=-CqwZ};utZM$~QJ$C{&'
    'qq8*7$)p@%;=u7$KWE@EnI06QFZINo^F~g5E#{NI2M1NJ`pFr-@FEy$>D~ljg209Of^_MQK!L`NP=p5jEoh<mcoU@CH*VZPwm#CYu_H{9Zn0~m<cA7Z7q}(@'
    '2&H?saWdO_n&6zg%|{0CnURP;K$_$I_~sTmR;FKjLU8ed%WNwQw>2GZ>j7|aSJTG9&_C1uW-IzOB7d3sbCywzdUSYv;0qE1{%u8O3V(ktAW)V}eAt9FS6q@Z'
    'U(gcP<4pPa|JZx;<~EKjU-bVM@xDWu?Y=+>1qusSki`gEqHRS>qAw-e)6GD@AW#%B0s#n%D7HrTv%j<DT3H2<lDqpxyq*|~sLIMcPoDL6R?}tHQwXCj)FavP'
    '61E6fXXhe=1G{3;Z@~bv{b&IbHI^-Yg&pA}+><E-Tii&hC+I7EYz_}8Y*X#-#SgVxdm0(zW#m~eBTo|@HN3nbx)!A-7dN~7Jy3Eg40-YnxbbV%MG)!A+$VDJ'
    'fH?QQL;I!rF&3ps^fBBI1%YI_z`n=(59U)+apv2Xa1Ck<m^0LD=7E%8Mkt1ci}?Tm^zib1S7{fhK}CjzY6Srh%gGd>>B;)CUfviasv_d*L?8xI#+J5J`VTp3'
    'CX!98ZzwC1I3ljE;@;H}zgXtb#k=u~-YUjHi9_Mi$mpwSmn{QvE4aPl4JlWVHONU88fjnTVDW0z%%2tNn9nYXq(B!%5)&r7;>TK4mv(}N+W7C-KoX0#<{IZ?'
    '5e=uDzyOXi)Q5^0-X!E!8J%J7I}Qe-{B=MZ2H6BI<7uL*Bh5E_KfolUKtXOs!(lej=k+N12or@$ruk@=MYIYqv4eR=xe!Scv_!kV%11=!gGogT<Q81WgG4W{'
    '8pZ^cjaPat&sqC##dY$E|F^LesZPeRNyj(exL)e&18Ns)1YNIFLmu@O@Cnvay2RV{d;oI$H*{E#`q3fXN$+|^-c|F(5%%Lffl9-KGj5UCyQvLBx7lYYEy$1_'
    'g^{Xk_!amz55VH%PMP?|`O+{X3}?a*k0T3ArIUwCSzJ;%1be20!y!i*t|@=x<}H<&Wg_MBKDr9NaynyNbQYKJl6sI9^Z-A0+b4^yx)@~;9jqqj6XcoK>BBE{'
    'j`1!1j5|RT6;mk=iuAZ#K8Y;g>}h8MRza}|36X{QBBQhtZjdxBVP@fC%SM1@Daoltw<P*{zQN#U?1F(@5v&z&>LlfA%9pO%k>ar+i&Ka=CjNiT{oM{`2qD;o'
    'nNn6SZt6gHX4A=nlCoW)pTJ^<IW{mW;W(SZ!;e$={{*Wsn(9|0)a=8L6^7A8ADgb1AOigh4P;7cVu(<Iva^G>*&h@P1O66YJQ^T%q$k{8+DQ2K^>j6-`RSp`'
    '-aNOANQ#g^ee4}iJ~17g#?`{!wm}3+yr>q-)aq^l@OH@CSJmUV`r37A0BeOih<Fm5_lw~oDl|L_B;u(URyu?#_Qiv#M&wXEgPP-c>>Ltfj@=Lt)a&uIFEgW<'
    'q)}IAD3j<QVt{x+NwY39WKWSv2Jhe2_>M=~MQ4hJWa-Swyzxo8eQ0YUKuk-iQbfPETEKt~+H~@^>Ar1x2vm0yi8iEf<Zr~#hc|V479W$d$nJI{*>3DUu{s<;'
    '_T;FWOTA=WdvWALwJenoJf-!imB?nX)FxJ3bF$3yD$##=8TI-J6<92tBSG%CF7`$_=tkj*afFg~TSZLm?TEjtJ$&wq=DS3FhnCp7N(Fg^mp7$yzr_>`l+8Uu'
    'fOXD-q%t1O=2><-vofD5mjjQ~lA+g0q^sb?${;K4ezFHsDO9}Y*c5P))rykTxNDGCPTRcY4cM`^l;>yyEXI?Pl!=bZhxVRICZfhraubn8x^_;VpZ<dGzi^lE'
    '=Ax(n``7cg=8<w2Kj^sb;@XM{0{PF9VCD66fYSzozajr@yi~$7$eGt!9}R_zXoa^7Up*>tlvP%UWT`<XLpKJh%g8Pay)@q8@bKm7-x07hjXo=dy>ix6&y0Vl'
    'U5XE+{e*60b;kzpWgwRkrPX#xDD<5t!6u^{V3?I;o)A(>=MrVj!oZZI(D-kKtUwL+WNn^40+s0sC?S|T!mC*w4w7Q|R*T?Tiz+DH^xvap#l5_cr)vaRBSr4M'
    'dLeA=6dD7uy9!Ul*)dl4TM9u4$+g7jxNL=%0SbIj+~dYK9nNS3RI&itg(rzS=su}Ml-RjU6^u$TxFDU}!B%&GO7m)}KG=b*x*e!vFW?|mG)wJ*qQczzOXTpi'
    '<qjvh4sS`FD%33dJxj&e&RRYDM)DfUeZ6BB$lcu@3uWEm!e$?KA}mu^@oH*?j__LU6F3S9BzP-?Wma>&VFZb_YKMEBqNUieU8wZ2%==G8AqOg#J@8|~tZ9th'
    'iRXJm?`_yU=x}7kZqDz6E>76L&7^%hM6+<eJY>&U#9xsZAcy_sa$dEj3`mxCEMgU8T==<ZxvY%dM;p2`sU>uLnaDLMdbjG&haDhxb9UDsj27e*1S@nOjfUvw'
    'KR`9sltZr=FnTe7vpBKcnxN{JXQyxSL09tFijLCH&Mq#_FWxX><5ysGvL{vKRU0Ctg7@V0b*)EWDRFTc^^y#t=WU~G0}r%w?%qy9x{;6?x%k5Fn&bkTZ|)he'
    'pt(6I!*wjma3G1@J=8~MT8hqwvjB;GJnYlqRD#j%V^ne4zJh@z&&BrUUHhDRr9kRB<W=ZlB^I1Yn{!oYlxXpXBk^WB8b=pU_w5yGYc7B&=lIv(TJ5&hmn7sX'
    'I2mC2`q8KQg2E!-oS{~cG`{!5tu7coopB}GrC{Ii+QXr2I~ovbp~vXtIvf?fX07KiI{m~+Kb<N}M}8;pDkh7F`<2P{p`Uvh#l89l;^Jz*=Qlb~H&Eww2F%;l'
    '>b|&_)3FK4wLY6Kq32_E+0>6YVwb+5yThx@0I2KN{DR@=xih9Cu?<w&?x`$YBq~edl8&1>%bavaFy0I&#>tJPz_Pwen+;;Sfj2MCb_K;gS6-tb=ruts{a*Q^'
    'qRa$vUP+Z@Xg1qK2C6n-M||9hNW{jDUb2~~d)#U@oTp^q>YnWEh8snpJAfev()Y{rXMa0;URj&)?Z71Z3yjCkdrGVvi`{}1(}<PeKk}bz9hF~=1MnGY`kM2!'
    'nLajKN!v*UsiA8)L5swG!Z%g^Gr_d-onYjO1;{SIL<GZ*!*JqQ1g=O!YT4$6Kom=U6kfXn9lNE_a|9rcWBE*u5GzK<#(&YFIhTDmET~)S+d)7@-H|7(ZLm+C'
    'l}0F-KB!b%WoJ%2x&aQHe*IOYQ6%oXwbSaL9*N`ExmJX-$NjC0Fz{+LK%G;63{uhXKGNitsmpdK!-|G2Q22tFv9BQhlSy|tJ&U8*G7Zx{!7-gw+mX&6+*E*k'
    'l1)&#15}&Mq}htuWo}tQ)#6YWRm4--epYHS_JK%SDkUuUmYqmK9o56rg{_l8IeDZ#yqZYsTD_s|c9Znom{5hb;+`crN|e~3^pM1fg!!aicA3_(-;LvRucJr0'
    'r$<1mp`I5caV+T=4MzrXiFMVQo$f~G+HPa*eY8nbE60G-SQ%IA3hq@jViwP+L_aEKd&ajjt{34;<%mFT$Z_B*)JeDO4t<xZ>VtDU87)Wsaq8vS%pEAk_o-f9'
    '8Y<gOg2Xl1>vq`zl4|CS3qz<~dNGB{-D3|cqUkYzxEH-lRt^8Aj>IP>fk)?o5z8T%q|s!6UP<rLz1rRr>9{x&5GR-JHyRD~0*X{iG|Kvxk84eJG`N-;?G2_1'
    '*Q2ZIgjaQ9?nYTgTsFy--Aw||ob|1>VjDjqh=?TQa2g1-Mb^N(K0`B_FRIqjznNt!YpD+NJW|8gPs%3{jo0?<>7<-_0K!K#{#oG)?lu|;V+~@|jQ9(6+Kt8+'
    '?n80&ZzzL%sA>t*X*RSQQ>WF?o=niB<IL1S&wLfXap1O#_aouipi7&ESE#8mp1`Lbo=)4umxTol(zP9hNiFX)G4dVD(5f&QjofL*7=n0B+nxwi*s_n}*3(IO'
    'Lpaxj+eX26m5w57wPsS0?je>N{qe=X2KgOxBt7g_>nKz#CvIWUJ<GkD+UW$R-IY3>DAQu_?V|$pE*n)Wh~dTDiOFjynG7Yh=R*XqAl84eX@53dq@nDf)IO#G'
    '#hd^Ixc~%cSLs~g;4ji@btl0%&|UiP4&}ea{J61|wVr~yskoiUedZ)`pZQtbXOzNyrYd?|rh5kXByUa!WkDe<+MzeGo#I`ri{?}tgh}DAQSV!AwUkW<`R_Ds'
    '9r9sowd1<#ac5n|`Fyf?Y79YQF;Tqwp-7B`hS0qP7le(_9}q(=q}0IM9HclCS&>l_k^t47)Kj5iQxx2$nlnrEWIKeDYr-q?pjmODyc6;z=1wGDD;fe*E#1v('
    '@@{_r4JYdw&2e<4$K}(+E$3%RIH<B&(nTIMOY$|&689lLNs8OiAViDz2C;)YU}-egxV&T%{InQAU*&H#p1vwG@o20Kt}4qY3H&c!KJO`fYX1^{5XklKbj_Qp'
    'pTGF&>nc>e(o30#91Z{$=MII{r9!aqjXRe+vSFVb20k`hR^es(ThZ#<k2rlEfC+WW)CUyF)M$MQywh3mQ~u0$!?r)u$rSK%bnpzQM2B{#hUl>9|0jp?-^c3u'
    '+@`d7RsN-(s&uiIgBDe6vqVYHD@<1x6^oC;2T&TpBk1H9R#!&no6vlzL>V}2E@DU2yE*ld1#)5GDeE-N6iwl=2ym^PG<QOxgdmQWO4K&C9XhU+i+g!(U^qQv'
    ';>xS}1cb!aJ4qZBC=O}wc#p?Uc1U(IevD?JfZ>u`M!+qVE$y4<^ft*<WT$VKe_QQlFDrKFw56H^SX(-mQ$y~LBB4{}p;pdEdNjy<&a=sq_n*MsXga>h9bbIK'
    'KU7~q=Ar((Eal<VWs>R^xUx4Fa&jBT>eJ(NkDZh(4J?^<xU&d2qKcjbF$&4ADBVaAqPsxf95=CHSKLI2Qn&YneU?xGKwS(7!MbZG1P40zAVJF@A_etRs;zG9'
    'Nvzg%b<<5IvREh$nblBkbie#+2xklXxV@<-KsoHQ>){$O*E?1P9|gK?qd;%uQ0L%4_rgAP>1XS$WTU6-ALt;iXd5L3r2O^tm&y$ISpviwjy%_CeEH(5I|OT5'
    '`8-j}xzt<ILo5GQ2wcf==O+775Mk-N0)(aNpM$OxR+zI%;<(u?yYuq?95PMzrDtsxb@}-~_;j?sBU6z51RosvcUAiNi~Y=b;GNZme+8;s!`>Yjya4S~#&Qh4'
    'qxG#5U84$5D4A3E#)?BqSZD=yt>RugN~Q4Z{N>BDXK#D<R<!pe$1j@h$Q?^A{BaKT(c|l#w213(S5afsO>0(=tK&u;^vzVD_Z$veOSyH=1uZ}sUAKmc8Vhn`'
    'I7h4_sf2tTDqbs2CP{X9QCh{siqtmgByAftd9k1qe8nW63C7wJ3yKF?=Ll4~$*y<;lxQ+e(!D%#Cbu2bGzR=dypRZznerB*W8FJergm%cK$(A56JW<%alP3o'
    ')S;HNxd^1)2{(|Y%}!w!Eq%5x{qA;CVsiCkVW%qH0NP;h%}awEZztqz`r>7-+Zs{Tm}pvYXKn9lqi%}%C3kD1po>O#lWp($99bDZy(ui3X=~?obZ!-8*5lBa'
    'qhj^-(wQSG0fOUXP>}tgEbb%Di;_8;<3m|GUq)J&xl&}L;_Q`fh3NfS=n)t&zc%aS`ypS)v73@p-%j5~5cAdl_L5j;fFn;}OC1$Mu6wGKib7y6O5HC?<C0i+'
    'Ku01EOYRW`Vz4&1neJ<&o9MrFb~EMD>S-+Wz$G7!?Qgwl-W)$Jd99+~<~`9nel-@TTWu3G$^u{RV1sHYoUL(|4PK*(N-yi-FV}TnJS1kSPkSf%9g2@FJ&TV3'
    'RU|W6D6&*Lg@XqAT2BXg%-azC@m&+k?|k1=k&`LwhH@fP?_y`KM;C7I^e4w_o1ULOKmT1ho+2R85K)-2IYE|4A<M0s6lY#3Ql2pbZ>i04(oO&bUm*~OD4|h)'
    '>%<p+f9-}HciD$ZiMdFe5@6eU(?_<|C?(|5XRWWxNxbjcZsOWY-Cdlob5qxArFIs28pCYc&eXb$3@TL40$<(GdpztPZrbvF!!3Ed&@nvswLP72aJT2Zz;z{?'
    'cz|Ot&Oxh#uG?_@>cWIacQ;vo`4m-7WQv-tmMT5Q5!{}mcZBXkagTioHSJyOHhV8#|MKhGT&RS8VS96%r%nikeu`A;_w$Rt0hvl$&YNc!=f6ND$_t~~N_LXH'
    '*tlZAgLbkLTls3>QyN20rS_m>#HnJGhrt8fCf8|wjpdw?E|_yr7h&A3@#C2!6fnYuGOla4hi>;s?skWjxKC7uOylb3I!b%4x1SP~F4KH~RTP9~hb>Bybko70'
    '(a=in>IB4JEdq;82*2+h5i^~j79|<<XQ^M0jjQCQ8H5F?b4|D}wNDB8B?cILnMIWl{xi4Vp&PAoHJUGPDxE-e2^*o*JI5kb0CNTsBNXN@ly-OyKSuu~tZ(>>'
    'sz#!kRPGSmB^%nM<&n}Xl0&d6$y7(qr~*I`PZ^#`PMy}F39Z140vFexec8+d;|Nn|+qu~P61`^MUs+AoWo5`LbA%^@0A<LaLn(DRMuYK`;G~6OY+GhxH}wM9'
    'ocEipqzYrL?Zi)7J5HXG;$%1EN3jG^dPgA6=y~_3&#4-gUC;HL*kmtZitm^0=amU&YS78&<04#xLBZz#q_85;{wTb%obFT^BC*9!_jzegnb&;`CwhFTcSKiP'
    '%7cj#B@fB(K!h*Ys!?4cK}(=XJL!BuLPUH;8H~+W1)0HlCb$?mc{{yTo4y-6k43INPU*9{dd!CtAIk$t4(QZoc-3WGHgv6g%gtPxPt>4X|6iTMH=%?GpOWEy'
    'N^dW*Z1>2lY<kIDJ8tm9#5{*$wc)2YP6}Q(;q`qSd)v3b**U-e@@~|Deya@3vkuBIyeB^ZgE!+mIOKmkU09bB6OJ$WnxL4Pce>FE9k(Rk?5vycYq7Y`;@D3k'
    'Q(e}YXjevllWx#UpjMt)TTV;hen(ZH*zprImwoJy?Z^^+k^)C2(q1gq%i~mPQ7n4H_LRoyllR9<vq4SOxEQEN=PgZ_R*kdb(t{KA1z#B!mYlb_V}n#n{`KlL'
    'UryZ`c7!P+x8v8#4xQ_&w~$wPXVNGWRTyuRZe8`kMqbs^KkF}Vh_#XxQW_&#?adi1)t&zEJ|X<5v^U>tNgMRQc3$Ah6%qjjmciD>Q8be>%jK*a*IU*u&p{Jv'
    'I7W4U&r_~7kN0M)3lgtE8z#~&*R41A;#$ijBg2E(LB(F5n1zTep-J>^K3y!-56o#8UC%SPZDFmFNM-mUw8)zTu|tL$Z;zOGhU7~k;pOQUAy2XC4QE*rC1^yy'
    '%0i=z;N7U;_OkwMdI?*jkyuNURO5t$r-^ZZm)Z;R3J!tg&_zLFAi>=j9^k+xVZihDNdbT9QNP6iSdE0HA(>3?kX$A-S{f`3GSQL>bu%ETe!5R`K57Aln?;E}'
    'kqsZ)D7esxr{d$ELceOZr_sIdXZq>hc$xaaW?aV!k_X^`YOQujgGk}h4Jcl)CA{PDgOd80MOR0jnRHCAOVgjye`{F96A5<=Fz5uj2%q2@rTCv(wMr9`&?K-L'
    '$-Ca;B+z5EBeXA<?nu44z5B$R%O}W_sV3t@7gIA*YeLhBDp0_<JO9IF|DVsF?!WN<s#S5!wvLKOg}{i!vi)+UgpjCWfsAQth<+X@J#>WUt6G=oqEoGt%CwH#'
    'DgjOy|Fh%7$<s+yHC%QMT*n<cgC}Xr57|f5Ow>7~_&KzYV=nMK+qY%4uD_uUnP1Q`^P^?|fQ}wl>sS+gLVrMM`nM(jLYWTH4*i+Fz3ncjD;Y#0tqZUMG8$i;'
    'TaEY=RlWIup6qqaXY^pd8&V!fPUu3%xd#SZ76XR`6bu2=dd{R?nov|K2t{R*-;!m3SGp(cIsAVj28#6amqeLYN%G{p(y8NZCZ10!po23{+s+$B9>A_Has!Xn'
    'LaF+M*{n`Z!-Q9{tRtJ-DB0|2kjoRM4TXhOSRZOdqyF3*yuQ!eSyyIh`}QfZUdJJU76oi#*TrTSzR!Zj;ggiA$lEzZe!;4bHkd*RPb)IC7Jg5*<=n&>pAg+0'
    '+ZJ|%Jj1ZeI2fLt4eV@!_+9RQc(gtiW^haH+TwH@xP7rtAi_@jL+@M|16{y~B}4bz1dl$D(TJ;52*Q=Ty~trs^GOet+a5zoVtc**@V{a20$oB@tJ#PP6aq3@'
    '<>YBM^Pzj>4pmIiMH_;PS(*L{6$>AZ{Q(zmGnxa>hr$24{vqIiu07t}sSC^lhr@HF$Xo;$RiYpg<fjticvAZd#Nu2}7r#bN`(29vx^HYnClsJ=xh2+;*kVS?'
    '9v%_01{$Y}m`=5sJg0Y3){0tAFGQtyO0bI5DcbR9vF0SH=A%$AH=_B0us{EQfh?(VjPryeg`VdkcciovN^h_Wl2+2z*agiN=@yRD*1==33XZ-mKK&sv{A(ik'
    'X;6L+=HRd>Kzfm0_I|^0<-APMvX&HhpyIo(l9NxRs_3?VkF$?aSP1h5U8gMXlDV1^J|9u?cg$<SX7=0F0wM8l`#N*<w(Ud7i`7b+2O4)}mb3qIU{??#gV-{o'
    'qmUuTB>@sMkG;r$oJW2QfI)-<H-ZgM?<n;z6czB7#6<1dJ{EQ-Iu2|%qEO=Z(sy-JTc%M11Dg&17k^O{Oh9G+huNEj4IrBhzjJySa_R|>P}$&$EQxBnk`V%K'
    'U~N+*3WJeyN0gGK_aSY_UxO(KIE^E?l_UXdnGCae=)jTk7F?{!#ayt!Rxak2m!3TzNh3ivCSSy_oc&?2RQ4e`IUGT=9sQy(Wl+^5xH72GVid^PXz+eD)7mRO'
    'f>?5}n$z**y;GqU2=^F$L7wUnC#uz})jh_WE|Fl;YALKpKd*T)kK}<Z6wFp92g+ZV!`jjOb^MN)tkM38#Q`_ZKqKzrgxjj6e&r%J!V1W(kh)ka-6Odycxn7S'
    'H6Yg~lkL8xk#-FBkyUxAwJlf9v%6W%6eL7<My>E>r?b^ehV2feuBRn7m*gUmW15&lnwTTno9`X;{(A~T?@?)66QDHS3|ngUB=x{`hoo;i#V`pL3_^%R)kYnX'
    'Y{+d*3pp<4&mz_iDP<Cv&Bl;flRhnGfwU{K{h>@*jYhhrRYf&>q*cSO_3Y|MqNDX+v%1auT!^MhLR2O#9%)WYyXmp_XW=nQoKbeW2z0|JHpW$yX0LnXvu|JP'
    'oAtG^ITDHEd*S56aW)Fc$wlK>!9IQyf#eNed^}ojsg>?2ut`%SIsxT_er_oh^t0TK)fkAb=<my*x&mK>)GtEfK%k4Zim9aSyh2IW<^6PzQ2sHW4F|BxSvpcb'
    '9_b|Vp3~M^XS{EfJN{pvE<U8k4Z60+wtr#4{xpcM-UQ}c`$Bj)r5=q1#Lx0)^!r5jrBf>B%}8B%h&N;2t<Y=rA<l)uxiZo+Ck6!m!Z32o@XHiw=c4{<IlYDD'
    '8KB7m?VQTX@OPN$pU-~{fHFHTEx$rbmyga#S?>;5N$A7E4ugNFfm)DU{@U94E^W0pl*Ru-rdJRTR%7OWCE2LPH-9RVA>!q9n2kF)allyNq%AP(3Ie2W7s%dP'
    'MIel4{5YWwcZv!aOEGi7>(^%&z1MFpD>#FbOy%^bmiR#?u9YHwXp}oTVHHNWcNMxK1xVQ5k;HhaR`M*m#X*wfi(>;>iz~WB49{-LKd4!JU>&C`4hKs=zZYUg'
    '{xVWt6w9QhJTXyVSvFKzNZvzLxtI{oFHHwSbV>pYL&8URWEz@OX9+`#c0f(-t}@<8_jDQdcoAT&?M)$}Cj%h5s6Ya8P1ITYzAjTYR)k~WzKLK(gX45+*bw8X'
    'sTfCiK-Eoo-HHUN2`q|4anL7L*twQ*J_si6gf6V`LKvSZ)EVnq>M$3E>8G}i(}zc~3yg*zn4w6?Pjgf|5t@Ovg-17i8?+TYx2IR*(K}{Aj-n~hlDVQfDyieP'
    'R)r0R<WGWLoUje2L(HQ}ayBJ(RGHDP?iK0A$*W7gg4xaef<X0IuFgl-NUpi+%;<xJ+kQhaZH9I!R~$PGCw866>Sft}W+=p4yXeF6o{S~D6lRy?!&y}l+2wt}'
    'OCtM384};6D6Uq4>Utm{Yt;Z8`;+982CJHFAJ2|@2piXu-L0pvU7@2P6#-+G95)*sQNDy?dEnb_?Abi?gXTG_r%?Kc&YOh#;P2p-i;iV-y-Mhgj@og0>l_VB'
    'U#_2@*fA%i=Iy)@9R)E`HrXL40UzXAGudw*`ds7n3Ue`S=zHv`|GJL*v2!b3a=oQjo?XPd^1_ZvYt$kJdxfUM)&dnOaDsr?9$HRN^CXR#b77Ch;W<3}h(>3%'
    'RZKqY)CTm}>N-(6)>(aEf|Drc)}?(_&%V>BKaU~)QY-d0T&d|1aK!L69e2uyz_eI^U6@J=tGkHUpC33sAPDb>&MW2V^++o;%SfA<w#2&{%^M9gT9?W>=Q&(n'
    'b)LPGRJH17O!{h4sF7m=)DXtR{^=pIh^N7&aRHBqZ$nQtRSXkRHIW`2^@--AiR9W3jY(iNfrXlmKXOF3XgsM8M)}BW#CL+q)mdA+sIXMJRSV(tD<NuhBw#?8'
    'TdRRs7rCfKHqQAO7^4#63r3nYlHk%f&qFise&{Aw`@cYMqE@9qO7=ppi-I%PZ+1tKky{%Hg7QjR5?JYyI(iv@YZdBdieo7QO|4gakT*3@^Z9Z*9Rne}rG!+o'
    'Y<|1qa7kdM7pRSB_w0wHz-aegp8jxt;pDj)_phdNTgk`|7%rSrg3{jOr;Azt&e9?BLp!StKLL@gwdefWcYYl>se++f{0bSNcavK=>Pl^9q>pbNMJZ-<B^b2!'
    'lGc9GVr#l+Urt*20P4R)&pBJYq(hDRlChnnggQt=nIkmG<VJU+<qf8;zlHM%k5?1p0~0N?{;gx&Pt(@E0f*C-<$J>s{*>y$YLk(FwZJ@L9r5ErMlC4TQ9jP?'
    'tMn{7;*C3)(>%C&QbNH}!9Xdl?Q)b4mC|pDf~8CWH(Y9cfFqs_16*sRuh=xDLy-#2ntmf**!9;qshH!>2qbn=40c@>oFz+<kESv+>jY+TTb`IZI!Wywc6fHw'
    'ck+p(q65)phBHeOnN;`azx(vx1Dx8V3QL2(4lxuPp6$`IUHY|0|J}!Dap(-lFcC~A0HuQ{Wr;4aS5QJJ7jLE%0d$GtA3EhAhuUh_og_D;dDDc9;+K6|T;&nF'
    'SS(0<bHOPT1cNSQSkFI4vno$xVjA$dQwN%yz9&F)r~>}gaU=YqX<p>QM^rrwe2L%mv7#$oMIS%E!Vh`K$(8COg+Wlo%}zHite5sC#;{<?db4YT=&DDAq-*<r'
    '^PY_Tgn%%4YHR5Rs$r5CQ#=R7a-g{zZV~H(arZD%2C6$gPW6I!WEW^}KT|5fsgggf74k9)@#lFuj)1@BE1DiD>xR&=<`eqANKNrXsE_Oqvpw}++S8tBg>|c@'
    '*7zCUMDq!L{=A1V;;yf~{f%+C4}*eufFK48#AjhTxhEDZh!F(b@vIdBtS_FOzxv_D>$B$p7SOFU&;FIvlIwLCeIrl<*&+g*q+f1R1KMG`6Ad#Cu17(25aFE^'
    '(KZq%Dbe<#vR)a{P;-z?a^6+jilbW>Pq|@6iEqxm6h!L(r*SY|=26X)6hwbJZ`ZIj!AS7UvS<7$3{9_qp`m?JYyRmhjTIiV0dFJc(-%Ezt%S?z#Hl6cPEN=p'
    'eZ4l##bQ_$GuLSDO-S?CBZqzG6jT}S!;eySlRl_Rg{~lt3%AY<m4A@+%2t<e=A9bge8V_CJ|nbP0hM2-pFiDqmO4n6LDXazwnkOQqo%2up)YiW!Ck~wFf(%u'
    '3Zm-q69r@Nu(<T)gV(uRnjB)Bjpj#kdd3gOZKaPaI!d)xZFC}eO9L?1djHgvkC}LxogD6V0#O8v$^ETj(521#hq~>lXtQl;^+T;nFZEojcvc1C-HK}_;~DX5'
    '`Fv(^ZRAzX+l?}<JShsSCo@&aU>IoDcmeY7iH_{2@5w=u1K(vo<=2rqbBtldIOf`JBadHhPE3vdgK4uu3q*%ak*LocUecjGXTpv;9}*QB)gg$VFR?nCwe*8^'
    'I1%V>v9u3pEv0|*7N&x+cKq2%CxP(z<Q{lic4LH|cFYMx;z;2#zM7uG^3$r-v%2LqYducv=XK*}n$(fp#m@ENu<ac9zuqxd<EL#<mQ>@?kbOIS?0htM%5sUU'
    'uWggtq<693aFNg8cfdCZo=VC;0y_M#ytnTham-Gp*VjOtjG7Gt1H{o{eRP2BeSsR_hk0P&7x8fjoM1W=d$Mfrl*(Rq+TA1l$k<!dBR{rdroB37SiD=)BJ@jL'
    'i=V)6wk}*D=e%kf%QaI&UPd(~3>#X<0)*Ugrx&k7<xbD5R%<dGsQfrqM}ac55=~WZOvXpbs%^dh{911*Vc^g(^l)E(jg<Q+SA1t9G;tPdR&VMX2CY(l39jg*'
    'd^H@ON`2xm+K<kdxPk_gC*~X{n~i+y&BjJ8yj%6>c?;Sm->~J$M8rzN^=88%QtG)wNZ5mt4t+<5Hxz&kgjMy*rCZakN2G5k$lPF68t@QLbo>K3rOu~l6zveW'
    '%$MNgDT%#k+S5i-KD#-$Y^S(oc5%0kWm0ioIKJW~6>Aes`Hs{U#Jm@`q2|hbVL>nG$Vo5KP7~>5Iv%F-p;KnnAKQ^aWy#>3%sk$Stwa6sMu*UbKX>RYcV?qX'
    '+#qjp;ZR4$sV5g@bLpasNs<riG?9{}5cZ?^WTA=3KUl_n*l0U&j|-4)Q5<VNFfyFA0@asT9hXPSy673@VI`E80+}Gh`e27n&gc2qMR)oF6>C&MNzp-vIT$^n'
    'UlPI~eCjKuvjs>KuwkdU==6C{v(<1LkfXyC(K;z1AF4d83E*38H_!i@dW9{IwPnw|VjWsf$LLBSn4M$kU%*3a(>*IS)S<RK0DS&tM<z`NkduoR{(YSKlBgZO'
    '&1t%Gj=$<YmxOofRxilq<pdY{qG^uVQ?=OKg=(k3-K==R?65O)?*;afKHMe^piBF(YcSDqY*=(xlm2jBI$v(aSb%;ia^bmGvc{h;^q?pjzvVh%u0P(Hfnt`='
    'gx0g`aX#G5M&I??oysMSWzhWpiZKRQ0%Ho$<1T>S&bc(@75KXLO%;gyhdl~lnOYPWb2uz-2s9)Rd4j@0QJyvX*d3>B?MsfhDjRAXi|(VNtLbF5urnqxZUI_v'
    'eIRMi?&=YM%}`7pj$WcutA{Z}7*ZvG-+V;4CFur`CSHX&A#7KrV#h-wi3i8&u-2?obH{0u5jBTqO7Ip%WR$jNP^9YAf|0sMUMo#jTCC!-fGvyRCuMpP{oSQ{'
    ')UEMYV6Ey3Yx1FhmR7AUer3bpSAKKT12gF4b(C(PTy#tmZTD2u3@~8fN!oe>(x-(TShE@eT7qF48(QXC&Am<t3?BsiD1(hUy&VlA%=YI+Xw=c05Iq5r7@{Zd'
    'U!rIH0|P2Jp++Zqv&_&}_+^$wKcgBd+Il&i52IJp+i7$`<63Mb(Hr<GyS>Wh%~rIS^k=|QaG2b|ZV%IPMyU`8d2;dAeZoW$p6L)ec*q<mJY;nhJYm8oPZWKF'
    '=Qui|W6`5S=qP5cp=0J8zpiEhnoR+}y*U6L1B;iy;ix_M08AXLGcKaU8o$q2N?jvq@+4#t{kE}kf{t5o#i*e8)FM!pMV5O~6scwqUvkD(F7us}C)Q4&r%itW'
    ';!gKT5C7ZiFWnReIg4pNhG&BdMkRYSkw-tBpT9Yyw0ytojN8F<e%B6CmPr6Bd6KP54EmT2R<zB~p>Rmz@pow>T<gPxZW9}E9IlYF4)Ulvm9w9IlCgCvuU@?T'
    'n;xR1Bm8p7x2VjEZRlnu0gn9vr!b}8qz{+bbx>y!tdq!Y^%?{!iUZVev2krTe$w1-?VhC0OC1pqo)}yrXnwCpx=u}ca{D0gwVxMDof^I84Hw0%q^5b84IOpr'
    '??*Eas*pW}=<`Qsr+svCtbhYP5oC$hV4A!EI_b9{rWE#+dO=V}q*mY*E7+Lw&+89vGQqc8WJ~CGABIq^2o;v@vxdXOEnqF`gi;M1JErD`{^0#xAMVC^#z;W}'
    'jH;HJqHDxRue0=3xABO`*B99kg3{i0a{o}=7|i{X{Z?`G*naZ>I7eh2eaL|a<*dj>i?NpB5m-Bq$!GC6WxnpJ*sj-sO>KfRwHC=J&SfjZWrFETdB$qo0sXv&'
    '&XdwX+scR==#uANMK`Hf@*!eyn1t-)t;Eo9csD!}XU><QT%{k^zma|~e6?Xk=4xA~0K_tRT~~oz^<bqN7b3-5yousXLf^iDzR_7fr2tkcHEAZ!BkkI=Zy@tv'
    'jy`{JvjN*#IUR+n)u=WT5$0Ga<c^_ldA!=sPo4;BS#DD#Po7lmcV3s{FU4A6tleAm+<f8L_3=^Te0GTDPGTRTOU~kRm~c34+^y+~V^3O8^JdEo8{JcdqQhP('
    '+6Ggcv_R6-6(J?!=kZBu(j(@962B7*wIOZtSs2c1Q`9~#e*+hlwGeA<p$jzNloMXL?+S@+0GrMhzf<f|9ownrxC>joNAZ?W{xJ{->yl17gQr%y+6UO-(j+;g'
    'WotbuD4}htRNaGO8lw$@8nsycKppE>0)6GptXh=+GqApN<(r^<>19xwS;JJPjl^3!=ZUh=Dus%dw{Z>5Re9{ClS>N^dN=^{yMJ8(rn3jFu4{dc3DUH*FX6~c'
    '_tT5F-lsMxE>qpRNJnYfYJa0Z(E@R+V4=w%V73vF#iF8)Q6RVVj8Q-z)W;hIbnP4K4EH+<44IwtF}e|_3?yLOlW5{Xo<)IR4M&Rs^aCMT=J%{k95A3MG`>fB'
    'qWA3d+0SRba?Tf%1;q9d*DOam9@qv4g=2*)fGMu-5RP&@p5AHju6O-goe@wngnl#S-Sl<}3w=i*<jo@%KUuhvHzydF8G`1prBYSc++mi%+MC=?zzIFQBxn5Y'
    '5d-ldi2K?AL|l!9onldOfH#a)tMbq9Y$#GH2~viF*@LjAuJ6UGwTO?95cAHW8)*bfLN5G-iTq7TQX)*e;H!C#rZc4_$tA1N9))G;`~0|$>CBEx6-80i&(l|w'
    'zfZz7LRpN)MhjX5&cX=b(}jtjE9fxoHR)XK>&)zy$0Ueqq?@H~*iD=?Ht0va2m)U~>w!6Mc4+65ZwKZUEbGbhi}PP9feEpjw1X5%=lSL7v$L<9W|?JY#1EYK'
    'IDdwW|LwZ8j%qX02gJRTb8Tsg$4!E9Of(IJ8&+qfu{XhRCofi*DWQ7UaQwC$a(W3p>82)a9BmHw(&aEAxw8TknW}hzsqV0Y%37!mbq<+W*%r}sGQP*vo-oi3'
    'b_79VhS^}WKrV66#~8b70k6E}Yxkh{%g?88&TLECLGS1Dix>Ymf9*bGm*d{^)4!8BO{w7{xD;SpBoS-kqv}BtweY9t;-l(b616#lwZ6~`)b5d$-%>DxU|%8+'
    'HijnsUWC>A^c_MVE5n7#n88-`*u8h5T4Y*kQB#?f5KAswz;j*XB$Y}z%dC1_=cjS>SF4k$f)x^N2Gqmn%d?}%Yecxscp556<hTY~YonaEROj+pmY|si@-Z(|'
    '{s!P(`jhv-V8Oairjxp0<l#0LQe?bRVZ;7Oqb7d)3{5-4?taYl21AJgj>uwkHO``Ez+gt1pgv)T?ot0tOma5dc6%;c$Wd;;C9BecTZJ786cl=R`s3TP3q9ME'
    'uTk}t6IAfzt6ta@&iePjG*DF<62lp1f;nvlH=NmGIv4<BV)Jw`dD}KN9PpUH_eZkc9=MylJT^O{<HICL5!ifHd!MKmarE@5*()_vct6p<!>ye}t;1Y$J6bc>'
    'b6V|#8olPTMuY=OuA?Wdy$)7`uv{ATkWsqGNN_jBn+PZvNY}7_CSUe^bc=9XF!xuhd!i<XAtU^uXL6S(Z_Y4%vB&8jI(nH$ntL|SAa@ir_we^&n~%>~TSKvy'
    'Nq}7UaF70?ru1qBv={f^J<1sjnzk5#WW5^0DPXlf9d*<dY_G%lbM%xuhw(SI+kBlNrYL215u9HELrb&x2#mkY(@eXdtgSL=w~ae#r=wtg!P+FuE$~MU=x@H1'
    '0{^*CP<fcXhlFN!)6isj0ZRzX3Q)MkO_t3f&c=f<4cmeoq^g={z#*W%2&pQ88G14~9OML<&v&D%(HMP8aYZ%!9FUfG({0ziZ#li2pp|1aVKiQJ1V-z!Fk+Rz'
    'pI*G~y?J{Myj|=j>QpngM+h08Dcy6yW>=eBr-eRAo2@S%PKC^=LrQ>ZO-75GO@Xm<jyy_#fDUrObU}=18_>ziS#WB!fG1m<08g?+Dm&_=;iD49VN7nFn5I9*'
    'v@*9DV<s>~U(Wk@Pdx3<uSW1U-0%zZL!KbZvzmwtfCtANJ`Wr9=KmJt?Qe)*{dnYQwb@+wY0r}4VNm;yGx|)h**|xqiiv`h{fH_w{pebVN6FNk0JXRQ5NnPW'
    'r|t1w(H;&cLIRHUOfrv{2|*XNe4wHXqK?yHQ&;?5OVyW7FV(|iRaM^n%(G!-;Vm}q<P7$Xr3V4LT3y`_Jcs|t=2Ku6ve`l|d*)DC_FarMP_>13fU99e$GM{l'
    'bvJk5EOra{8Abo_F6be@mJ8lnS6-W!q<7yMH1lxxPl3wxZ8nF#;=E{TQrv0bS;)QG5Eb+P63dJ>g!mWdBTOKLd&;tZ9J=<8U^&P5aae5pIQ)9!$KgYbAMGaP'
    '0$HLuh20pU)dIPsYlf9qiQWW37#*}wR$WaPMGH&x7dIfn4oPq$oJ}Q58#xT&SXXld5+K28KbIv09$E4C^!w%M8#fyNP&>qv9lna2CUFV76?~6x<0Ie%F-!Il'
    'qs7`ODM+K1Xr13CSH=2h`-v51Ke29xNpWDk7p}#)(MdswJpv|{#m3h^@JKIdbX_}V@8crz-ToAY*_ZdK_JP*H>y(b|M8qC^pHSDG^&Ud6@zSXZu8(jVlhM1I'
    '5a0s+86S-iB1Nq=GObwL^Y|(S5$_ZrdHAT}0b%Ncjj8|>v+Tdmm=V|vs$g>%1gtrnHu?l#b;dd`KsxqvE7U&J&DYL4U`b~Mu2w@z-2sw^dob36DKU-_ho2M$'
    'iRdI3m{$ixzhyQdsB^+i(=a>;)C+re2G<XeBJvH5-ri)Wc~hw|;G>4B3}iXRTZ!Hw1{=9>LB(7WM8|=pB8*lutemoFpiBuHk>PxlZc#k+KhHY(kepc=4$iDw'
    'Z$YOlfVFTAjV}QN5T5G1#~3{i(w|hBAo6sEEfS1eW5RZ59b#S{2L!>GeUL7I6!2VqyrbthpV$IqL7y*0H+Sw;vwLKp3x3$@1~7kgyNWtV(;uGL-s*w$;QB)$'
    'WcoX;;cqt@;%2{te~Dgyx6$~rzS1{ninFQ|<gKO!z14!hRY=?}*8le6^!FdmE-wC#<>0}qvzO<uE1d(kJ(Zdesy<E~a3eA3s|%PSl;EZwpkanGzrYO)cNU7d'
    ')_Gm5P*mGEg;sf_d^j>_XNNTk$9spnA?AH^w}G`OJy>y4me+$z<YIHaE~$q)k?1~wE~#re*jn4cR@VZe5p7E#4Tqy`nawlg!P17~6KT}|B0{sFttwi_L6oLI'
    'j!klz9*q9OuGu=uB<{h4s>vvyQ@2#1+k$8d#qv2=bRLd;vnbWYy6hG=SEZrE9W}A?RBf8L<`i@D!}2H2WEZxbhv$jEPU&W4))3G-j=L$lo<-Q$*Afg92Km4R'
    '*E#xTDla+RVO`gsj3xS~Dz!rC)RfN=+r>SA)#S--f5ym~iJLAMBm?9}Q_FqtA%LQqpUrtaiA0OJQCwcPn5|gv$dGd^_$ucGE7RM9f@z>`-ZX@its2r{Se)L+'
    'b|NWHykvI+yMTWra>m_*k8i?<mt%}s6ixI`l4E*lURd=Mp6axEwNWNcQyXyOi_{f_yoOzg$k;TT3O()WNm?|jQm=5}Jz$D4^u$vd9;pP3R+K98BjRRX9l%<Q'
    'hE_a*mTfGtZ-Xf_^;p}RCM+;d#nVHr_pdWdR9(dmuw+CN^Fg%7ANaIbi>hHNS^ou}emG8@g|Y=KPh_Omd7MjG0UiU*LV_JrV$9FeG2S@FaK*L{Vg$*uzwH`H'
    ')G;3-qfFf-g{_u~q_ZFZiEanRbp*Sd0|g@V*rj=*zpmjPk8b<-(G`Y7E!kybxb5jrjERd$Fz=9<Lh!sOyb)~(dM}CqrE&KRlzHjKpCA>$VH!Ll+@Ais%u2IV'
    '5AFSYM6&wQhYjUW4s4SbmefU!!1qutB$2__{&-v6qx>U<ric+8sxMY6gyoX-3dWu94HTmo8T`x}JIEJ-8R-PN1btCnNI3JoZ#3)3FRR(M8O#L-7EmqKQP_Z^'
    '8zu5ql(tNQS5pT)gvKQ~(MCQjvcGS2Z*cp%o3>kO<_zUblQUxB^AxT>8^!#WnEO;_EFgI6eq&Ba^}__~gu0oi>T*dYL(C$YcQ#-ZOE-ygovQ5_+9bzxE0uGv'
    'VQ|P$r*v?-%OvY=eIquRHVE+zYbumdlGZE_JX!pOwq5Z?2~AzS^uCXs+}OvhgM&4F&H8hk>y3NL<-b)wLoF~sWWGnivUp4O#HPUrh7a#carJO%nxU45`l-$4'
    'kgPEAsF&Ad@;9!j=bIZg_aA52TpJp9R2o|6vJLc&<*dfGArl*?A1V1WZ#doejBcTQmBK9?+(PDsUVQV&IV}ETudGJ|@-Mvd4*fNc1AwGSm~L79$y<4I)3!l;'
    '-hWDN#Do<EKLeNhY`R#!g53(wos@}=GIZlii2>?n8GH8~W3OAlwes#4TY2}t-paebv6UC?y!CJQKdkQKVf5_$*NYct7nlWy<So1eZ%3<J_N`N{wYQ@o3l!uI'
    'nt_NiBA<P7=Rzl31lqzHFQ%(^Hz1enH2#W6U04L6n<@)9;Pd|7RfbprEYjSL#_vh{4I&X%IEhp+enbiutWJUls0nnAUL4V{Yy$Ki9s*TfQ0M>(HdF2pY`^FU'
    'G0jit0SlrD*0z``FW1r47{xH^A)JNTbUYf|)4-%Y{1W-h=yp0Mr2Yss_~=^*t@iJ*wi{y4(EE6Kmq9lv%B;m|T>Uxve8b?S6W9Y313zY1C(D1BLj<d%zH(#m'
    '0U55MK93s+&<Iv$d4us15emX%n3-vG*C)S8^iV_-+G;ti<CLhi_z^Am)T`ePd$P{GA1}^d^?rsQ31YLr(#Wh6TEso}N^O95)9G-5?Vu*$FEVpFb%D}|Mr8kE'
    'k9Sn@5lM;AH7Ba#f7!rsJ<qa^T3@UU&IG4eTAEes^K`{9uJL<Vhp9{>RKTvJ!@8)1BsK$=pB7e4x$I%6i;afZ^c0<(Gm50cBJ8^_q5I<W^o`GzHQO)Vp1nes'
    '^6Hi`B5ftn7NSGpzX%IOztN(!6+7SRmBM(4*8lte^sINM&z_yVp^7os1?Vo~N%Ft&dslvwrqTZF#q*aKSYu*?K5yZgVGmvd4f+}Xcys<M|8WNQ3H9-e|HaU;'
    'tuJnk%7fl&L%Y_K9e)7Z5B4s4Em1Ujq#mgIQ9rP*HEjm_c-T{~aZjMW&=0l!ltlN?7`zeY1s*K%2^Vt+arN?&N7d~{PgEGp@>5igKE+Wjg10nQ`z^j)e)6oF'
    'RFvn*sp%dH-%CwApZ05f%Xt|><HNA!DxSxL_HIIoQf+ofh(Ah@1ge2=ZEgJyb5e)bbm|4jiB$7&!4JooeZ0wUny!2lW|u&`7W4+B&+8?h;cci<%NN?s6g$(k'
    'A&cb^=JQf~oVUX|IlY*{?G3n7W84Xii~>+>M0Hxl8G;azpLKLhvNAydx)~kte|+Lo6(6w0`ui=mE$}vn)u=_3)=J9IJ+r0E4>?3LsEt#*@FYMV$eDq=!O2ks'
    '^;zl<Ve>g~&l^ozaN>A7WAxT&Qq7ZsB(hZa{Z6D3R>Gd+z*^jvDs81aY-+PT9xjY$D?4w_Num#EpA%K+YNRWC5o1Uau4kQgEl&}TB(U>+v>MyW9i<wuZwr5K'
    'sYMb&!g|e5wz{r}jG=P-O^tgQ{WWUs!1{%#Y<}0;+5x=dQm*6a)5x-;i#yI16o8HN9Yyas%JEBj)#bQ8_XVZEp;u}nORhm!ijc`Ym?eU28~oW+B`f4E5kc6}'
    '=!+rKcln@+ex$(<FU2}8jp$fMICSs@tq55Xx4N#MfVTMHNwv&v>bN3kT1~ylr8JZStJ7B-`=Dx6%mmQvmi2ba^D4l`nGP6RWRPHRZ#Wa4WwLg@bBT!GQZ2<('
    'qR7vasOpC9!x^!nnl)NcM#Kj<-4oogwMbbOY0J<~)Z0f{1<o<r)*|_fP9)GBbqyKCoHhHLka7{(F3NIgaq5G4cBjHI;ZF+3tVIf?RVZ?3>^^l@{ZEK!Y1(aw'
    'y&A6J+ssjr&<}XxL8j{K(NimHbb$``+C@rL&Rj$>^tK4nb?bfLmSL#~dilOXwC7_iB69RmJPNrXJGUOCZp|@;DwYOnIEn0Re}q()N}@BIW$au|kD_JxFoYfV'
    '(<2BHlL^e6N_s(62YesHXc5d|q>toV0$Cwe1|MnTPT12U3kb_0bg09X0=G(;SK&9d?;|GVxYf%ohff8P49B+V*&P)9uT$HX(n2?2CV)#vWuMXn(x2r*7*!dY'
    '{!mN^LDnJ#;vzS2ejDHk2{0SXF9fE$Xhtu)<<nWbRN8bJO&DAhqxFg%ZZ#EPuR0`v>WQ()Mh)a-CIR$W)pL1ZXTDRE!~oHH5VNJ%pai*yMB_x?hyh*SUWtAp'
    'H<jrRq0L5lxLI;)l3`l?5D8UXRMR*J?Y_mu6a}_+2|HP;Yf*}I>4F@X3o)=ti|HILimI7<SulsgeE+c%)g}6CAa>RFA8CY*7=y^+N3$D%*Yv(oOA0Jw)Y_N?'
    'Xft{mu`O^K0_8Knf_P50(7?Dwk2qKiPib3<G^q%728QVw|1<=jv}xM_12`#C?6TDr?$mnX?Ob=Mw>h9mmyZhzj?m|Mi6Uh|S#4Gn{6v^sgS*(-px#TKtwik$'
    'A04)gf|6Xs6m;ST^O%iDFckP_fu_{eDflt`kAe^sY*0_I&;|=5K_vNij_|R-V`+7-AbFdQ{D)EzvTa<KBO|!=DUO+_FqMYG*8Gw~j3aQ5&bpORYU@X7Vw9x9'
    'eU=+g`M8lK!RdL(!W6AHG0EzCLZPX_5)RkLdX;QV9$4;n_eg#~QSXh?(b(tkEVk(J)}N`fCr5RLx+7L^K3yU=42#nrqEefnf{gN<OGH=G>3c*dSqRBjdg8aj'
    '`bQY@1~o3^`{~4}_{rHI8r%=YsFjuq2>>|)nI8p+VShBfPgpUI*x*al=VCl}tB!ifg{bH6`ZFg6m1PyQ4+!!E9zIx#?I=1W3jkK032>H-_#RQm7tszoaH-z3'
    '6B^g|%?9exF^)VNI_+Y01W815fJs5@*<p=4jITdm5VuZ~+`Bk^`{F$ML?yWoT#y%o!CYn;uEMq0HJBGrI)D84eI~|&=;|KL2dqHH8gJl_j24E}(7#gys7oJ1'
    'zpwoPpsU>sS7$WNjN1HWijy%Wy*O|kSdZyGS(6ov0}tTOQFz<4l}4@YhW+@*7Z-2dB196(lFl16TFMI)af>>hMmx@DKb)Vx(v9tG?~(va5sPHcAzH)geuSq`'
    'u66L{3hh%%`>ed1PwyuAx^=_Y-<~x>SG`Spr-zHfBvgJA0IT<~NWo2SAEgBgE2TE${6tZb)0_OO6(wK8=LS^-mQIe6nQX-l<P)ySjAC7xY7R%4HbS9{gIfZr'
    ')=m;#t(MlYCklyflpcB8ajI7@$%rTf6iU_GOvv!ue;h4FdIwq;S4el3S8rO3dk-Z%n7E#+LDNd^o})AKFfn_hBr1iLz}n*w3qL?D=jGP#r*F?Lwz?ZL?LFMb'
    'tk=V;FMFeIp36pFgIA3eOud=Xse;(u-n=d1sCf8N-DPhEY(D+d=;l+VS&;v|WfC#sKT`9a>?KT=2HOuM38n;FT7#pCSjo|Vb*>-AR9yO=D@~V}aLX(LokWe`'
    '2xV1Z!f>^>em+G+p0`^8Sk927o8t~`ItIKE6DJ^%gH^@?Yp#^cfLl@|ap9xrjPwxuLa3E;`QE}iN>+1=h`Nln7NMgQrHahI)UKVn8b_O}q;DegsV`Kj1>&ln'
    'GOB)(E2Y{yJk)wfxQOuxa=joQhAtcj&m_v1k&A;;^gwN-K`gk|G{K^hxIsc!<}vS~W4kGRZE8$Wp8MmXrW_*mOlTjffhlDo@Jhgpkyindx~xCA=}`QvzCtw%'
    'GMPr>DQvPiU7QOGG6Z;&)y$a?_YSXH9kmi4k((15r72m_I_d`(8pc$@pHN?O*N$TSKxSXmG*eG_!KM1A8|?zvle@9!SdO*A!PJU_kVqYf+#}7L<=97tbZV+w'
    'oIn7#T+64pBAhE<;Bci0_S2`Q1$wXQ*KRWCrIXo3+iRg%;ONk)u}5VwNsAn{z=w)lIOn)d^rD#$$<xt;Jn0x1Ml&N{+q3eYbH|46)xa3kmLVImJ#7Vd1!=PM'
    '&;teRI_i!ToZmGh_%pji_rgQ(6k>pL(zcDBKN6b@@frnqcEHS8xvb<mCkw`<$4%sHtlmM(PkCMw=$u`Q6}MI)(81~23IBGpsbvbDQte#)^-Ag_q@F8OTPKd@'
    '&SJOK=$LULason$bMw6MxbK_(N6bB@LHo%gPS|E*xW)gF(1h<MN>)eI&uuRP4ecgwHW<mb5V`4Ka-_woCmWAht*lrRn&5JRo!dF0It|eunk?+=iEeA{y;92D'
    ';Dr&sF9OP3^C@?tt~#;F#o=gZiCjq`VsLETnc2b`OVyE}|5KH@)Vpt|%cbhRT9xat;YySHIHkkJx?FpizDAX+6&qin$qkaiuh!$*wf_6mxIdp=JnsO<G+Jb~'
    '`vnlUdb1I|%Q8Gz3&BuDt_L%K7?0?A|Bf`7N{xF;NXtX?+l3FusN-x!*}HcOaU&)d>3;P6Zi5t#N31zTqDu`BJ0I<UKrkH}f8RDEEURx@4gMINhoL+0n!LEV'
    'Y|Aa%+-n%krq(gzl>;|8QFI<+_6b&Od=LE8`wRxOAQV`}P+vsAz>mhmgwTj1VCu0hLQhXbJ&HrXjX548?wQHFlPFaT>z?UuQd-x=EE|v)`cgSwvsW<BoWd$9'
    'S5t3C(eE%*q66<o_x(AkUV*eC6!nzUvNTE}-p1pdKbVdF`OiMcrub?w&-%CU_u_UsUEYjH**;qw(IUKi$G@mE)K!`^X#K57WO$w4Wb+~PjiY}BahzN{&DBbM'
    '^KMu1N598Ro$nM5w6znBv$uUe!`dy_n;wIjaV4Q3W~^Iio%ElgV#edrd-dXV51pn_F$){na2B|2MKzBzj3O(qI{k|~+^qyXuyd8r0u@z)$Iq$*Zt1h1e(JsX'
    '`TUnRj971UjC7#zyAEmz84e5e(!fLAM?akY?d;<3AVB<Z@$2hnKlk4Ja{jiU-rlqG-xZQR9=C!j^CQ#UYO6jupN|Qg*>vfb7ytOjDeS-(&(3<!F3wJ0!QXFQ'
    'ou9w``NbLE-Bi1XophNI=n~v!+Jzmuia*J-{fqg?@(`ywT>Uw2+@2iAbPKAX2lMQ1K3Y=D6F=ZA@)XCdABDB)^los22iXB^r!ypiA4YMYLfl1&-s(O?eGUh+'
    'rz#~3IMQ}+@!H~aSc|*G93&N?ZwzNqHTAIQ9oSn)IkpUH^_H$CFMa2f8@x8cDf(w9&fnXztfHES(-0aY?H1}B4pi?M{Y32?e(+U;rvso!r<C<ZVz&GG`H--S'
    'z<l7F(0t&ob{OEiA2V*bN11OV6f`X{bmV0$J}dBEaimK3q#co=z!0UdPM*s|aiO`VabGR1Q%L+}{54!r!d=@6AZ+{D3omu^VG)=3PZ>g2JPG|Ho9BWp!T~a?'
    'MKXkqwd;f)sxSt1&8PX<b3@trX}J@ax>eK2Cx@5v{eP0_jMvA)5_dFa?#>tp!jAY!{qXCHm(Stc!O`_y7O99T0iA#QE0Cj2mP--z9Lugfl?K)}q;`bTAleV^'
    'K*}{GnuUS*Yst3E^^#OFvM7)49X~`6%T%AkVtvwjT~h8a<pMsWJy+AKKa=q!5vn9y$Ol({T%?WwnktG!rKz@TUdx_s^IG<J*D(_=Rxj>0&B44!du*+$UQBQ7'
    '7Ea&Hd+YsRJ=m+@<V^n!S})y+4MR{K6U)J$&>{r_ISPU}I4GC25*X~#`5MKTkhury#mr&ZNHr#n*t=K>82)TAv|^7UbE{s=iLOZ0Ks6`t3JXK2uj>-`Z6BJS'
    'OWTGXJ*EPkTmgIN&tgzVXZCYIO{YJ0@-df_FvB1-5i85RY%}!#nW{MK+c#6hVP#*dhO;JIDdE0}<g%$s&RVQTD&%ZdW{u7*u)Dre-)7bL@6)zXmS((0#gsO}'
    'yhU1Fgldud=?drro4}31P3zZw=cp=lvLkfsp;l5+=)BTFxz%3vf%sU^1epIVn`cVzL@F_c9Uz||(wvc>Cbe?i$2a8H_WkZ|L^<T{qvj6Qh<=XfP6!WL`=oF='
    'M|1#j)Wm>b?Yv3RO{0a_`r$$(2gweU4tZB*6d^{cu^o<oWmhOYs-gIgF4z$>x*JV~(>ol%pg+S;qdoNARKNl_60D3TePPcI(Ng&03KJ15r`#Rv7W<#hmA!{M'
    'hR2@ldw-FbHF}IRy{g6mGo&9P(5FrcXgVL8zj4yBHu1$eGD|}B(VFz%AyS_x%`_-3TcD!oM>7_9PadI4QHbU$s!Iz5jB~*|P@^VL{B<93SQ8Cnz?=oTs?t~o'
    'OW6ao_<M<QU9~qFZW_JD+8dOz<^6eXpLnQ1`e$8}ai&m~rq~oZ{fTnxRhx<R(D4i1;fsl0xLP7gSdSR5BSP?@VHYWY@SQD<e}y9@XXj?08n3(R_QCMtMq`cS'
    'xQ<c$|AS`B{5c=WMwbLFQ{ez(9b3G&6|C;^rB)USY9bs5^cVX~l7jUi1fev?VlIl-4iDbR=UcSU6QHusU-GeetDJkv<G~XO5*d2R1)VKntH9es=KFHhl{m<W'
    '1plpEe?xVHn{{EB0(P}9Dd0`O@Z&S8yP4G45~txDzJpP*E9_dq)<Bg=pfW`)S`KvR)}KbM+v<Jy(hL5?zBsZwgW(wIUFG!MdJh+~Nbl@X<h>W4R*p_Kq<p=I'
    'j>=p1Yt=c89q(5}ypzyVhyLTH)~(B(%?U)dHfq#KS-eHbKL#s2w!PIvs@uZc&*U^r@apath6{iX;4kH>+hj4#g>DG<f;?7Iwf}6_B;ID&VD&LE=Hi%Q@`<pb'
    'I($sr|JB`-LjCXoa;e|PGAmWwinQ?R)NC4^Y{G0Wt;5`Po%=?3fTb9<Termq)g<Ms=bpsn!MaK^u~>u4Et@HDM3euV(B1;kn}+dCMDIY-ImOucqO3Q6N{n5{'
    'TIEDhtMgys8=|;0-!o)0uaNvc_*x0os`1|^p`QP8_WH%^pE~52vAC%d#4avpy`f@I=KW!&<k2$*WFrs-;wz>EM~8Xcv<Nk)WJnnDiC<_wxY3Dz`1S8mvz^et'
    'ZCH3zKEWT6Db(!nLsbfctf~``rE0se1-b_Ndo@|G>qn!0$n8^@-T(Q152I-)tK4FYf-t5W7~QUJQAVUT+O1f-hnT*iM7iMaNbVuTJAtAjHVQ{dE(<H=Z-OKb'
    'gjDJmN^F>2oePP;K3v_-WKu?UT;mws5UX%MY||ij+GzU5VYeF5Q>>1Ew2*A_T&V&eo5v_2X3Warj72N*6!?CBm*wyyg<V*03Ywv)7BE+nvj5Q>UiU}ighK+e'
    'Ir{KW`rB(%7+`r8^cT@?{Xhwt8c*?_A{|w2SP}GL3X;}Az155)qSFd^Yr}fhTaEYI+x5NO_pwH9#Nf{XMYu0{5owF4t+A`utPxe2apk>0GB!Dou$a#?5u=X*'
    'qW{6Q`h7EL>^4MZmx)q~glPAB3Fh3HX9FC<P_G+H=8TJ&E&Cr^F!8Vc*DH=vy~jmE#~}^n2m5L)w1j+yo_;)hN+)7;yFI&)HBR97Ee;Q5>Db+Os#o~<xAwu)'
    '-`a<Kv=D+7&i|hxL(8%6y?J}~OM@W&ihTTA4FvYn79I7tNjQI2O>a+sIirdSYihQsrh>Qaa69lAr!l~QR0EwVZGpoqY`I-l{lTKUHf;mFD!uAAkR$T~`o9Eb'
    '>uW+FnWVs{)6Kk;m1Wgi7h1j8LBmj9??&n+^+I(@%np`Hq7c9}^@td7Z%0!8tZva%py+J5o+%1{*I#Isa5V#(m-TOtn6{91ZmcDB0tqdeh^bl~>RoqZ=FhSW'
    'R`aXlAKtEGM-XU0LjAzbmGXqDo^QeyIt-gz^H=a})(L$$+g8Mhtzon5|NApou8Y%WXPxL;gBg#rI)^qfOg7x%qkp3AmlgQLhv4Q^S#ims5;o&dU827Tb}njT'
    '5l9VL7`#hiv;3dEhG0};(D`_^)S><Ce2P{8)cV3&N5GVjg`odloGOhEDfJVsO2J`X802GWO&mjKeabW_VOk6Enk7vZn;giGvky&wB6a?1PPsVY(G4lW(J2tq'
    '24!<8qGsX>jt}3=%Lt3sm(x1_%O(P4V|5UVCmCY)_JL2q9G=j`UH_htl<S<Ojp2X?Q(|W|Um!5Y%)22sga>%uAGqu<GahJBL4Dk8bu}IhU<%IqgBu!<vuxQX'
    ')D~zj);^hGm@lRxWTv~EbuEy%`wIT9o8S1eM!oN$12(_KU-GTgD7;Dk3UQFJ58pR2z;QYk`;T;Cg3iUjKrSiUk2DdZYq5BF)7;QR@M0V9UIu}<Q|Q^`ZOo=_'
    'nlf5ZV_c#{cn(xDZC%k}_US#WG^QT9rf+BS?Bi&<THsb>zLfU|sZFQ^A}`tdiYn~SGiS=_Y(&xdB-1;Hcci#g%V;`!Ayg@lt;hY_S#^xcf(3c3;)aJ=snMbB'
    'y*j=4>BZ}We>^|?@$}c1Zxi+EzhbG76n;yF(-@DgmvWlubU^p^TXotcl=ez8$5v<kCHi>lgGGZ>U)a>)isNJF8M@PE%ynjS%}@jX+3JYlZ^UleGB}v_orX-P'
    'h-*#h30yeu@PfvBj~(@PSVDR=A`w^5@VGx5l3E#V#Ieq(Yivj}hY}G6H<Fq9V0z2D3Xal(NRSF;9s<$6!M-u(!E}s|2BQTsAW?K`vBrB(cX+e{&`ogYi)=||'
    'H<I1<+x7jZT5C5BVgjLz4jR!djUajlV%OrxVYSu#v|CS`Ev{Ke3|F>O-^0pw5AbL_XR;()_X=9g=ACF~hdxE>gma4|iJb89Uy%znT0FGZM>}5q3YHBydyzfx'
    'gT38)bC+jv=K!m$_9@Bm5)F_$Fd8<=E~i*ybEn?g(<31fG#m6+7`CC;de)agsv|+L@NlYx8m>q(x5%NPh1Z-O@`mB(k*qUtH%405K@MeZ2wIqAW1NrGL^vg}'
    'X^w^*I5(MMgh_R`wcYwF$WXObvVXYG%hKFG;01|3f^gZ|K9B;3twWUeXhDcAR0eA%v9OmiqBlq}NLD?lH|%|X)sdrNPK#KH31nlTg~{e&i&e=7u`Q#v4i5M+'
    'G|yxUt-p0zEFPp14fV<Vqc?Bw^<*>u0i#+XTn9`+_?T+7gTzh<E<EKVz;I^_Cm`LxxX<aNN&Y^lH=7m-z0K;_NhEy&YOjZjmLGByP<QxfF1NUZH1-XVgw24h'
    'NOA+T*xrtYL#~sWbu%fT21KJJQC@5!`KuZ2l6gjO`@nd}fg|F!P}@{3B<YoKnrS{du+()B>}$=P{TL;^dJBIvt-l-b5jze$2bT^K)=4x$ohKm+LL^2MqOIdh'
    'VA~Ra02}A;GMFGZz^#M&4m7j7yBEV=#2V$vPGb*x(K@WR;YVw~g<Wdan?w)}v8?{NbBOfemuy}~*gACrZQTbWKxM*m>N6@kO6f7Qc|EsfX}7ixNQ=_qgF|O+'
    'h$+bj{jtHh(z})Rp+i);wLe9bU|)s^jI?8(!lj5$4(um*gGzD%_3)?DUrf}9GHLetawl`<VhR(+svL(;P;3BhW=aO3SqfA6?=N0Ir+}7r!&J`K;PhItEB!g$'
    'zGTC8qK^8ks8O6DA39aFNwlDYT(>xfH;K1y@&!t^ATF_fG6u<SfB^-%($9jpFVP(xXhl9{897D=WfK&E?^T_q52~oD%Zd-lRp@pZtGD7murvpD=*qkpj81XB'
    '3De)Rx4mblKXP?y&UA%t2uDGEy7Z5y7q8AP-r$b<+ZhkX_XH_g4y;4MgK!<KXdzlw*AGOvbV@SXNQft-KaiIx@(0nZdX=I_*iF&Oq3|n-WEj6j;VF?at7<Aw'
    'IbQ~Fz~^{}P+}9_{(oRif9T{cCVc`$W^$LeQGfkDyI)kDjcVL$mBQe!(T;Dip|Bb55=YMX_yvf|Dnh>5uB0o%;z?BXt%nNfm5{3O>#)sU6~S>7nCVIOVU*q)'
    '`kafdi7F-2Q&W=u`lD<Ghgs61+fvg}qHrc2d$omPh`%t$I5LK*x9o2<^UZo3n?3<8;<b$kL=h4GJYT&(u+Bfsilh6Q8zx}+Zb<qM!H#y@igQjK;>qlFiNMlb'
    'mjuF^c?`s@@n9w=?vtpITVt)^a=_kQ1*C7VhdEH*`ChV!>1ye&5}j8uK$5=K1Wdt{UNHYl*+l7fKp{tyeD-!%4EqhMU&O`((j=VDIax8x;@}mf5cA<rrO{lc'
    'RhDG&A91w!ulCaYPUC>*HO~Kms^-V0a<DP;JzsbIO3kHEJeS_eq;YIz;>@8^HBxATd2FR57J}eVO+N)Oe(1Q}Yk=_MGzS)!_h_K_WlPl~RHiO9TZ2^e$0kOq'
    '7{!u0t-D_3Q$poxt?i9><-uy0%Px;cuZEA_qk+LU);4FwTa=Q`rJukU>D<DEbgFuAs7P*Xe<l%hN<KJt%FEUl=5iiYm866>F-$oBysQH$JB}=db-n8lo_(Yf'
    'f;;`GY91uq9;eE&N1Iy^A~bp_l;WO>{D;O-VBfx390gVuj-vpMj^+~nc4Z5AK@_(`O>G`-VNJX8Q`waDD~YIZ4I6=b$Sl&r-Uvn|iC48HPbIXKJh3aWH=DV~'
    'c|u}ue<4}x{rnGWT1%Nm>B(kJGA=PO)0877R!7JJqxPYNgYOuWtR4SQYf?cxnu?pY<Iz;L_LLzfo;sea8yHISs9z7`no4dV^*^;Ygwr!t(InE$9}Jv&$A;5J'
    '%w_}UQOMa3%3R`m+#7y*H=BUrZ|u{_j>Fbv)?rb~p&r4Ty};CuJepj(<yEPh8HG)}Bs<vu;yURj>qMXN+UZ#HrLQ$JU;0rYr|_k?9p*<m?8)qOy$BW}{_<_l'
    'o3l`_E&KI`zG_xO|2|(e?8Gns)geM$r-ZP5M+HPlli3Z7EmbIGs~8o$<<SDV%!W1wy<~M201jj7nqFU9nOqIS)&Y)SJiUuvH0U+sws1JnN79|5J~9y_92DXp'
    'DEdb9>1<U(-Ik;(rM}~}$ZK&U>S&{UB@N;ovoVPXhdEWRD0&I1>1vAbs-q#iAse0cJj0gib!D8;uuf`@`r|n?es6m3L~|{8YOk~9;D&mAmx+2=TY!{VfdS`r'
    'mRhA@X0@9vMm9lMbhLlW`uARTfLB?6vBKCYTk&fdB3jB2v2biTtolXc6a`w*tdqfo%xS#DaHS~lC!RH0Zwk9YV=3kqu)N&9Z#MSp%~l&#z6dV`4f6t{(jII5'
    '{_vm<W$-<MPbI9xhk}RoX8VvHw;J&H7Wy)Qznd+7wkv+G61DODPMfP}G_;>1uL3rwLcw5@ER24L<``2UkUP%z?E|S<;jl&D@9xl}_HM!pbK9pFzSb^1#@-^<'
    ')AzgFr`<+uP6kGaQ3w$OQZ1d0OL|f@adZSIkuGKdHGQr{qU;q*j`-$@iDs$%8v^zPIViSeqv~2(Vu6EN!I@kQZmg6Aq|no5U$GT|WIw^9a7S^7e8R}ig3#($'
    'XkZ$T4Ouw*h`Mz+OVy8uPup=v*)&4dL*8-iU07_i6to&*dfYh>dk9+|Z5L5x%tVDB0(V6_O|o0=;m2&K&$ocq+g-9o?Cc!IM{*W;Rp~geL2mExDQ?kft)1*1'
    '?8Umxy*>TBy|)A3i#LaS)t0xdqy=y7&gxgq<lvwMA3C<U8SZs$0gS3>o5Za&7+!H!ikl`d>dn1+gD5yUiZ&bVr|{pMCj7V6K6rXJY>Kh@&#+7U@?X6lPT!D*'
    'SG2>O2oH$T5O-kdjFz|);gPU4#hnO7ueJC1Z6kQglP0|r?KYH}8a|}DNM{b;AqlX<EZ}_u^Y58{YRd?weh@if_6c_U3}b7RGMXPQ-qYStvIstrU~l<p2`4?%'
    '#LKf&gvNR%ni!J2dt*un;A_gD4t!CCBG(3E=p*pSiD9G@mH3VsJ~T4-7Avjs)Sy=Q**5<Y$a7|Pa9KtMcHLdG+%%K^!6flgY6thL%aJ7j=~?~asJW!|fLx~M'
    'o0%z@*CG#pZ)P7iSE9W8v{bR6I@*j`!rm;KkETPik3B(6@b&iK`W-Nic$MNyj(su%gqltwLeV~b_Lf`(NudXi|LRvMfjLFCfPgBG+7}HT{iD=pgqWd%|Ddt1'
    '>WiH|nIo@F44Epc0?C}jm-!$_Eq8HiYviuS$Xw!_>Wf<{K2XU-cHomG7v&@|kz<9af`L#w8;Fk^bv|l-$?GlyBe0As>fBi$sNNaN=OYw*1_fX5cc+#_Pa)|s'
    '^I-QXMl6t}4|b5*_0R-UEh?D9GYZD<5!x2k(CZIb+o)xKZUZ`y*lqMb^*F8p6?M1S{9Tq(Xt1yHyMmc}Zzn&Lp(|x=iZz?}>d0Si!GAy&TP(DaHx0h@^G`ap'
    'm5?mH9CG1lffhQU-VIk-PiwL!pO&uL5s00yc+B4?qT#hJl7B(0nLi;~i}&z5v)CospM~|xs4@w@a1F~t%Ra04z>bcS2JV6*1SNH<&=dUirBJT-oB#Jp_CKAz'
    'J?j{W6J>RFWFgZgJbq#c1W%$WKH6!p2O~1@btre&pAWSV<2h%sw2hZe-SzR{_^F)mAk{IIh_3G0J21Ni>4dici^K0I#kF$3q26dg>4@D|SdhYk3*SSHIrwQO'
    '>a%rR;?0a&fut%{IgmC3B`cQn6^=(vjv~iMSCkrNSLn_<e8*0VT5QsD%XWP-XrkLD3r;e1BwSIYLO4bwTA_~^dMS?JKu(sv@YF%a+2{iJqE}}uNO8>5pU3Ot'
    '{`uE%`(MxRQ(r?IKW>r$&o7U8IZX0Q{VKrkQxhhmoP8E7cHesXm?$W`ThTx5I8|71dxv}LFfBKMx)n`bSVGV%{XiK(f9FUE)>^o7g7l&I7O<z-nY~Rc^2I4&'
    '9&R=#MALtYs#cj*N-h2w<@`pDZSQbbJAjZefh*ho*dMPlxB&>KL>eFly?4>x@BMs!@!}unuiq53l0>c8axTEuWQ&w<4jcAm9pXz8Jz0<Lf>IbkyI7!ux?2j4'
    'c0k;;3mU@Mp9cC9b|1rHf=G1%9QLml?(V~aB<GGMAFCtARTwDQ03rTp6R$~s$AYp22ojf1*Ba9nRu_BWegUB)!THJw=B})g5ATx+Gtqr27}JjOQ)UdQS0|HD'
    'b?0&_6)p#Zvc~1reOP5Ha?)1E1U-XBlXt*NtL@CX%jrT^g1!jS_>DV*cPnmK)h2Pla6RJrbg~E`t);@8N$490Z;DF7BTL8Pi%;wQK>8p1qjCR=kYFq+Hg6E~'
    '@IA<LLVpXru#?K1U>ei4O<TOs!g6O*zJ@(RsNgS6sF)s!G-(ki4!z;Yv1wK|8M^jcCFHnhN2q*BOuOg+=MBJBbf{XqtcZxdgk!Pw6h#!wE)%3+p7&jDPn!H)'
    '3b&YLN`1VrHzA-TPki;-aE^FEayipbky<7xLTL&#ZWKNU_?lCutZ%0bwPquTSYJ6oN8=W_)}?Ggz1OvkU3I$7WPm!Qc15BAc0$KT%{SE_m?8UMC?7|wYW^-{'
    'y*CH4o=UM?tIok)zdWqp!DactIp&h+14HndKIW7<Yf=hYa~@12D5o^gQlP&i-=wkz7R{v!G_Cc&(ApRLk<+$#E<zVTz2BU^H0E{`@I0QJ1$IYIv-VpaQ!ry)'
    'Kqz1hK|mbvnhqHD9j^6Xjs%n+imjh{fPAx7H)D<On`mdkv;QyE&{$pAR7aD-|3vXHSk9Mt&bMdx5p08Bdg?*1-QH{Lw(VW;Cn$G7@_+XB;_c}VFV8ycQ(Y$r'
    '<Ll8tJT};XJwQr@uFCk?uahCen-U;Qs}cQ=-~#O`l!nBFYqRD9C%)c_tR;`wgD;}&ttx|{U`3b^s_PM9vMR3t1Xu;q^M1mq{}wm(<p{I4V=D`ceI`640)co('
    '(T*Huho$Y&um;(JlOd&+!i`}7putT>93AX;;6uf5oa{Ar3@#0skMX==obq*+jU~DFD5@UrA8t1=hwQ;&%sy9(Xup0C32qX$5g8yI`q|`qUQMBrdHpBKJXLMC'
    'xtha<RHGuXWagcU)bHju-zv}E_Gpio&?j$%)#`qN{V2nCfwxeo83K~oEy9tBst23Ydr(}js@R>%YPDTnZ>vESw+kx9*D6x!nM!L2e|hmqgJth}G-t*3AdFBu'
    'V6?USM<tB0+-7Y-f=`wQAlnph#=^|D<c0<;6WJEjiqp+oCGB996EaifChKw%wT=IAf#=|*f{yWJ6w{>d^!v=p@h6k$&~yCC%Hu+nc%d5bs9Zu<@lp#Q-5{A)'
    '7X)n}pf1eQA|?ktohny#0=~fsr}!bKML&Y-8zcLW$Gqu`-x_<>xtT+;_-3r0Nw#kDdT#1aX*_-mSPuVr*)e$&iXjpI-H!6lzERT8XXV*G*W&!=n1RP)_1HA#'
    'k*PP`^Y~Thiq9SjtZ1=Icnx2pyQX57)B~8IgZ9q9fL%KO?d;;mm*>An)ftfu1|$^EtKXmp7tI~Gj!tiG;oT3YNQ}-Y`{d~iQzF(|+YM$J;KdCFOt;z`3eL#{'
    'D(D~hZYtOmg8$!aH0lHviyFiuDd7U)Tnljh0^}u(r@zk-X5|g~;o2URSb>cSLuiER1F86Kx*|tS&Z^0Y9T`t(dOI6u%M4X?%lfd7UV&8A$83PUayH_G!9+kG'
    'SN2dv;}xa9`1WR|-uZ9d)jR#zBR3qpdf{&^w!q(^YZxAr+uR~#X~8QL-GvAgolfS<)7P)hE_$!uTvmDmgdAg~Vx>#BV1@47O81g}Fb$}55hRU%b3GMBbPDw9'
    '6_!#ed<j%gP^tKO^$JNX6;CTAupzE<PD#G60##~-AfhXN_$^g_IS_Xn{^@GewU?Bov7WJRH;E<`*2`bf6;@@ib!c8D=CVTB=qr*r2dlKk(Z{W}MpdsXvS5{A'
    'x_u1q@^L%ng}hr@LC~JFGl=NY*6Z=2!TxaeQlf{G5U{3VqbhhEK#w{3Ktlh|-p3Z1b!u|AGRia6eiB`&5i80(9+N?+Z>E;C0r>37ex?%!AaZ&?1_=-UxQe|a'
    'ljB_T+6OZhiuL{uIMsGJj}*#+SYiI5;%7l5y&<O_WSw@z5IIqAez@PeS`En!4EvW)P#9>s=bZ8|O|Yyx34YKc11_}2UF^{tvjvgj;<=Uf)euMTMw9*+xXtNe'
    'p(+?=;}PQgRHbsgNf7wjWi|1$bwJiCRj)Q1zz)K+SD3exj0f6^s1qfO#$MF=RsS6^zQF?(h}oC(4WFsQ?H!qkYsHwv@ezedh!S^_n2y66Gl+Uh#q!EhIKKEI'
    'pm)UKY{Pv+d@gGfpG4IOMs>mmu|7<M0>tF<D7s?MNE3x)+kmh}XV&>st*TTHe060rZ!?mBZ8{*bx4U#T3~**~7kjmz1VW(7ecrs|QIjNQTq}{i##*O2xanzX'
    'SX$9FU0zmDZm1+g(Yp?9*OMR{pzFm8KjhG;9#|sDHJ_Va?$Ai(p+h6Hp(&#|epFj-9(fN`RqKiPdZ?*0N0Ca3P_TxwXa?o7qF9rP%|Ckuh+p9Xcwn(1xQfh?'
    'bzv`z1g11;DSbi0+*cxo=6LMKN+I@r@d%iAcYc_Mt2|Bu(N%3Kft*jWx+JffOeb|oBu~hN=<TH)wI(+iW_tq`d-SQ!Nx#MXPb}{#aO0Syp0KewpBN(~BJa{i'
    'UCDNIP6O|c?EoZ6B!&w@Zf&at!%U%z87U^0quUJQMwY9Y1UX3;7aaYC&`Whftz!5vojV?x^T9m3gYNa-yo6c#-@l%{c}v>uR=eGsXCGDsREsZvKfn0f*@b?`'
    '^P#?Tv|b=5zzU%AJF(ofMSz!OH5iYD-J#&qw=Z6D9;oVWvKuGWJ^Jsy{CAI@;D2}Fzc%-=825&hdnU;-IaiBnAGUt|3ip4Fe>U-Fv+LC`>o0FG$xFg1C>CB#'
    'cq8@ZyKQvJzg;ca8dOzfllR$uI_}?I4f_#R)T!!DVU_rZI)LZb=`QoJ$rVz|e~xB|FL}eon;nc1#y{D$N19?gdDQ_jvX+O~6FL4Qh9vCnU`B(wmDF0`!Y@Rh'
    '!k!r^y<+}L9#stO6a5eRLCV%-&Pz&?$2k9qY{O_d>W?b{uxF+CQF2yVB0wFXz?}Mw<zH2LF3OOTUQ)W83jL@^x*VGEPsu&G9;i*%bvP<wjji~H#LAz;Q^3jn'
    'Dsh@tC@Ffyeo2Y%glZ=ZDAO>gKh%}DeCU4xqK5#niy4a5jCdhFYD%_wia7%0K=-5Tl@OC?HX6J~H(981TP=8hc%M*JX>Y#Q>WwC|6<)IaxwBc6K!F=B)#rh}'
    'OY}5pn%@7IjZ?jmxzwXKxl)G;-AnO%Tn3rWYn2A568rO5^NJ!7Ei5dTnX;y*c%rNR273CmwNq=xPe97rZyv^Vnm&VaP6My$uAYQ!^T8E;X2|xSj{&#H@@8|2'
    'wH&gMiimKwSfH&7Xg+xkZetJ_oO_Ph<*Hy>VVpxZm828%NOj)9y@ibRV7#I;NbF6dSfp*+^|430iRRrzv%uE=`NhRqC8(8Fd}?y3*N<9FffzLpK~%cpBy<(3'
    'SyrT5vzx0mwO<x@$?PZE8uey3;o5Gdz^AEaaa?PLL`qz^G;JL+eQfC5c#9FOHHjJIMw#d}tMhW!^>Wr#S1h)UhIO1)_v)&$_(=h$epxY&#Ouf#EN(iO&hEDn'
    'NE`o<yvu5rE>O#krL2bPtq!aT@Y}R5-9-J-)m56p#Jad7Tzlc6{Wfi?doHCbMi|fE@G4QP6)`QeSn76xLDo~nr0To=vSQ!zu*_+*4C2c$42u3t=l-QD@``%;'
    'T^ev!Hhf5+o((S%kq}Z>8Fz$xDtEW&EtOhX7DemUy`<)Ge;$EcoQ8#DE+oq}0eTGw<`QnQ)#M#)|Aqw+N24$)xNP|zuCA1y9xc<r{g!k53*2PbgnN;Fr!KNw'
    'GU`p|+G-K@p&{Dc4v$aoio$}5Yk;RVA@6p0sx*KcH7l(mZAfi0F}3`Lx#1I710F2dweU&~<uJf1?)u~R#IRvqO4&;8dX+?djYNbiPCOaaYb3Uq3L1dbs(Z^~'
    'i(JIcb+(!#c(J#{P!zST^lzi<E;c-~wu~ReDfL;rj6BKTvbmS;y&Cvd-9tT1Tr0jL?K2Hu#TV!OI5pQ0I1=tIv-m$EeYMgrot>Eb*4KwW<|ae(61=_478T7G'
    'vn;B-&88TWp|u~HHQ`rqerl?7$EmI_peS>xI`J$PK@U)d%gVF!moLwrz3thTpP$e#m6gtsEPhQ}TK;r)b@+4&1t1tWymZf=SGolxh10B5o}J=F8EgJpb6Mm9'
    'JX&ab*0$o*7_|j?H5Fsk7pPCNn<-t+UnEHf@mBr&BZ4iF1Q#S;6WaB3ev9r+qv3>Hl!h6_4q&^B)%EpgFyg>0cd=n%>+Jd*+9RzUdT9in{^C6dJl)MMkq0h='
    'n%mOjp0|MD5pWN@L%U^xO$mN$pA{*;$w|S4%uq?KS%W(5O-?goJaeH;!WX!zJhpQ8LQz}MBps%MM=#@C(#y1XbFMoZ1&2*loUZ#`PKT7YtSxfiSzkT$(!;14'
    'xby59pjwy1b-gx}S<=$9rLHEeLJuoillJlO=}z?9S%(Iovg~MOS@vnxpDb9<#mUW^0)%uoRj^Bp%fCced$LU<CKoBu?)!5xNCQ*7O@WmR>%%E|$iS*AWg%J='
    'bZF)t>ZJ5ofZ=m84f5aIM~^S~|2F(TC*gq2Xk{m89>9wx+UfY^ekbZ<W!IzY<&C3|W65fgamqPt3_d3@p7nHB(-mhTcrK&wqvf2Ftayk#l!supnqw4N7FEfa'
    'peZT4P)j&^H^I5!o`^1ihpbKioVR+3@%5xepm<wK4I}yJt75qyEERaC07<dTVP_X1H79iKhBH~S9)sOvSe=0tsqV(x(Tk<*0fx|GV6cqcIypZJq5kT`FlwL%'
    'd6{T5`eY%+ofBXcXNaJLJJ=j0T5S565d{#8@-+hSMt{pYOo+iBQ;riv=jtzH%%~jw?W}k9^2JXt*a?ya8n|5Fp>W8rT^%S$yii@U*&{zvQiJM8Y?kanJD3o_'
    'eK&nCfud)<H*m+HRZ6(a4q1pR94=ew(1xsVxNL=^T`MMBmP+Fz3YUdn2aPXWD+kI^y~6y%w^Z@@@9_5y{r%JV`I|HN)uy;uSBz7mW}~R9Y4n^GT`5XAE0Rqc'
    '4Z+Q3$Wh!(w9~@I;g=QqsVSAQ=eqKqh!UAV{w}LQ#-68$ZQ?bu#9+};{-q9sE$}^%&XB5Z!C}RPS>0g|Vixz<v#*lN!=(+ttzASY1(p4RCDbH<%AHHWu7n+p'
    'U*fn#FiLn>PP9i<<4GJ4g1GHl(eiQMY06L3hxr{qa310rGtS7%lTMU2?BV*P_9J62q;A3i3ON&7>yci5e&2~c(yYFR!$<Cvwl~Uq+@3P%FYDIU3%Pc7u)@RC'
    'cFB~+6#EA!Jbpt~E-M~EaV%d>*mgikC5Lmy@p`iLNFnDr2`xh*cOD*nv(3BH-<~;mc&#rC??RlbX<$d?SxSW%q&6(NY`;8x{k(#Fi-{DY=S<!ziCVpGr%;Nq'
    'Cc3B<B*CFw&r>OTo>B9kM2cox&_l*&NBs||r`Lu!pKshuRfv@eCgqlPnL;(!w<k07kWuj`PHW}ukd87G3WmX%d;yd+Z}iEuM>%fKOJJ|Dn6bp=kP^$gg^k|@'
    '_N-VR2nPmT*(-=4zTapx;JY^eLmhHJT?5C_yUdF$((6w3^nE3e&w?}F7a_l{1APti-fvY3I)~xLtW%U;0T^xMd5H&ojk(|$D)D-Xd7X%(0^XMp9mSGOh?dHt'
    'eYLtLyF(@%HI?VQiYRt3Z$R{1bcEYOwpc-2y_+LTi@>Q^3e%;bgCKFiz-lwCQt6nGO(dRnDx*Lg)dkhZ45?x1kkb~<yH1VXFvE&HW8KI?akSJO!{my5FCOsG'
    'DI4oWf@mE?{UIiqm<mMeWVH}3S8Ail6c|pFXVg3b%c94O04*zY6CQEuPvlmiW?`V;k7g07Fo^qnTVk4rmqn&|`tHrMUlq@~gK>O=Ri<7!9P6?-nX=|z8SdfH'
    '0w#Q%^<)m6H;mcT!+8;&^{r#gk9IMFW>5azmw(~;o;=@^=dNKNs>Y@0k(z=qAuKOkb;pH|vMZZ@V&K|OZ1vThLt)uyNL`i4r+ZR|z(0+yLca4tjuAPt_#0Qj'
    'Zm~|Aedt(`1)QQ=X7#t6_=z_P8UBe@ymd_f1)r7L_QSrZ<j{GjwD^|80Lyku;LFxnzLmc~8kM>mgk1}`v~n+4(-NKVG_=E%_Yug6<i<zgD~6Fm?k8jj<p6ru'
    'j{s|SB0+FWM2*#$93cG-EpX`n$fjE2bl3)H*e>e%ni`QN!)<l%)w*YY_10WWE;U%^Xk~I9xdu+hyUQ_FYNx{0GBBy^W9XPVztt>Znx5hs%V(*;s;ZQ&#<~;q'
    'y3nVt5fc}MTP4<3SZD47WH-bglv`PqbGc_{Efv!7c1tZeUGHstAx^8+7OJ}rL&`;c7X>@;Fgji?xufALjS8)@xXM~En|vf3p0(y#RE9>1|MX0Ys6(bSa49*M'
    'u`Lc-!D496f*q@#H}!Mf1&*wNO-atbwoh@jg0N&Luvlu=*jDK(Z(r#oaTaN`-`rQrk`f6fF&lrPbOya?we{L@>!k9;g*{2RlDZz$S~YQ$*AsKCFm!Y{`FN>*'
    'snui73`Si2ltlNjSka<;+ge$66_Y7WfzReIPkLQ=+jcGch~?34&DVi7WVY-Ih{glVi98q@sA~_G3bEIGWL#S`UhJg1EionMy}LJ97_nMMx)RH7?YDL*g>=+V'
    'ZcMi6XhiTsrJe_3k#L;n{YlqTf_1o4$~ovhu9*bWh_V5i_auUH#Wo++Eve$?(~IALC(700c35>bU;!(uyxfjcGA*w8ne=c{ZQj*9baz;cc_ol2Oe*tD^^V2N'
    'A#tB_#O)qAcRJUJs;<<cCMQ0z<|kxbE7;<eb<H<>5!Lw<s8`Uwr7l?|MFm*tviK+Fmx)-f3*FI|DNApmhKkh!Zy%@@_{LGP&&K`LFpJnu(c-w>j>>vr*~}P<'
    'L#H{B0+j7!h6;%292Ej+p}&RhlJ7MsC4N|qKs3P|-oQRBo(`zF9%W+aaU~cWTpeaa??#-RW1js9*rvT_r@bF9&R=21<OctIdmiC|<{uhEwBBlLOM&MX=a^4f'
    '|Ni0EAAcmtUA{r0)_Z>XcNC(V{OH-~o1d{jLq5?GJ!^-krSsoN?Ebv<8W#R%Ot=d|dL6TMZ@oGHRX?EzXQyu{C2y0_zqfur<KOkBgj!Og+)snmTHRrR-Qcw%'
    'IL3}D|K{!KTb-<zIw`t^&s&3jZ*kYB97_ni3P1VySPz8H&4%U?f%}_Z#FnFpZ%Ge*MIe@;4aFtNfzy1=+amai`F)J;G|wcuy{H|;Ij6Ru#NpwgZ6JfUr~$7o'
    ';4P*~>};I=bHTVb!GxcfG+@6OAR0<_UuG3+F<=Goe0w_w%p`_!N~KQG;PY4O5(EU&1K4vxM&PQ(%uL{PBL=h#<fcEqhF;S%B91EZXpm7%<Ykpg)X@f^{=$0)'
    '|IR-#<=irgy_pUMxEuQ&f&1*UcQdwS89*rJRd?787iL*w7E|2bVBlxF9Skm2iGZX=vM#~YQIknz1&=_Vs`z;yb5GLi?a^eIeX923*intalzxOIST5WPfiKCP'
    'U@(HT=|pmEZEeBNI_0T0Xr7D3iaeT_wfo}_sN;`67|VdOx}%^_#dOH<k{kNtk60WL{`iAh`@>3jjQiJysnL)d8=%-&0-;8$!TMz7c!Q+06^R4gA`Vo4Ua*h!'
    'Dr&S9{#d}jx@0uv7dI@P+z@~v6=F0n%geern={*NiJjpkK<7Lko)R4>R6w(XAS1B7KH)H5vI7P~0~DiG;#g=Xx|EAo=|$?A-cz`|2DQzx+qXFJ)CGiPMy^I^'
    '0zG4*pkK4!o%ASgb-o=69Id{wLKY(6Du)acB84vb!)_qUB9xtASv>&g1-4P6YMiG{dU_vBZ{9#0m&qp>8Sfz+6hFIH&kC}h+fCpaagVwI)0mJ3t31i8sKvnM'
    'svMkW;mZ)orl%o@PAj)|6*dfF7t<`o-b(kZeG0;D(<sBtPVusM2lAVsB5f<TIrLyuPfAF>D<3a)-uG7f|6}jnyVJO`ebN8#80R}w$jF6?3I+6VY^3tIj;+KV'
    'u`M6TX(!EP&<IKv76JrFvf9Jn{mj>T)~W(zIi21oy>}8(wQ9ZBT=V&xMU~=ow(}Q&cU!p%Flc{}^?`Y;U5t=ES^x+@sGi{~^d=fF2)mzA*~opmjj<w796pQj'
    'Bgz90ivlg;Bl^hDx}L<a%LgVJ823yse@!c24{}^f@#Z;&=~s2bRB*N*IzByPwp3qZasC!|#EHZLp5SD_KlFlS3;xoc3>Je)A=#fzri_S6`HuJ+0RgUo>Pr-D'
    'yF}VkWCCx{0Swq8kU#17cydF)rfI`T%1*tjDHSDAfrKKWg}+me<QL&($<>R!5tAb7^Z)fP?hjljT>roRb=!dJXvnU#Gz`HG<YadL`j_exl&aC18`GUEtv0i9'
    'I8-)>%?e)J4p0J|3Y|e_w~c*LDmGNr)u0fOaqCWj1*5=lo<>Y7q{@7+b)`s<Ze_`>+0gTVTcDA62m^eEC&Yg6Tv*$Pb+S3TIf!v+yMvc?wXoJV8L~V6iBPlV'
    'UNP_#`%E~wea`{-hSUFW#_h*A0b#XNBMA@I&G|HCa>81dO1LJ4E(~oGEy7{K#uq;#lvq}3h+xkN$pz8Pp1t^m;m=>ZeAaz>c=*Qrg6j$a<16tO3{3Zt6*)IB'
    'Q`Sd%_SEzT@CHJ=1d78#g=X*_2wO*zacV+T2RZ=%!R?3-aZ`Mg+6UQd(t5*t$bGFcM!^w5jo?O9BQe6z2^=kc%f4M696|Av*~E#(wZ&x78`)M~R8uNuP*j!`'
    'm*y*HJ>VkG5EYPbF^ym6dg_Tr(RocQ(D+(;bQ!3^p>UOUH%UOmKpo-D`1qhfMoV{DHdx}(hjR&Rp@v9@%kO)xBg`oNiToh-UQi~Q#?O$O$vF#FP(M*|mm6yk'
    '6l0*JK6vpU8+{Ruu>qpcm9L*<JPZry2qAePCV(H9L--TLhcCkWDeW0BaAo+wd;=^GxiEr2!B`M#f#3~4fc2VXS~JnmPgwh*)EjW>hxFrfjzibo4aEp)osKqs'
    'idu(29kfnIerbh{{8s6_TvblmNXl^GwG@)q?MPiY#g05TTAkIKP^fTJf!6V)j~+dWU5wNKW@9+=Qpx8!{*tY4Xu1pEHMSDC*cj`I%x0GcL}!hPpo}+4bhbf$'
    '6uq_fyGwU{7t^xj?$#IGJ}{i!8{=NBJQkG-k*IN!dux$ut2SFMu&lnGIL~jE$@2~!Rb;X>pN*v~=*NaiF3)kZ1oX95jQVQVpg<K<-)R+5jg%I8pReS7CL3=L'
    'p~pKpSluTE#?#hhcI3h@E|7#SZM75ZmHIYnZju@wL1vJ<-w*}>mHtREri?TR2Y2oYtE9(Ly!B9YW_aRc(<%?`T$CwWC#h6%u&i}P9iWdPW{j}FKHxVm2MPog'
    'lG4?N6(i-MW(rAnDbZ^Z)gLjQo;(dn?)G@l8bgEj9D>SSp(zVBx)P|gMN=0G(WrAMK-g9@xZ0cW<Y4uyyJe%_Equ^!bjmbG9(Q>qG{H=xWw5OTJbhVx#GDAL'
    'kxJwU%etxsBg36T<Bx+koLU^YAxVdOdlfF{9TQ`|DE;comtKV!7%LEl!+KL=YuJdExHGX269Erl9`?gmeYk0sN`*HyTIf8SFpbI*k#|`*_QohvmT<J0;JLXf'
    '3v*3`)E2i_D_!i)|13R+yZy9nf55NRac&mk(wF?tR-fS1i&p}-q+XJBzan-M;N{kCMJr`29CB-$&^AX&+MVbSMbi3P%(kP>R3}WimK~1u4~F-JG7W}OuB?5A'
    '^sUL3QgcIXZPHCNx4{{1=UrBWV0=prxEDAx%3_O7gIf)lQIy+|r>P^<=tg9$yenSG<n|*?`3yfsCU*OB5fh_nv+teKEn>;USd9{jZAMF=KZ7!!m8eQ-Oytu%'
    '?gDWDlk=RPk2WrlF5114_`V6#X{1`%{5MYXk}!ZAkI7-pu~QH;E%Q}C#fmAJ@gB6*@xi_YSqc>6kO~Jpah5kcJT)^I_T~vpbQ$M`lT)mxa9j%FV0XxAS=wr?'
    'blq7t^P*!~kVfnd7YUx9jpzYiBFet0g3|&cy16m{quza@1PiEAT_r)P0ULPPjkKhSE3pu8U5X^gl`VSA@L{+rAwD-(MbxKY-5koEJJ|(HiX5wY;kxEY(~`nM'
    'ukrkJLfXcB#Y!kC-dx_6WCxS74~j2??M)uEtrNTH8lkNdh;!t(`Jl#p9y{SxRWxBm9ycX1r`nThRYFAaJVP~rGc_Ek$icZ%2k$F)WkOq1<;&ASet4+b&_<_d'
    'OD@VeX8aU)K>up7(pu&GbczQP^xdIVE^Mr5oxM?+5XU-=u;dmgC+K92#cjgQgd88~)$ScNv%Qq%bP@-&1*X`F%tc+Iwly!KBDzgNm>lHuS&tl(z9RqN**Z8t'
    'Fx47*o~Dvqwt<w8`Y;u@b1B+W@vp1%K<m<e?%ZBd8ek>fqXtM+GL+?r$NyN2h3JmAffV`s=rXWn`~*9J&L+`i=&%I{E2a%x$}`)}aYdgLlfNA#f1^>vtbIr~'
    'BZ-<c@2{o`uPH58FWG090=KJm`Bn-(zM~p;3O;_+Y&n_u_>a%NlALoa^Y(S}EL#mGPKs%xv&!#rpCccQzI?N)1WP3wRWbZ(h7%cBU3DQ2Z`k79CmEX>NxlOm'
    'n@_KBeWh)O9-8a!H>4K)%Imz|8~JonZV{vM)e0tG`J@Vp)>oHnwh9Uc5>+)-rKMSsoCyhJMOrZ<(v!c0%QofZdUNzbJ8dI$(ws9_z*3%Y3L(n>R-H#6*AFjx'
    '1a=Oalycf~hJw2|Zc`g@0d4(hzT1aKTQKkF<BWC{`g#1i`zsrA)z9b7>z9Xb>B$58fp+q4Zf#m$zIc1^iUOf4uU@?T6_1|*=OOv_@Q@BA;q%}h2fzG+c2)Y`'
    'eC)G_@E1e=<ZE<l!r#&^wWMl3eErMei`TzU-NA}fK?4(1Auu4Iz^dY>hwt#09v4Pj;R9;uvzmhEhi}*;{ii3t9zew{Xi+NQL7^}Cn-~B5=MySR?^TtiXR2t<'
    '5BsO1-(Ej`-aUT9uIO&n-jLwuA5V^6caPs59vx6=p8Y_zFP<KBpB^1Nd1X4~&9a(RGlqk=u#tY|iq$d&sy=>oc=-1Di-Xdd1K<7p<mlDG(J^kcUk`Y&tL}<e'
    'uZHcNj}I*O{K;&qJImydi<KCk37PI*&%4*#kE|C&0F-Jk_gwq!=k5e5WPIywUvYdhnDuUIgyzP|3ndBRa|@<M*{Q#ac6?hk-pgam<Vq22ld12jBybF*d(eB7'
    'm;n4LiE42m&9#ctR3C?YR-uO`T{Zmh^S`k73}>d|TF6S&RPHnW$hLw*Q#~;x!cWb$tRL>BgeAN+;D~s<U)Aih>$8m!belvokS!ejp6izF_4{MO4l$-Ud|v<v'
    '<lq*wRc;-KAn|oMAC3oNxnp_6Lh2W@Uf8Erf>k?2AJIpQm?9`IGTkC*^lK_B_M*U;6~fAqvK+ixiS@!V;a#D7PoQq=i#BvsD(mEW+h4!4K?hqp!5^oS`PD3Q'
    'm3BH+d=j1X7X33T5DpX6?~4-*z0<$!Oi10M?H`54p_|VWXLl>dvQ35Y-kbF(bt~d{F?vbtpn2tMQ^sR!Cu52&>JMsSf_@D$fz%q?<v)Fn1DUM|GK}znv7}FS'
    '=wbW3qdaG*Q71M%=W!HHqf2MoO9DqZc?n8+wyo1CkvoN)d~9JO`jALJP>wGz%4=kQQlJ;XIs9N;-C&({xC(8|ujdM8YX9r_g6VtqOPs-Y!%=7GtOlLJbV~(Z'
    'VZ?@`SJ+SmI}P1?1HHwjv+NqmU>DZ&1f!Fq>tjZu$ZlXt!1gyjl3tGLybDv4MBktrlXXu~74{^Luf>FiBVX-I@fGP|I9fAhdq8E^5j*VB+<7?c_?CnEvuooc'
    'Cf-~1sM!i@F4&=rOeuNZgDfDJqKWtqtk?5|2`P(*7=y&;`D8L1C*;fvl?0W$w|6t2jk6o&aKl+6Cm|y7ezI`a+$NVpi~`3CTD)rPtH6>}T7??i8g@b*A{9VS'
    'pT0Xdc*dK9j7TwqhD&i}x#Lf=n>L#sajN1H1u%~#V7Q>myr^zg{?l01BUW?MaIGGs+ynh+8`0=)iwAEQ#c#?L*V1p;fn064q#6Xao32!0a8dDHnW+G_x#myv'
    '*$m;zfeMyWl7J9GDwo{HA~_i8Le3_N1{KOKXpU+L=U>QgTSwnGK)OSM)74!2bYZ9_qtX&RlPRl9L-16w0vOVkWAjzH$<5g7O|bXe*s7~0u^EBIt8-29TI*+2'
    'i1e}f7Qq0G*r9AT1+KMzB(BOIduMk`5f(of=vha#T&`8l>uQa1NomgE-0sWOupd2mv=f;7^<u`|j1(s%<Ek)kRL^mGYS<6+Yyo^%?`i}SFx!66rNY2#0AEWo'
    '7`IAtY2Ljfcrui-tC(1Ehb(>vuV(Awb2buM5A=lH*&=7~H_Duqa}AScTrQ{Zm-M1HzO5PKz?Lxzll9laf8~HA1<zWEjh$Fs7kU@xQyH(<E!VDLW#c9DM(j6K'
    'YS$*?Lawg`RDf`EEOU)F|JvLU{#w!mH^OgA;fvvj>DU{s+s(z^gdBjdO&B%xyjAX`SK#krx_=KK4Z&HZkfATdZ78Z8bsb~6j+She!hqscT^sLho7vs2r%ZmR'
    'XA7cpOYTJ9Fef!7vU??abm^|SEV)k|Ds7Wv?wrxzmGv5S?qzxPv~k0xIcIB^_R}K-OGdQ*`n8sCjR|qbmP5rxAP@K*P9yI7CC&4ojUiv`sJsT)iL$MoV|b9X'
    '0W(K7M(ZV?7`uS1Z}})!u$C^dbMoj4convEX>R4=Lzi9A2LEN(<X@GE!P<yJoUDJ@b;8xbwbdo59Qjt-<ho{REkI(~Wuxe;P=D6oA42W<x$W<ruaocH`LJHt'
    'Bfc~HQqDybb7J(FRz2T^JG^t3@eWB81Jj1f_kNfdI;MZKG5>?v7>@}dh=vlr;J%p@Y}Uq^xs2m`VLQIa+ww%kDvAq7QZ7#x^!U0ry2_MxsLZB?9ZpE`(L`vN'
    'Vgf_t)uM*n0wY1d1}GV?5at?v;kJt_5LVo%<{YIXT{Q(Qp}l2(jo|}j)I#mJ+!0A4>yf6r?C;u$<FcKh04<BBnyb0g^Spe0t%eI)z5zPM6HESeI5P~pHh0Yi'
    'fqBLA`j{t6YKa}9D^5Q+<MJMlvx3Jq{uu`P705_Aueol!I47!Y<cr}*mEBL@Mgzp$K?g21FX-L17rjST3H^96WEUt5U+O2l{yD15dowIKxRSJcrE7e8#lWs+'
    'mstIa%cYFqr6+&wJc^e~9@6|0!m{EW#~MhwErR6Mta-TzNlo?0&VySJt4yS)@zN2|hmThp4s{Z4!?x)dvG_N1V_-$g>yQZqdAYp2NJX;@HMV+}E-mj%Q73Bt'
    'PI!ZKmTeHA4#YuX@$JqXh3gYDIl+ZJF{@fGV&}!X5e6wp6iShVXUez^Ie(snH_A>IwpQD#5!MtPITJYTA91fTzb-s0{sU853z<p~Z*Sr{`4np@?<&$1EIM~`'
    'vo{#fr4TP^u#hD)ItC^9PAsa<trT=Y=1sFoJRc#VSE6^IIbTu*8*Iqg)`s&B*_i0M?@!>S9Tr~r+G_{JDI6_reia?WPbfktboHALO0NI=Vb&BhSbaqgq-9at'
    'b@G6@yqYXBbby)6hKpOTHs&wrjL@$}&}km$mxPMRY>^FW`uq@^fiL4C<GH9Fx^ix~CPEo;U(l`yN2g*%-=yWrx$Esm1>F<y+2I7CpYJpu#XOWZ2IvIG_Xfw@'
    'T7%4bPN}64f;p3;c5*HIYz?{_pt-Ol1tDU}D48qaDSRmMpmkRorUDB~ZPvz&znsy>3u84#A4|3;a=Yd}13skCxIeiW>kr{?_dCxiz_{PoZciNStl_ZezwjGP'
    '<t=4KM=#}@G5m&q7m^31{1LChB^sh)G9yj~Eyl31>tS|afnCuKh4koZj1kpjW5!RF+Trt3@Tsx@75@yZ7NSDFp4yWJowC@GMrvO8Xi{O&9R=5ycj>j=aV=k6'
    'Y^_olBx8p1pH6J>20=1ZjEu_b&AzvD#vi?zTp?oVbv8R4O>UyaWIRL`<!&hrrr5-vm($>R_xL#_o^Eo&0r(B%#Y#8uTo|%rCptuhVC>NUQ=$P56wzTF50VJ;'
    'M#Walh>FC(ckut)oK4{Qz2`G{?&T+V?&K#p>-Hz3QPy9$c?!-bgNpym$scg$q$xNf_Yf<aKt6lGSwR2<y!bnDfSC(MR$!1E8|&V}AN~ZirWLi3rc9=BhqE+~'
    'b3pfkXb*kQJ_;_dB<;jxvy)TKbN^SyvHwc>5bhlwza)=z64k8C?;0<8Er9&9|EmD<pRWRt|NMUxKt3uy^VrC;zZ_jo9!j5*M%spoKOYT$d43Vcv%4tIh;1n;'
    '%{OAT8_YYBTLCpach5vp5E+CU@hhVKKL6{X{yzWOsK3uk<2y8l@2Agq4c*WjP$A;e^P<3w|3V1duZMB_H!5uil~zN1xvnM(u5>al04!~{EO65Dt2P)tibZe|'
    '_#)NjILxBXf$M%k#>(o^rFII;a=F**)M{X}P8_Hau~zS&L>5z8i-fIpq`|?BJQAWJm9{C(q=^>wNYIe8+%oVQMq=d<Z%sJqqetYoOU>m;5!JLWgphuGXS(#w'
    'I_RUfcR-AlU095=XCcw$MGha2&a0o$G~rYJOa(zDc}EfP0ryg0D4P~1swjl!3{S=>ow<|AWaL1YYEV%+s#c?f*&k{#zk^Wh$AEQj$vN#c%fly=@s&(D=Y$x9'
    '5$&}0Bc%)yRC^tFXKsFUN#&e%yB;(x>8<lH<N8DtzzHjUE<hH-44Lld_tNBk9@^Zhgc@Ee_@}@)<ZhurcSCE7^Jq`(dSOV20X5X_QaH%#WqC8`HNC{78|2C|'
    'uLWk_tI(=W(s}4lVb`dBY`~s)ES%BvgJ;161<wr@kE4kx()Nc(z6u(y*Ose2TE4p!xSgY53iXn7O~{X^bzHG(UB2$u=+BY?)T2LrX4F7JwdFK*BxY4T_fHz;'
    'Udh)~f(E4(j6DjHyscf6`BiTXr!l=X{#10aPz=}#@L~Zwxw)iiL=MQk9%KQ^y&_!vr6QF!>>7DtE9ce%LRjL)TI_XquRv&OBL&Pz%J+=Ns7%Ew)X*755j5Hg'
    '&W+_Do=a_RMdMi(O^^>{xV*C??vm(*Vh}hzhnGbTH${hD_FcWG*FI$_1BY8e68<Lv#5t34cYwI(e+knUUcE<$hp#j~9O6bIIgH*<CWE<2!Iwp3@M51sbsOC+'
    'r8ibTn@leLGy~Z2k->C($iJT-{&qxoY+KDF+S-DDwqt%Ho=W!%*5)~ma!Z!MYCh}Yrcp*I_{n0B{u#D0;b(u_n0VQ~nz~X~{?*i#B|1K%-_si=#3}2SIo+Ov'
    'ETPai^a0T7yA<_z5!u@ot48G)==au8zTUsW51Ba9UIo}UyRxN709a8R-=}V^#8Hz-E481GX1R_XscP~eB#7M|#hkc^RuR(6eR&hz&6CKQmU;jTgp5qVf!)FF'
    ')M{(P@pzwjzV5bhvQ(98+b0Wjx0d2nOXrQ{+Ev_}o5q6auQuV21;lyJoEb`#8IHO-!(_eX8?!_~aBl|HRrIwUs0b&Vz*R`t_!h@SL8PdQ5m7v^&SE_crfy)T'
    'JXS{Z1|NETyi=$dS{2TX9oSzohmF7%_7#c#&1W>sMfJKnwnU>E7dIbLJrwuE({<}?OS3M8tD#S7rL4Qna7XCi{w&byx+emiLEnajKzda#td>xzUOfHvH(5U1'
    'e6ZA(xB49yR3^U36OX%Riw(?n3)?OzsDI=)QmV_Q1&VE`IZTG*TZsLA+MD+J!v$*Xn+;LkTFd2p>@ZH`2Nuxk+C)(Ik2Jg(v!vN*H-E9M>RpXPko3BrguP}a'
    '*VffKsZ2{FXq^<iyEzSu<lgo9<UEf>R<<wmH)$2-;_2Tdr;wYUx1a``$+pg{6jqATA+TywhpMznYc>3O*SD$m$!{y4cSQ%MTVj`QJ;&q;avC(>VB^bRcT3<u'
    'ko~19>|_v@BF$9wI2>(9eK#Q-1z)RJ1!^mfy`gWSv%Vc<gQ^t4HT14~s@$m!Cx~ikm0MW?eGjOcbZ!EyI?*-61rF?m`m~kwXasyx<m9rl@+>flVyj9{dAdGS'
    'o0sgv!3fFe*o<C2rxw$T>}t$#N6H&Nm8+5Bj6xuEs=b1Izq86;YQD3cEvFS*t`KuOb7zH^uI4|h5PN=b^h{?<ct4rIZTSQ2mK*pt+>3C}^v@=6L?e)KQ7MMk'
    'N_8#;r&lx7hGe9|3Mj@(wPI)4Z1CshN_hTki&GB4Dm~hg2X7BCSK@<){5*Q{_60s^Zf?tyS1(?7e|bWBv<D4>Zl=dC4-bF+>B&>fw4h2JzJYIFlM=1^^zdCZ'
    'iK^rwj>|^{(1QcX-{wQro8R94CXX7V)WL_xZw{U!ryxGU$}{~_r9UB{`t1g?4&<u<zji1<gq;!KCpuP5$!4@g=(wc#wz3|~7c+QpHOuhX(?j6xKZ}32__^z5'
    'cARD&y3K6qX13jClm^gg2Y3k_r)f$#&g;f@oyH!xjcx13cHG94nz694&uU7aAHM0n{o@UL<4Y&*F{8u1=5e_9><z2tZ1}Py4fb@~Q3`abjMn#Tu+<%8ePG!q'
    '7{ye<YVaAsIO|`t>}CeHk5UHXBevXFI^uk01}sLmfvrfU%7dC@>Iw*Mw-l=cy+U7m;cqB<Nk<A{x=M9Q6|Yc~qQOqj;O@Pm91SSJl&5Fl4#4g5U=#Cot(J&E'
    'DVy<IZ`7w(cv@t{T{v6l2Sp>dLK6-?PDw`y7vW;oi)f}I{sbcq&=>Rq?IbYSFdrBAa@M=y35k?IW<nCAJE%~}jl%7|aV_>IP-$D7DU0En!dkq-u{Y*<A4I&X'
    'QC4GzF~TGf4=_rE*~J(OYxuvB&Z{?;kSGeWI2+ER#qBhcb;7Jd<0$L(&&bW}ajNUVgr7KF=ou09<}m1NARBhx?~OPOk-igRD{uqmT<;vX2-@6wVTi)O2#F|^'
    'tM={Dp)Ui}+7|MPZsyw!5B9${;MCgcle+gw^qoA=WI2eijL97a6#sa|Qp+I0Lqiw=o0#jf#<fhztXby>3Ox-a85@{F)Fx9F>(7&j!fECUYr$UiX74ddm+)#P'
    'n92Yni&a1yJop!X{;w9Y7{eK%^UkvCY<xusHCJ=uZb%vt<E<QjDm}lNPH9E2=DhB;$<++b21v)~RKQ0{G^KUHg%7?hTW#*4tTyfNR3=_sd-9Hl)t#IYQN`<~'
    'rC0?;&|7?^D|1{+UAvzdoKe!!^lk%zK(>?el29UTBcPXxmCoh2$Zow17uoGvIWDlc$#Nm`${J}cvRjkb!dLN8y<u&mN_vsq2Gd@AYgU-I2Xr!<MG|V7%}kP5'
    'T@FM=nunMhtSM^=juOA?Qlvt{W+E4f!V1Xplha5l8%IqXu&R+Z83{&C4paBgT28(|0rWmB@lpXIa78N}Aj9xwQs$Wp|3*!Nc=5(183VMOEHm9Uv)N&y6nf)P'
    'Daq_ERw<lv>62L9;+#HGJ>n1Z4u@zYz{1vWb&>{lLR{90ZLM&PC|)oS`5B#wYRGF(t2X_evvhG}>X)v8o?S9xdNWSX!gKv?^hQL;xt1=Y-e{Kf2DgM82Iut@'
    'y_EU(g}Y%d>cLLGfcv#RAHsinGa<LLt1;IxN8Su8+PtfC0DWNFwWXnyv(Cs*!IvPlOJnm<q5d{UUui-gJbK_y;=RHWs^Z4KAaCn-T?|(D-9}{@0zKdur4Gjy'
    'OfKZSSxYo&Sc9!i!{2tQX|Y{eFBxud6{^#9IU{A+q*~Cr881N$UV1PVCJ=Nj0`(<_rNqTgw&V&pTe=~gpT_Heeje@w@ICXcDxC1y>sl9_JCGz$ubj&4#^+{('
    'bFR3)RVWc=|DeHOlKFE*%|Sv#8@vLsSQos4tKpaPuJ|;_rg{it!oAD_qZB;>Y9`VZp62C(CNs#2RRD3z`?^G6Qyetwl8|Fout~tFoYiiIi?c4wio+0*wVZQq'
    'i63BLf-YnINEEY7i<TH^I3SDYrE(<=wmD~vV2Ubvdrq~BMUCRdx6#r;7158J3qFj2P~OZ;Z@5$Uy)>2oZX<Q~u(!?K4Q;>lBTaBxc)JznB3smeI^%MWuaT1p'
    '<|2dRtJW!SewFuysSC>4-3oc1cqEV|kD~Bq5_!IK5XJz?yJREfiVNYDxY@^rF&)-&HFJJ>-kwzZp7w)!*F~QYJOmWj7i+51&2MNbhAzAcA>qb&ir361xY%{O'
    '5qN+nuvWaE>LvTBVBP2-S&g^~9X-F&NhPb3Dz$@T&zTil*_HK&gUm*vutjJs$rZbH$sAwZ`l#b&p7TZbx!mO<wRRlGOl%_Oi>a_H+7%wifJ`>V@46J#LWMCJ'
    'D}cd*7ehc?&|(M>BQFk{0buyY>Tp4%gfA50EKbtRHfrfr+pba-C#5n!A5L5S3EVcc@8*^8(9V}5N#jz;9G-WPAD6rD9D#1+#=2(U_vxZ#t7;PYz$j~QFHpr('
    'iD?y$1!W4L=wjQDq7(qRp$cwRC8=zFn7}Pk`EK6&ZcvH7gL9ZfqG6bbenCLvppQBvMcvW@s|$m%n{}WBCM_IYd%_+rj+w{vsbX_jO2u<~+6GlF*k$i~!?Aph'
    'r90#xI8pJ)lk+b5v^XUmi|UAtR^QV|=$iz&iP&Z*kT{@3YgA2Cg{B&HG%Ll1XX^LnXPQUA9Vz4h`hRN&s$#k{?6~TRwwBQmSDnTmR3nmw1}cBg^=(Z(+lY1>'
    'EjKv-Vlv2RnX#iQ@B8oO|DWsx{7h0X%S5;a^d%LYXW3M$Vsrq9l8Swzkd#8-CBlq{QK0U_mn$gymZ;#C0QQJhL6z_vh@IGfH|k$I|2Sd(@tU{Asyk_(0pBg#'
    ')OblX8^-k1inbcY{DekB*93*78#*eX6+LWNqJ@@LbM75qDvT-%t$UY`T?}a>cX~bur_i|pA))dD(>I%qgyxMDvG(mA2Xe$wH)zX+UXsTNvf3B|t{cm_<-r=&'
    'Q}fC9POF|LhJSFhvCj9~FwV+FbE}<}Wpc%5`B=OmZFgp$dHpt`ErcB%lYc?hn~jFqOkq@#y+%|)xQi9Yy!O>p2wE7p8r7a1*LS0DAH)IIq2;THen|z}CFowo'
    'vwaEEY>?;Jtj|Vxw!JGW`EH}}nSIA)x$`bx?DXk(;kdwy&hCIdc1v3bx*yq9k@u!!1~86swwP@<5_`Lak7@Ayy?pXIHyYJEOqd9xHxp=jcE8T*1ccNF;W(k{'
    'UA4S4$e<s_LA~QyAaLtpQGWnA_1Z^Hb!*T>sAVsOaLy(Cw$uLTrt-zc%=Eo@`K(Kvrq{meJvTzp;#^p{QGEH~$0jVVW7RJ@`r@FRP=@=b%ITSklo8i_ucg+6'
    '=%8L$db-u}$>!>V2+SpSG;kCM)0H76Djn@TiOZQ37}#>Vzht^h)43@k>)+C4<&VWd@!lqgx=n{7b&v+AlQj5Pg}=|Gf)WS&|35#g#il1*=~e*sAi85<fE_Z7'
    'qok5c=EZSJ@xKbh@v3!E@fP_AUR6TJ@KP|F)iXC3z>U7M!~Ivt_Ui1vVsFO)hybyWc_WyuGh8)O(K<o*zG9L+Q^dR1nj|M$E1%^zW@iWNpXZ0e6+RAzBo=d!'
    'D{+!*ISL!r&0#x~&~(pE!~4ZP!^JW9Jeky;&UzUF)T%W~&R;zZjWl=uEN?G5ebzT6-o1_}M-d~li<;+9vX;^Zg+<HPA9oAWeN<ly`O{ZJYwfFiZL7Q`Kf8r2'
    '+d375KU(=!5K7%<`rTm^Esy4hZ!}b@iSFO47pKU(6v?)4lzMuCpgk-tan88pUoX(v)V_A4^E!Bot714Vw0fWvneh%_jJnbSG)4xQN4t*JuC^Eu4*_OyFSV%2'
    'WW@w>dO2H^aYgo&w4k9M8|xuITIXN6<Jg*;6#Yk8L8$*!oJ-o^-}a52HdY&rOKDV1>{OaI;*~%pixD6(1tq+cIQ2Q(;sUEE&)ZPAqi*7Ya3sr^7q5(Kxmp~X'
    'up>-e{9q1`o|@z2<W?g3fjx0l`JuXu!NSL}^QtWCl|JnK$@F$}0F(v)2#19D%Ds|i%fdr)3hTQDh?t80!`T83-yOeu@<zpoaBPT*6yX>VH#meGN2#0+5V=#@'
    'fXNN2X9_|@qND8cYB<a062a0tnOtXIBbmUljvLw8;olTC!cipf%Z(a=2Z5jwcxnfTkX&0$Vtzwz%SXSxM6dbkcyciuomZu%d(I(n?Bx(Rc5(>JbH4fT$hhXi'
    '56?3no}A1k=h@i&HpD%UIbiOj8kiU55t#pt@nX%zeA>IQbW2I(1Ze-cfcwh<!b^d{mjZ$p0fEc3-W~Saol+G4T<gs_>yFf{{s%KC++$9Ij9iF<X$uUhB9U5{'
    'iRrL^el?v-?7-a0muCw$xugggx!yF_N`o-}pPdE)(M!@Ofbd_ME#Y{TYzfEfWJ_?8B>cy7BUqT9u8uhr#!Y+D&V|6BFhMkrJhX+?l#PLbkDCg0^j)Z3IRjq9'
    '%kVCsRf%1?L;s9YcZKfJ$t<6iGvbI?@AgHxAquljPz$+G2|q(a$;~BI_s@WV#EkMt{)F6EsW}A>*q{ON=-t}{Uy0~M)%Zu6npnP%=vzv@i7#`;VXlT$CcXv7'
    '(z<zt_noqGff<Jp@um4x;k~Y8W7&cFCym+8l5lc$izwD3b`K>;<-DgA8Ov6K>vG&%Nn@+;9M3EE@~St09k5V@w(|O&zO*ngkuHF1c}cBbvYqEOg(V$RG}1Ae'
    'c?jH8)=kylX}6l4Ql2KaBY3J?A?w-NS~hmtC^9)&LxbTEJTg*7>L>#tA6HO6TdTaImml4i&T%4iFrLzrt3_9*r{#`94_+QV{T0E^aarx<#(#82VEE3Y=bis4'
    '+Q&<+jz4m32PloTUD4LA0y0iWSgYZ_>i4gv6i|Xt9pto^^(Pn5N`!uA<j{)oimdG=V27Oh>|{p#>EZ;|^n_U%{u>tfgq_duXwW%7!I{BjCynL_Oz$F`setM&'
    'ACY(VsY%8Uo6Oqvrhl8m+_%*!?da}y{C&m|HZmk&jE3;frHo4bBr?V)ocIe;bq#q;Q*TTPNr$Tqt7qKNm}XM-nL8XFiXt%`)lVLa`;N}OdY@19ETx$`btr+^'
    '(47(;w>K8r?bM!k-M^%?q8}Hv%hD-RT_ReX-MX~;67w;Pi>HdVved>o4tt~dMCNJ^lnAvAQy_w<crg1qnomc=g(HaIcvRw`<FA=G==d+EpH@1A`&3V>It#SZ'
    '<tk~qCCBS2s4H4+p=xwA)SmYG&I)U-Us3vMOT|JuYSOQ$zief-)~v`6?!t;HYtggFr|W5|??p|#4$A2rJrM5)q4e8G6xPgLqH1!U(<_H;cLBSf%`UHG|67Mc'
    '`48Cx*RTsZGLNNl*e|QM+%6dOt<m;DZ^yck0fca<G`E(oKPhj09{zqK8c=xCz-x^3^*Hh&HYxB+0MWiUy>h<l?&LfNO0RQOSPJLBvV04N8qVmff2Nf2TaB#;'
    'jYrMxAC3-=e|!1%c=KY=A{ek}=OK9z&W$JKWIVc!roG{SI6wr@$lkxFE`?gc5G~<LBh-2`dI&wOZ8Vdu-JR$ngF2|ON8DDtCskWt43VpyFE#`EkV%({rR@C)'
    ';?i9Co@tDqBnP^a_^3HdS>_t?1y?Sdw87Ko!+v0eei8WKw^4IPCQ<Rs_Q=TFOFzHuA%@CgGRs;K&QD{T=BMDy>V2Rl0V}i7hqTpE4QVY$j&S|f6br;s;sPYC'
    'FqIfGfoD=lEYebe*IhUqD0~mM9U}+F%0T6_t5N2-`{xLn7m~DI`{%_;N38f7r_I8cnk4c~tGTcm!u_y<YK-kE{=9T@?kT#)p|4h?jp<84piL+S{YC}W;K;(4'
    'q8&JcA3PRqsU48whR$fi9Y@Z<M;td(r08UQjcq;1n}=a_uz|QZ=n-qNgz}QuM{{c@d;ubpt0H0&kwA(*F5U4ZQ8HhaYGxVodg+z9Lg+e|_d<eJoPts(-xX8R'
    'l+NmSf=g0JMV3@wT6HcODd_k>Q)=xLO+Dd}h&w*_DVy4S6n3b+U*PwEVFpcl#?X>Po}ng)OyOE<tj+}V=46mzC|fs)bj)gfFNt)Bh#`iM*wRqf5hOwiXUNeQ'
    'wF-#=4I$ujPb)`#PJQhYLJ^g0P$%!3<@VoMc~9TRF|jvX;hpGDm(~px&(}Q~dV&+C!x7Ax(i@u$KdnyuUoerPl)LLZ78<1T+fwWQ*4dUS65&ph9FDSJTc<K}'
    'CYJOW|HT$e2zCKE4)jXbmhaP_o=faol|SvQH@k*Am~ilv%9O2mbOm8TEf5GVq8<r`w;)g=NFvFIXEq{-%!ViyTESevPQ<LWXL4b({|%Rx*r!&%h`v}^WRBj~'
    '3D8*{s8i^fSr99`ddN;u=+1a07OUio@}QeLgxZ*Vnn9!f{fEkw<fmLSYQ{@g83>$NA%JFmQQ|9Stt^S7DT$|9@fKJ;zGiuxjh_C(P@5GyRT6r$MhH&9Su%+-'
    'y>FJ>QD1<;?`bXWoRso-Ee~t<vOf6z&DKNMl!M-syi4Jvx1#<C<oWvh9%3fXdn1IB&Fa|&b(}Spm`Jj|7+z#>f%LN|Lo8t92z@vkz8{Wzqv#?-_}St70==T2'
    'oLxYDKVh(ObolRVR-G$)vl+d_wii(62_BDGhPJ(VR8#8P=I(Bcs<RucoluD8Fr!)jih$a5bo}({WHjtY<i;xSi{xi8@rucHe1ZU|c+-=^H&#urDM==o`8T6?'
    'XLv{9mki7}oQuwi(4<ud5I+~2OQL`5Y{RgQwjYR3Z5<y|r!!4C8Qqbl@oX|1{u`b=+#@#!yBYW~Hf^blzdfFBH3HM~>kKvl`|J9{yaC<?$Aqj65RM6Tmw-WU'
    'XmmF)<e|vd$nOAGRFj!hJNVm32Vw}IaCDO0PVk~c?BPD#@>je)_E7)Lc*H$SDa9LTj~-E*eAUb*^9=X|Jz{Kva=5G2;8mcj7=EaEl6{5%n-et1ka->JK((CU'
    'B)o^Q!!GO|0dFoA=Tt1%{OtMR(Tjf`zV1GKdHDJueds?vIDY!%<&(Du&r*zSao@dqaddQeWW9Lt_TbfVTB|a!M>VN3rU(3C;5^_50eQfG4}SRtf4zA5EBpt+'
    'j47i6)r5-n<MdONHO<vlO$rl!NHtEXM$3;cr4HSkE@tVc{YsopK~bYV$CA_?4YjZTS9R?PSkfJu3`TcT0Q|9_niY8L*dW4{Kq(itpL!)dFP&ft2;f;n(|h_!'
    '|7L=i63NDs(<Rcz*;&#?LXTu~xew6>)5X8^6GP+7BV&%{=3txr0&N~20B@RhXWI|DeC{*tu}$A;*0`HpUiC&~6rLyS&!Bj1I4}tvjg;QD`E4iRU(LGwc74i`'
    '&A1u2tHk<OJMm*qn`A#rQ>s<}HU(I)uu7;0Zs%zR9i1_-*Ne;!H=U=pxt!{OmiD;IsqdXp<>yrk;7mD`>tWkNa^RJqWq1doPgTp%E6j1;FVd+ge*B>2R*lzZ'
    'BhF2>_f@*XQX??G;Wq)uUCmEFPB$Ozx>JqBmDO}k76-WAQWfbT2I}v2(zM|LB1`&$TwVtS(lk#k%EK-&P%_D-fV7i+(RVFG$ET?8RKep@40R*kFsTrzWSpj6'
    'E(g`$tw4u$MlnNLOPXqiQ1;E-;Q=n*rI-~0IG;z`Ez)ejO_+_X`xlwO@Lh|n(DiU~#Q@Ic2Bn08aC5@d4&U<4)}LHlOgMl>IfJ6PgjuQyCVn6;V8|`Q{hq-+'
    '1?&Ufm7}aT_`zlxZieH*<R+@^GHViR{lwg>=X5d}O%P9!+k{(^K4@9PQ|z4N2>>}rTBV-#&Y*4V-__gz{Nu1wnnGHHD*mp<d-$I&^QHb<d0aIMk56rnDyx)+'
    'l#}HoS0)pnlBXH?6b{xJGzGu-CdD?@*Bedc*CpFA-#D;6E-hn@s0sv0b3{nlupC$IJSNN_dBH!b9hHgYW}JGbyxvTtdw61X-^u^!QwRafnn0d+>0Q$HL3<3E'
    '!{gLNu1eD?%4by<4a_@**oC%w*-4vr6k8gMVQV}0Q_<-*edJX2DW~YeIl%m#KzKC_yc~O%a`RXFX(O^4pu?-O@y+dz_tR!8k5k0AtU%lgWN@82Vt#MnBH2|r'
    '-Jlwv7lFzNzL*sawVcZtgCVCSVS0~KKS-}i@2j0o+xHq)QsVfw#`*@m)VXDbRZLTwFRjMlzT~!1Z0k%jk}@u`ixWgAlQc3yw}ci6l~j<|10p^N<=CO#A-36V'
    'R3k!zG>+7h=)#H~ODIMmt>RL4%QdVNfn;q#DsHilPLJu<>D3IwX$}2S#0`lH6LV+PaH7o8ghImLK&mvQ_;X_yRiXJcUa78)UAHb&=*NoU811@Cg6s=zKJHC{'
    'FgSG1MZ67DDyLpzgi9%Eq6rvt%>t`!)3rDe!sZlE^etv)C1pQGy9GQ$Rd&a&y6#`R)e=1OX_2x~&4ppADeO@cF)ba6VqFK;HL!P<S`q@Q1L<9&JkqKn2UPXx'
    'hIKuAOj%t-{yVn6+p<sdya!TxT2waPbKWT0n4Y=tN3uqFQNkXm#WJCaWpta*EJ~fxH>%qyWMpLk<fa`!*$MZRDs}eKvVInMix)eK69<u+NC4LleCbucSGuu1'
    'si9yy_#WVhH|jZo@2A4tbHzC?aIbPbgP-_=7El$I3tH_?qIX@ZkyJ-OU`N$fKuwV_!_^|caEHC3N1wf3!!*EcWQ)McYx}DT!Jb&g^ONF#_LMv%qwS;(o4k`2'
    '@?mr_#JVC>JhqTx6SI1Qkx`6~sM4oog37=*3W|4g!oe4nTsAODFe+F#;Kbq<iWu;)y@u1M)+0C#eVx&MjrZWcJv1Ce@|r6giM|uc-C#;@ynRk?je1nHjL>B$'
    'Iq2PP2G+&L6UqahEfJ$_t$@}80KG>LQFx7vr6)VftB~D?R)zOnCk-jPC{m?&GOsc2Ej1q3`3E!=$NP=VT^4QwUq5zR5Lf{BVZd-~ZCqe@aF_AcfIi~!Ue+C-'
    's`<M2K>fUnK_*C>&OROwdb2_5W^%Xa0T5s}Q#+B8^W+*N-)jyWO31yiU8_<I;PLR^Sv6@k;-prkv-T#NJ?q_86W|Bnk)0SGi&43Y-p5yT$sQ6QEPU}6zNA_@'
    'IeJAMruEorKG>(jxBuYL15rP$puj0v1dDEXGiB3Dy|DWQidCyG<x={R?ilh!z1b_>&ARoy(CQnq78qELcDW6ODs;%HRpp(wqT>7tZ$|s3a$+R6n!Edj7b0$p'
    'mae;m$^3$@i)z4D#uxJf@v37}$~n3dVL7DJd)8xhJ$6z9-k{1k)8v8Q-)WSgix%iWZ?Txw?4c)BZLq5%-x&wZd!A`8wQHBRX_;ZKQmOom*W1;Mtbp%l2x~8L'
    '8Q+^^X^G||n6jvMJsBbv#0_+M1~=!Z2lwR}ief0wEaq^9X>;DZcbYA33F;RnVlfX{^%A<wcOPz2M^G`|-1;$RhrwsW9UY6Z9v_IZo<U=n*~iDH=sPhFF#D99'
    'P#`?h?wglSUcWv#>H^PN6-q_>q1s_lK(5cWBNucM{>hbSE)g|%sBcbf&l{x=XOEgHdfrq!$@jL;jcBR8=qyg-<EU`@6!R^u<W)8O_;Hi{)>w4MvAwOfxT1ES'
    'lra2*n#Bi}O7w(9tMt>9A#4(gTb1(S+)klJk7e9I5-@5*WV30~urpRNUUc8ZidJ10uxM3{mEjNOGNgnGk4&Dh;z_z65VYMj?qQxv@~P2>y=HHTM0yVQWTFK^'
    'p?yF6u(bnMF5R%sA+#%Sw;>*kE*^})PPAYoRSVy3?R=ANZMOnph4;I=BxVdX5dFZ+=5|{g>JmuQSEEH51eV)li|-({^rGKJN7=>X8X4YM#x6tf$K@5d()D`?'
    'g+R+lL?;^q`9Q^XZ!x(T_M<+UcFFj@X=;P+P0?(B1&clsO%rq!XqTxP5qc!IA}QZFc1lq$tadY)Pm(sC8vcd@@I&j}O>>lnCnVmR2<=NtXh<LeG;OO7jTtTZ'
    '-aHd)R%Z{*+^HRQx%9}ztsq!HA9n>V{WqFigfkwZQ(BtG4nQRqHoNco{sle%Zc`uBeUEA-PrfR7@>PSLd@6U5@01q^`>bMSp=#`s2=f*f8{ZPqa9`2A#j&7R'
    'B6Re<FJuRG7Zds>ZsDpZb0Q5e4?c-STApK-UOS?<SU}TBo~BeCY#U7lH=1RA)t@v#)RULWcB|htTOEBYUDsUuDg_o*5v?xY=3Q|FLFNS)8h`ppxv)v{>F4^H'
    'Lo&Wch9Ux=bvpcr$Qv+CcxXTphaI=L)nrkt67?bk?I&$9^LKPM;-4mPw8fMl><Th#NbE)FA7w+*_TrQbflUDxgdU?Ai;8_nRAs=KTwpqu5A`O!#>J<<r&FjD'
    'SfraXgcz9W?5$_LYY^YF=_p%}&x~|*GnfB8pJz@vEa;EwwXN@=G4X!<V2DyvPZv<6*q_<qL>Y+Xs&OSFThmo!3=0{-aOXC6cC=i$8@dcQ??@UjEIIjbY_rll'
    'e*B2!VFd9Z=SB?QYgetjC)!D*leF0up&wYDp;B9@TWgq`mf2NE1K%t&u5gKte_`8Jl7b7{F0%B(#;Hn?Dp0(JnUNK*ZK<j|d-P-X<Z3`UNnpp6Orpy(7x346'
    '<Kg?WMXD{MTiZ4gV_K{2B&e;}rGM`vyY%;N3>(nge;lyMH-e&Vaq|5|Z(5^Q3BOWq9oF1n+bydmYONDYedTSN{LMJA4PXccR&C|ry(|z$D~xm6GPmGnA4nW9'
    '#&P1HF-~Lc$2|uAIW<ntgs<kHtHqBsvKlkxlR01T{~k^)STViY3K2|WQVMHVuwOKoBk)`a2I3M=^GFjXdSUo<R5QV5m3^|u6g3%5U~%cIK{gs92gc6RnxUqp'
    'iFGd8*#hLblt+vcQ0IDh>kA#U^Q%exGkq4Zg9`oq7`X5{PM+7l&FkI>*uGjEhq>taA}zRxRLv?s9vzKT0Zp?HRm$n>PkB8~X%|^M9*|T1%y50aKDC}=9|}(*'
    '|EKIQPT}^Q%wgxW!<15w1L%s&noFe}d)Y}l-d%a|Rpap<eJG!=wFi)A#IL*+-^b0MZUfURHlJ@au>>O{4U<b1IIe@P)pwVVu`6026-k!Lo1W^gLbI#1K^$Y%'
    'B|Ql6P;8BDCZV4D8^>j))UC`_b$Ja~^;lYv!alH^sy%O#l{;SSxO!>sVnh>B&eprEsdD>5L))G*ff*&w*D$b|+5;B0&%Q3(ERRyq6|u%?BMB~a{<#9t_Z|xj'
    'PpBr^0H?jt$oWj^(?X^+*}dXiMan*RL;Gf2yf?Uj1W}{SNuIzp7`P&xC02?sO@rM7@>o~Z?6gWZy`BZ!`0AsrPSD<5QjM9hyluv_G5$B%Z4zc5pF=;N!X5Go'
    'PAohxGUv3^na&9Z`cwyWRQjFhGDLzX)N=<{!P}c;R<X{Kc>5I;wsexA6KGWAhE$cS$ay3o6}hQ>6%{$->POc*J8Zmte}%Iwf+mQ9r2pP(CR<w|8;a^2pVhav'
    '(X3m~=wwZ1$jH#QQSIROH}&T3P8{7#u114saCI?_RPKSdXQ~)GNm+pqWIe|0;e%}62N}1|fu$P^<Ts#oLO`8Ik4(R|H=|>T2U(DDd^AC*F9ZZ+XlltH3G01J'
    '9Hh2}qX$miiq?>}#kW)i%YXzdGIozXqaYTx#$#Z`n_s%m50BrbZ9XV;Ovu^C%(!OUNRI%A4bxQCuHz1aIClSl8h$%EPHQm7(biT>k5nuLM-)U(gg~T1C?bhd'
    'h*Tf|e~aKK&z}5&1Ok6OIr`<r>$LuWd#mgUXc(ep5VIV*T<Ax9Njr~Z7q=S5AaUDOZv$H3piu6+Ju9FhH3#a_L$%bt8HsufGU}rTB|>^RT%0Gj$6?7mZ8q*K'
    'D%uQacO9Wa<<zBZ?ukxg(UzR_-m{x)$h<%$#++dOz1eX_9?MmGE!8sK4~2#5&(wjdKYCQxJIJv1RNa2s2y^k|4Ckr0lsnuWg%PIhfG4a#4hh$PY)hZRMT=cf'
    'Z68(?rW|m3OaPmj@p<{-u=L*L;x?tExio@=KJk!77q?;8RWxcSpItef8VfG(TMOH0t3_i~a<$U(PyuMgzTCJw^%NevnpHi~E*do+8V>n{`Lp)!2L4Si;>Y1#'
    'YzRQxKmW|Rhu#~G9X1ff-0I`SjV<HgxqBO`u*Jo9@zQaq$O=5YGNTLWU6Y^xuXST-sc{!fm_vi|98G9tbGG}C@!ee`o6pcy=J*H|HA~>z<Rqqo77_7pHiV~='
    'geULa7p2joTy@z;Og@1|G`iFgDXI?q&lGO&EW(q;R{$~k+E;CmE!Y@Gol!0RV`t|N+Bk?MaraxBsyRA1JbHF;)cu8X?}$xMy^{nybRuXHXBqWU`xQpcQ|xz2'
    'Ny6!|CI1XBra&E$0L>_y5(04WvJ6e2k1P}F-8qS)*19Lrv^VQr%#BdYE~`0xebIMb8}yJejVecDdV;`q=Pem-EC+?>mb_>=juBbgC$El`vcj^hpJRKAK4m>|'
    '?IXfjQ!7=CoSDa(M#vnxBe_2w;ssT%;BKW%`@EwVaC+_1GA`qeUhP34y4{N`5%!}C5;M(SBjF2`-tk}b%3Xy@rE)}}-L6@9n$7Cyj1v7of0Fe^?|Ymk+U+<r'
    'OG&1(qt{3o2Op94FB`;Sr8&wtl%O`tU~R85>Y4f*`WBnmCg{J~vpAG^Pvc><#b2IB7AKMQ8|&!oVU<{rHZlB5uKCNW>?$*9Z}h|=wu<$D>aZ9C3y}qGb-dfS'
    'B1ToQej~6~?BrxXkm5FjNaMdfi!ucQa(1n}20-P8k-Ddykkxkr_3HxdVHl!?)$KvhJZxVWg2+*J#s)u6@8bgS2fWq@V@2a%6y;_0t^)d~QHUZnCY%qPL>L>v'
    '=Mo0fgb<j<)=*i9bE@J9K(xVno#wK^EZqF+akSfLK(hgK4wAwKg)6#zRcTMa_dKNFTFq<*fO7QiBlLF^_8L$h3APrmWWh3V?|CZqn$Ku5ZIaDTFvg0a$~3Wv'
    '3xJqaV47A(Mb)1Vj^4g_`Qo1kN7Z<x&Ny23<$dBDVrBg*1S-*+Dd=h;y~1-bH}0D9w5gv4HwRn1d4E_gIje7sOFGIjEx~2JG#x134wI?Moy=MUs5DFzrb~AW'
    '@q9p3p+8Q3Yu=K@NHESM@0Ijb3#mlBC~<rpP9~9WtYIVNK@_8%(hwg<%~qtN0t>*^%5a9=E~Evc-mrRBm!9oe?bd_s@?_va=Aqg9BnaO|ZbPb&v(>b^?V1Q7'
    '{<qn2nSxXDXhCKQZt<GW2lzKXhj=`Ch$&Y3aQCAD6@^6fz91n}1q@=+HV*Gn!4!kZc!F3l%nu8k_hOjMwe#3pRf;m-jC7dwS&!Vpdh@d%`XY=FRLKH0%Zoi?'
    'HmGr73xItZ3^tWw0=t>&jEXS8uI{7toXuD!B-i+B;oa^sYFtR)kiq2YE8LV;jBfC@q#>ocoCie*L!=$y3}|znEnsPTS0l9x+wG3=qJy&jRm=4-5F)jtTwPBi'
    '*%E!|tP>(<&mJ~{87Ulnh|{Id9yUO5j{P?N+=+HZWly2{67vnl8ro3}fsPb$F!T$N(X7c`OcuQnvKX6<JUT+6+avvvZaXg*SU9izA^T&fPyEY_L_f;40|i+4'
    'cQVq*#BwopH{@sI0vLMaTI|h(YZSO;)S^x$t&Zwhiz*R>O>@PJ162TZ7|!Ooy=+M7vQ12?l_bK9NuH#GeMqE%L~U23Z%lzdubMnued?*^Fo$hY_HNDUMY7|*'
    '1qP{>w+9T(NdSNtSDlbgp$wJvTt;b6Zsgvn46*pyxj2{vxEF@V{C2KVH+)$q+Fa^#X5i?yT2Y~H+)k$A<{FtKQ4Qb7sfZ;kEtfQ-WBJo_T0gjj4g1fmzmlGm'
    'pNE;AiK2~jM_$ThDGahkA5hG3A8~sh-1ZEqnzui6++S|}@MTaM*+MSs1MG|;{_&tC<F)D52cKTxEPSvNp##eU4^92TUT{^xMZ#cj;$Tg<w{1-*Mx(?Jy^^Se'
    'u^=CnqF?D^_=LIY7p=g_X?V0!pdmGLl}?StzN}s|Ky`vieRz#JdjG?5(S2EwwUW(=pa`kDbd^V!N>qSv`A1hD3L}tUZ+Lli+=YF|olvq7wS!w9VE1DuX{*@j'
    'xiSJ?H|Z|56q3!@dLVkcO?+_03Df5_)^m*G@U6wyRSmj;JZ)2MO!=w7L^(S%)SADl1V|ctS0u#XJIa)qzw7#(lTyas8d9QSZryDdU#Roe^6sc>vo6G_<gZf@'
    'C}^QJ;JV*!sYSc?R}8=Qa8JzZ;uH+}d#iZyW{_%;2GE|8K7~vwma?~9&8vB<EE(;U6?{+5SXho4ty7yC-pWJS+{0()yy=B0M1Z2EI0o!J@#2=^mVAY*jMtW1'
    'lb;ORwc&Dpw=ik|D`+iSuLmiCQl03SJirf?VG8rHOPDSri%AU#6hM3=aj-VPm_`?)7x@IO0kAPDN-$$ZSR)P_)V*V>KW%SVJJnw>e;>~Ttp#EC=7Q=8{k_SP'
    'S0gvfyr}}&z`(XJ2qUcmNb(%_;^#_<mm|F9&w;W-6{EZcR>H-5wJK%fQ40TKpB4mFsrPO`{*BJE*&w=^;bjiQp6_%J01cFaKz%}O(diJOI?pB)X@#wT*o@BX'
    '1CASwsReQ0_)-Uur$7IaeyU;?D7f6wX^+kX2x9o?eU{BL^Jvh!ox`u%!z5}p@n#k45Fs<5VF+E1rngkD$Z$~i)5CYwmcpkzetvN927a>lNR=|<!cT<9{7l~+'
    'zdf=)lMEKtm*$E381qrc*H3Xi<lCJ_Lw~i4e@pr8Mnjr9ICutyS&P|fHZ;0rYpbCFF5y!L;}Xg>6p(1^p{mIWq5Z@7xge0e__7T9=lloeH=w@+@t*!ZnM~v_'
    '?dy_MG3hP+G06G|?lkZ`V8+=EN7mLn>)Iy@H)4Pj@%Uqm6GmdLwmyAMs)WrhfA&Th|AkF<vDaQx3%ET|79EZUj4G7$Pv5InaigR*h^YoUlmq$xeOgm^s`?#~'
    '>Y4+SYTgMuHXNOk<)4#(*~qJj4~Oa_oBAoijQ<Y~0#UeVW3V^>>3b$^;|ZUESSPxn>}dD{`|>!|B|$Ew{AB1_r@S3#*ZIxhGq(|Q)VLY^t*hW(`IYd-_4~?)'
    ')ASYQ*{g?gO5+GftP1uoRJA$zOM2*}4Az_Fba+zJB4sZ*Nt;PC7!C@B@byX3+c<GauT>kW4ejtNkvXl<b2lV3&rWFkzaq~dlxk8p{#<!Unahz1d6Lj46;ab#'
    '8bB-oHm$-i;zacfPU`2xk;aNHwrOuZS6b5fS<2um9L^(=5%C^HXEZh&duPKLOaac0&cj}%XA*6RzWvY<<@1a=z~`yLfAz4!blP^p3v&`%6vOe0BsvLrI8CPM'
    '#K|8*)(QtIPb2BId;wv8wgCft_&s`886PapbinRd3c7H@;rVg=Jx`V8Jf&XQqO|ISNipVk1t)hS)y;h`7m%rOx6vr9QYkr?)LAR+>qfJ<a=hAB=q(mAbv8?S'
    '`|`=_XH}`91_c|*7XAzF*hbvOsozR?@@eB>oMk6e6^DLtH9{(A6UMwheQzLK-8u*N7=nP#&6Ck6o8_W1?OQ1vnF%{RRbHNZm^QdDNHb4aD9iAka>R7$#h#D{'
    '$Hj8b@{?5W_$1j5l!-n&7G58AiHj0gpOdmRgxTkuK??kKgTVL3be8EC5Cv#Fo26rz1!cQwZtAqf$UM;WRp&YtkBP~xP0w!U!#<*rp!YP&kJ9XW!U%BSH5m8U'
    'iT`opNEVZHig<)o_v|kw$~%|qZ1I2Ei%G|JvsCALF~Q?dhnm=3+5wq+KUt9DCA_^{07*<tUGbjzyPiTprxWn|aU-u2NwKEW+2jJMT1;Yvbt9}5=dDV;hf0x;'
    'e)vu^D#5E_d)vD1&Nr!f3jI@1JBCB+Y?v<lQ>@)wRlou><~c|S2ep#R7At*K5WKoUQ#-H5x6#(7-X-<v1QrOy<CFPfxVRz#?&LO7`<6F)RO8cqmf<tQpTQY!'
    'v!sD~)BP0w+)wR?%}yxtG?@NHr+o1sSbdVNyk3NW)3fHjp_Tg<=hypqS#?1tt=(*RWumBtR}Na_VV_&RAMkmKU$u(O=Zo2}Hxgg-kG?kjV}j2`hyIashUawX'
    'zUhZf8C6^C5@4f5NE?LP0NrgZ5W;pb3Fj@gxHsNB3AGgOTeFF3Id)AgN@Hmxb}a~z$8hm9`Nu)2&_D6vYSG#t*=YgkAhOWXOPwep(hAU+kWI(xAIp0k>yq7@'
    '*z@ykw7nVKOkg=?DxN%2IpU%k#}Y?BM3l}B{%f)=@`Q`TC@Is#_CdAH)3$wj3nJp}BEg7wE7;o&7*D=;qQs>*`@MfUcW3GxCyJHy){&A+0ad*zsi^lR{r=UI'
    'Vh)VP+JLU$xLg~vj8u@0G%$(}ZiE*HeT-2FgfXT!FFxk|8}hOrU#Hf!EI=VH9E<f{j@c*6JYI~)Lf0<iu<W7Sox)kYg&CNp*rg!nD}m*jg~NjA+Rxd$@hgX7'
    '`S%nGcT$Q&58&2p(yd8PNpUa4k!w~_@p&*BT;xqH{bT4MRM?`&ZG6<B=z)UMsDNgO5Y?FPs5cY-L!`^#tGHEIAx0&`N>HDADkQmQO-9kTWM(;?UEsaVLH|TZ'
    '{mWX%G6#toe4nN`ZkCy8HaJVUo+zRfJWXMeCMyGUA;&(b{&muR9jBG&nHUuOX%QPzDFLm)$DVhZ;kSvD+{Z4;JFChHs9n)0ne+t*M3DkQspOP8u3(yB62CFi'
    'tQzB)Z3GhvmSGn;tW<f%LENsU0?s-pdJsIiiZNBxD_(htS>Xm^1pJqtt18I!g->H=c}Y=77hU1%nhT;TLB>9hnB!oD;HYnvGSzOG^p0+juO+~7y2q-S5X0fi'
    '2y=5qw!i!aT4DXv^rvZP5(87uq2NYFFjZNZAC0afE>3V+l(T&{8Kg$N-Npvms-K;XUTjpUcG_54O9T8&XFx<@fLgNWUMYoP`srPPp_F!u%a!Y^+Q+I=_hzG$'
    's6TZI)^DSoO`Tj-0=p#73i9j{af@N6l9(j>2ow`N0ttf|g9U(b86!#@`s_vH>?U&J3Ynkh6<{TIg0_U%<KSsNBonMhmSxroh%$de0v`YAN`^Ae{yK*i$!4nT'
    'gxd5t9GGXN+VmnEm*v@9k`V%Xl($k#Q^kGZ2*+h}QCImka}Ch<#nms*w7JgsbO<BO)#D=XVti}ZX%6JuD_*}k7qCtg?>ab7{3hgF%dzZQ!Nj3wD7vA|Zq3NR'
    'KkgJ5Xepw;98dob8|(wCUI*%fEJvbkFjcYcD|L-dISdH?*292MMsQzo=LHXn0*?)nD_C;P0tXSpbD287jsCIoV}vjV!xL6WkX2_g7@iLM9ES<F75bLfnm<Oz'
    '&>&}5*=lS(z%~9Bp4|d<`nA^^N55Q+(LwsW_x?RxFCfYN(4P#lALdx%916V0_dnq4*{~0r>uQ$Ow;paa>hnHGmQ)*}9biD>>1cAp#FT<j5*5A31Vcw(sSv{-'
    '#FHW6OV%?lGX@)_{`BF1Td?JN<M}BjjKSQK|JZrJuHf5=cyyx|w#u<Z{UmopXfwh3q>SkP>WuV+iLoYEvp!~nxtgP+W;VMZgyQj}KAHY-0VBLX*YZ<TDNcKf'
    'vw6aUCtWBd@y6Svt`Pu52iemrH0||a9-)kz&{Ue`CF5|r5&VTAnF~1RQSW3zNmMh9UAn3BtZr}bP>d0lfL@Of)QeP6di3UQLuga<gAt5Xtp-K>g#)Naz!E;)'
    'J@MpcRg;|}Q9(*J67DDdWhXhL4}N-be30hol_q2vmO(Vvo}g`od_7kI7xb0r`^}vl75**Oxc#jl@Kg34SAU+iJA1>_b=KUszRsf)OD>yXN8cp+iGQP*7b41-'
    'W$`^Z)8R%l=*ek!M$1Z4@rPU=J{0xgL#PiQLiqe2>O&0ER}*Bpc;-DkQ{TUHsB2VMZc<G!?0z}OAZ#%>AqZ|nd(Sgs#Ct&U1Mn82Rov4X)M#*kl+PAPM)$kv'
    'oEe4SZK74=)8{=RZ8_*&tBp3**Mj<dj(<w}(mbQ21P{|ti&|0hJdO9vtM=4Mg5q`%UT&m5UuO!R!#$Df`c(UsdfmMw-pr{yF?H)@&{%6Zz7-?FTG*x!?J!L)'
    'JJv!%#r5>kN$helUEE4M22(bqjoHU3P|e|DbQ{gjhh*qE;h5m*kP^sqXfQgu!hOAISNLm&05>0j;3GL!At3{z##dvZUwhGjEjiOG5HWuG?T;VO{)dxvgYo?K'
    'bxq<fZj=<qx8Xz#u(tq=w@y2uj;9k#IW|TNOf<E8ljir1>{Q?c^EKfnx5}ngRTlWjO)Av}Pnt!=L5SuV5Nr$QmGlE&$)C$mEXL$$ZPWF2fanYf4>|I|Hp^!K'
    'JvUU0d);z|aIQ~`Vte(4v=Zm5ctZb*S`kpfVgsFtwK&1O00T%@|86VF=q#LE-J&m?bLsP`z@$N#*m{z1I@0mPGJlc)EVutICEa@Q`pL`g)5BM9o;-b<Iz##k'
    'UBwFPb~Gx>N$3$??b#F_Y#x5-9xj{g^fc=ezOaqdQ{YhoJUZO~drVn#-XBH8Rm1YcPUOB2Pfl~Y?A!XK?JJ>r9md@0a4aur*tL~De68x5h-LC`SDSg#B|ZL0'
    'KgZZDTw?nHGAIi8%3@N6VSAd#G1=UbY2A4Hnub1fa97&D^PExau||pyAbZ89&jEJ88c6FyCk($oDYhF-tihvh-eC#wC80F6CzRF0=Lpn`jdbFmCo%`%LoD$g'
    '@}erSxsDCJbVK7PyzqcYw6D57eSbMG_B4a|m%5^MyX#@4S{K5S4+T2V;Pl+n|FF92W>Y+_#}kl3;dJ&Gx8he4^{aD`$a~1@EPCe|XTTtD8Rc26K>jW!7y^kk'
    'j(Zo`9O!<wiBKpfXwVog&>+%_PC<G;i~dE!{TE2I%y^N!3#=D@2qbUOKa+-_^a5*?gsRt%;K?XspBz#KOfW2PI3Rq|Tj(m)K<*V0dJ1Oqc=O(;tox5<vwQIR'
    '?a?1!1Zh-^uNy7jG`b7rQ4aWjdGCFVeW`0nA{+V=y{_atEWH%V@?JONcJz;}=A+|ZU%Vms91PT(U%h`18v)fL-!|hG6^O`p4tCUH0vl$6I_n$B+%o9hM(Fc^'
    '_2J*mM+tB~3n>X7Ns^8T>ZA7$Ihi7JMVYby%re@n$p4T_g;Y0>wsz}V4`FLd(uc)aZ;@~!7*v-~Rp%fn&<?%;_5+AFtFC(7GFCLdnq9;5Ic1g@NT=bR1u}!9'
    ';sA-82|)&6TFK!x7t@`Jp#z6>@UXf*LUE2sprJkr7svBquoz^nZhCW_xaJlnHk-jWSWV4pu4~eArD@cN6XXeLmWOki{DGJbPbPy~u1-cwzO{Q;A5P;KRa59}'
    'JLj+Ml7t<0{|EFR&Fz15aR(uo<uQh#;}#&e&+VAbFTD5g!nz_15=>ZEWwD|kwi1dym9(?}`?mu^HS1o(e(Xw`Aakyr$9Cj#!n)%`5<jS;?W)IdKbT;!3i7^{'
    'P8|L4L$tNyus&E2Xpc8$Z5bv0t)jO;CH7xQ2RUaAy#6M|D*a^Py&1teU{}aBv|^mjE3C7xbmER5xh>}{2Y-aQ+=9R$<iC}$dxX_Tb}yS(C>AZ`goZp?O1*4X'
    '$nm5SOaWA2g^dDc*a{~3sbJJmRAKdIr3e^G4Ks|$Vo5Pp<)L#{LC73hfHK$_nY#e^4msCJUucn`WUI(g%v*PiYa}9&^YpR~OS__vNu>yYCcuFO`qx_CkQ_m$'
    'q0%rn_j5k9l|YPJ{tTBLPCn244WmROQ~;+EyweSy*G!nxow`eJv=Y|f{7k9#xX(N0tU03%K=H50E7<iH@dOomT+uv1dVl{Tv(E1?j-%#gvlYF=+zu~$?;}C-'
    '!^~}T#npg|-r4Tn!23}T9Z&DM6Cf!-_3vJKw+2G@5DGu5;cn?q*Ji<=kwsCEd-Ow89huE!l|6Wam)1k;*&#itc@8Xu9HYHqY*7ThLI(zR{ZKjABW-oyy^X6I'
    '%4d{Mm>_bdd`2F$`%#1ccpUxMe5hlKwcj-6GJ*yu<I#cwjNNoctn%TMM~RNW$@fVzC((a8?M27g-0iY#NYVGTqD)BkJjtF3L4y=TWbZAD<HkWaD{tfTsKrqE'
    'BBDC*CDk6u`0(q~=g%%|H^#(cytU+`pueSb$HIa#MF`nTS))}Y-vQge<RxDL>9%Q(#CTX|_Acx7&+t;%19|Vgn9%#ZF<D=jeI@3DurGVFTN6SeoPwXbX3zNA'
    'qTm!x(iB-)nj$Yv(;i28sGDBJd2qwD)ivD3ve-0ih)bUNF6CzolPS)w>H{LiXE}^>Z)>U8IXrvg2||n%9!6Xi*e&#C%0Ql_Wf2Zg0hdd1JckQV;Vh&Fig<x>'
    ';pPtF>*Ay3Yh?C8$km9@UE$!O)`hx5qtuVAG>y)dq8s6yVI$)ZEFR`9NY#)QA936EW(zMGh6<&Kct=h1%|_kEFW}fwBsrZoGaJZH?nNH0M#T=%=Bm%Kkb@rq'
    '&|quupJucXxn$V4z41EfHN$SvG%+fUe(voZw-SFq{DHd%@tN9&<Pm@kJ9U21xDha?aLugP7DjX?54Ri2u_duACs)JK;0F?BBfbNpnh<OPz(eAU;^rA?0YTz?'
    '_Tm@I+x^^vnjMa7W`iZ(&PvR*!fA@*5cse?ju6-i?UjXEHK+!rKIc4dCk5pX?Aezp%%1|_W?#>7sBIEuQbYEj={+T^SpM;)-6@n%#L<^Pmfm6LW3UU#wG%fS'
    'NEYoXECo)KwF~8$zoTqdCo{$T$tO9qEjq_=f9Vt1;!Vx-6n_qEOWrWfu2guC+<p-EC7^|kn6R_cC;{6MHJ0DaRwuqE2HnR1DdyANv9@x9w;6O%PTOokf0XrR'
    '%E`=tfY=P<`lu!hXOBoe>mu++*EG~?2Yt##;g1l8Kk{(+BLw1)d?fyep!lO=EdHnjjNh6KpKH4VBuZ{eE(JshibifV|Lgx@-?*+4k}N6l>&Qe~C=(rJy}@n$'
    'n83)6(TVHH;2H=Asv`g2=;s*_1XSPS&sw)PxaQ2|Nko62s@GpZVtVo{FEG=?mxqVH!lP~Z`Sa1?tB4?U<iXoR_z5zFs^jSJ?ZMNxnkcD{s9u!;0H6KD_1ce)'
    'fBWg}(UYfdyUz}OdVB0v!8t_;B-+XKqf-2k*IJ|#0_hY$%IVEX0)!R1q9IPN&O3lVRKhm;p=87)q9srzjR;4pL&;qKi=;QDawrwx99usr^pw5d8ai##`x42*'
    'lF-(+ik36ma9{Y+{YZ9V@GAPE`484O$WBOhk;%2B#VQ6Wu=6q7Wt^9@?FU`@R@rQncfR075^_=wb#HQdYG;Cu%&FXPF}oLvPv5|A+-P;Ra{^h&$!=Y`gMIt8'
    'POO8ln%hN?c^HUB1Jd~5YJ8J`-P?wrbmN`%=?`g=5#|4qu=6ycqwfG$jP!pQM*7FF;5<3P;`Nl*o&&uS4R^rk|Bbi+Af3?MaGkXi<w9i)xKurz&L)zMCFOad'
    ';Y&{xQN?-DbE=U1%u{y~>HM3mr1lxM&ET<@?9*X>6Hp-*Q|X+(Nlm}pjMP{xcs4XX>s_;rVd$jF3IQUX1AgjYlH@#rqF`dzQhd-5hRs~^<+;G!g@7@^3>HO5'
    't+ZdI0e03PI86HO>?AnDOSW`=I|maVbB<_SkEQrO(f4J#64^yVk|<$r`nW-JsmDzcYrT4XH6ao&{Mk;0rgTpM$fHQXk2m%t?2D=7$z;M^D9MxdX}Dll72Mki'
    'd#vD={hUN@=Cmk~IxTACL|0Y43?CZ|WHuvVgMfwuY7`8TmHRG_;v7eHXB(*Ju9AhS*hei(zW%cz9y+w%)@qaDsIH=YYDg|T!q#I)y&yfnM(iXMwom#-Wb&(F'
    'E6rej5HGokrau<-34~!TkP^`vp!mbnP?CTIJzwxnKu_j`%g1Wp*d$oc&Y^T1BVO%BN<a3bi8}vu#r>lBH?yM=R`CI*Sl~tHA2?5AU$+xXg{Q&HttH?S0p0Xm'
    'Ch>9b{5$lWrUmJ+oFH|(5GSr2|7@Ffq^>)QiQ!vsFB<5)6azmYg_$&q(Qa2Yi)}Dp{nwI94`0)miggL%(#3RPLtOzbKdz*uQW){|t|{VG3IWCyU9eeQ#hfC;'
    '8eAgGXpZ!BqUdSCxh=a3)jfqHCM^6fApqiji2YKS)5Aewt+m2x-7E=+Yp`k$r1jW<`V@~!!!YsSsSfoB`rXlvtjJeUkqsKphB&JkuSD#LT<}38V|%k&Vjx*%'
    'te0}ZS_M>|mZiJdc2K+{oURe$*VR0&uSfG{MP-V+t0?_HR|V#X$OZZ@?{nJ7Mt9=Z=Fqm18iP30#ZkO|UvgrGf|^DHN0(cJvt3k*whk>wQDAV(4|;DqRd;lr'
    'hviB_|1McYNr(rnf7aV-bjhQ(dl%o%W#7<=&Nbp{CQaXSTFKm(UsFT*U~}t9D|)LUWPhyVHjn<9%_jACJy^2n<?!+f-FI;-*4}pC9vr>maEq4*PmaEVR`TtG'
    'ttWZ4Bt3QYcNo>%rHtuFTIiRM9m5nX9&GjQ3R7-%<WB@D|FOw1IMNRfQbye#oU+q5eGac#wsIR(XpoiyO84`Oq$(^Sox^ySKtWq_b8FXXLX86{(p;dHZ=;_H'
    'I%kBD*yH-YVUr15<76_J=hIXn2rR8IvH~LBX}N(AB*ZALZn8^)(GRDg=KBn#lmKdw-B>{9^lfyEfZ`{&lIU%a&HKvbIH&%x>)J%&w6>!B8EW?@wBst?N76FP'
    '7w|1bM~d2Fah3rmADBd!?JY{PM2wTu?RKl#=oEN3a(w~Oh4mJ=EU;FcxG4LkeU#f(b8MMxJ5>bIG4=T_v2s1waF0vcA!1Qo(OuEN7=M*JWHr*X%1vU8bG57F'
    '-Y=3jFWww9A4Jb@PiDixA?ynRCBPFypbpdt%)~p$Qm4#UxIM5d-B*Xt&~2}J(3_2JpWgOISyjC{dh(8#OdEAHXbov}+O0<qa1Zi_PxZa?6fVIhKfOHAuN>Dw'
    'Zbe;GpA206bU4krM96`W#ko)$f;}}ORju()N((w>N>CS5Z!~J0a(q<19NDM_V+<d(ENN9?SX7lH<QH&O&Q@|#M_{@P0xNp~`H$m`cH5vpCn`;AQ@Lb$i7|D*'
    '?V!7STT-Xa+N!GE?IfkG>Dro3ZI-~9d#imv^0BH6B<FU72xDyF3rQbhjdBHY2w#H3!6+lw2$1-1dZY6>MaM+7-DD@ms4R@qU`tI@+rno+obcDCjc$-l6NTOh'
    'z4^4&YFFPOCR!)iHh=DzKX>8JH!q*OHj~y#9^h-(%}3SF=Rn#(jMsuwO*4ZHcC_ms4KVLbRZvp;spjF3qkJfrF?rfYcuun30HeytlSyU!gz2x}W{dhb%TO)m'
    'PJ`XMtw&aiThuq#GuJ*veqlWa_CjH-k6EWii+h?V_|t@x3m9!AodPB;!@wd1P@vT1xMO7nf`4$!@R!20<Bja}9iALKkyrYUXGe!`Gze;FOZ<B{m9$zrkCNSo'
    'v3fUOafur%FL5Kk#IN4*jesG!8EPY=tsi%`ljzyS5ZIYv^vme#--F3@jG5YKqZ7nihM8P?aL?VGWj(x3v@0d60b$!v9>%dop<SHKvdrE;xNbNBvKkmWM!fc;'
    '=B7j9_y}89M&gk?A03Wr(N@~sZJbiy_7k3){3K2;Zg5}Z7xkXD!}2Zha3^`R6(`V<T&knhb_6O-aFwxKbTOP$kf@&R?*`TAJNBquX^NcfV=ke$6rJ*dSNHJr'
    '>Ex#LCNf;AbrUEkq^8Ya_9r(fSyGl=0F!o0krNHpoe+emqqXNbgIbCBZ0)H(n>JbrW+rCaZofC14G{!oF$8I6ax>=O+LOuE`!lL$kA6?!Ux?9sgBbWgp6$v`'
    'GMF<7SClA1a{o*SEh<9SYr%MC-;q&vx)A$IKidowfGulLb~<Y0V$_pShrir*zAPla{%1Sk1_>@U*IuBDMf7QVrBXY&QgS`YmhsE)`sJN#L&k+RU1S(~uDsk<'
    'NQ^zb)rjBRPn!*wXC(g;B6mvsC&SCw@`fBEJYr#{(*T}Bz}}G<i!ZjA=In|pp<o_OQI^So4RqqfvLvE*1BH0oP)1VbR%atsYQB-GmvK7xn+--nm<O>dw26$E'
    '#?_orMdPl4KozsDbxlEG$*jX#QXV1`CIxyROZ%Ec<@kvl(g8xA5j1@K#3JlOc9mij6Anx<yO-`eRVzwMmQpn@r+A2pZg&`iQ5=p<v<!X-f8&2F_T83_TvyuM'
    'Td^!45FYt(O!yW~vBtzO23-sS?Gk=_BllQ%0*VqYO_?mL+n_7Fo32op26#gUuuE(RwL}zFl`E}WiW0l1f{o`^9n#CtD^iU31(pv70kFn%*iCj|w5!~-cK*7`'
    'P1!uMw`ieV|9C3!4ana{rYwq8Hrw7!XQQzgy;3@}ji<*PE;2vn2&ws2Ue(7(5)&B*R7TbYM3qr)k5!dr-%`n9+qU;V{$|38pDFKumi!8Pv%9lycl6%YebS&s'
    'b{ZcPx41VV0O#SQ?QZNY?MCpZtT!)KRD@y&3c7?W`R<Pi@ahHt(TzAGg>D%0*N$E@oF%ne+exCG*wVAx?oX5$z7va~S~1cE+R*VAPJTY0Xu+Ky={m+midAQw'
    'f|QHaDIfFACmNQcoV|7lTIjs(ERW`=Z=GlvdXhUa!gA$`2r>wU#8-pn>4MW^=rv730Sv&JA&QjunTqyf;}{p*QaS7et!G{uaY?Q4o2ix9I+Xh)hxf1WLC_Uy'
    'RI?{iUP+!k^oC+AdXfuxQ`^NIp!(u{Y*MA*z}!?RRy<<y^@Tv0@ZmT5kg5vZK*v_;1sD}4;mJi^aYht8?czdGtNu)aA_Wpq2=~*&moE>VzU}^eaP;=Y%NPFy'
    '9v_}6fgFz}@%>4}`{G_YM+swiiI!An4})UGL<-rnRzHv9vC?sId6sIY1VBSG@zySSTndvB?7P--+@ZHVBek@@g*6rMU0k6VV0q2XacY#!+B{o#nnF>lxvON|'
    'NW44@2|H3d_ZuT3GEGpLlrTA%_o3+3i1r`mA<$mU<zlGvxyyTwwYKC&7L%hE%L@&KrT3}sy?9;oaO<Yu@d|Nj&hGK~Zf65JvY3Ma@OA8qE6J>@*cYuKuIj4t'
    'RjiD!UK|}A9@SsI`1K%q`VtPni=ST{97VO0?5uY^#4R-*-R>a<)-3Czl#gCXv#fV9{|a`-SH3q&e}q=L(;-7rT?}ypbVtMUjDFJI?hb&x@$pBXB4s~R(4&(X'
    'EvQ=y1<lC^FJ8ZfffvsH7j2()Tvsf~!6x*2OiGAfHYWQ+SNy-@ta_cZ1q4@?b-GL9<z%LX8AtLo(F%&gzr`P7II}@li>ZY>#$ZsZ)$6U&UQ<``c;<Sa2Og)Q'
    'w)QRH2+|`j8!lS^g5d{d)mk>1TWSmCw%zb&8VOV{ei6%Vm-buXoYJbLc*)0RE9oxY*ODrNtPbvSjHlrRnacW@m88$IL2n*)FM3_;(NenY7T<h&)*Fsr^`<q`'
    '-Nbatd>XGp<ncR&uleWrn9xo`u=e`TFOH7iMz!}q9|my?!@N$13xYYF_J*@LIeX(O)Nw0BDu>7YUjgra+V<{%Sw_lbBv!E$C?VDK{>>8@4Qfwom7k7&d;Roz'
    '_xR1>+e#8SKhYz(^3#)F503r_zIyZGpZ|p8_WbY-zCM0+c=-1DivxZTf4+xX!LU<$P;2`{Qg+=`)H1otrGgoyE95k2XO*tFS*00Y5II5XK=X1d8Q0uC^u0wE'
    'DmItOfQ1-cE}yH+H6*l}wc#)Z{o?NH^x5_I<n}#EvSNrzh09gEK)qnL5(*;;5PXS2Subv+VtKe!ocOT{ozF^G|3htA8A%#W#7Tkdvsws<6|$0}@8*CamZBWZ'
    'N|{g?7M;X!M5EvslK4x!2Mg)@&B-=V?4^`l6|`u&8Eayl(RHaheppJ@zY=Tz^UK3`Z+=H$n(Hh=Npn=E3{<16H>i{Cum(NIX1$Ti-|GZTz%2HV%g4%&@Ovw9'
    '!i*sZ6<ivv2Dw*FuTDn8zTQ=euR){FqBl<zaxW65XfW&D@P@ydQOd#j)rmm%l2<8^2*kDS&4!CJm~f~TBQP+L6X5{ALl+gPkH$wJOea}3RybfN4UZ+@5#3ZY'
    'i1%rBLw)8GgpaXMbsk+_O%_z)9CeoH9W#>zQ}`Q1-61&#_n<adzeFYKll~H3H+)1b(sU>&U>Y+wh~7+BBNX8!ISOM%EzX9FAO&>4r}DFqBR9*?s-w~(Rw(IZ'
    'ZV_+1H$-%BoJf$)M#F!@ce5U+?99f4_c)J~>uT0RpL3P#sy8M8WVPh=`84ZemNZ)X&HKOJfBxM7kW?5_1Zlb;&EhqyK}qlzp^xAn2fzG6zhAuk75|H1C5XF;'
    '_2D+}zI*W+p(Bms2F-O#wgtk@4vA3djd6-}SbzQsK9?Mv&a*Un^yrbPloi?Y$w=qU;ray${$@BH!1=<poDJW<N4F?CY+UKfgD20r&ynTcioAZ}zHv8_yFs{u'
    '|NYzH+XES?s>7;)c5Vclh>jZttP+~{h`=@KD7BB@FW{(BxE@vrBP6&t9OeVvBgF8IdN%?lPL<62v*DDG!`WWUpF1A9@Y`kEPCs@}5vrUb)IOTnHTat*O<RNE'
    'fhA;W?*ROU#Z`wTGSGmEi>g#Af`=-r!9+?;0ER&gCs%y5_@rTU6jH)!XA?eFQS=0HClOZ_{8@?1gm;Zz>%uu;HI(EuyH+Jo?XHjvTYlO?`FiXHnY0x*(rH&T'
    '4ONT)kxj(ke$+)W+Qr{BX_5H3PU3VR&WHEwgXjh>@>d*1QR%qx$os&z_!(JqI(Ir7I9Jya)?Al5twG3}4H}2rhANF*Yo|DXpIXW5!C_r1xUSGd%^p9;ZO5b^'
    'gfBfgQ}0~(*xs8JPlJH$n`r?#z}@Cn2n|i36RfhpTJJvS6!zAGA+(P`VYH)t0#@3fN>X4R*e*sg0_-zSDCop_e2LKZRJ%pvu~vu@Arv`zAR>hrwsN6E963aL'
    '(%F!oa}%zr!zq9CV9AW@!tK`1!_btg0s-ttjXWDU)KR(qU>sSa(JD+lsvvJlM5XeNzf4f^1(Y;;_2l>N;nA~$qvP^+d!reGsjVA4kKL-E)qtcjONNO*uZ<a_'
    'HkJ}5SHPOeZFh~wUxfc<VR%)@T@$8IB}fVcg_KVkdE^$LHgiL5X+)Wk@oJ_k#%w|*%=9xA!A<sRzPzws^o`n=^~hxdfFdKL8J#j&NkMwC@Nrk5`s%gX2X2zF'
    '!krYp0Z7DP+tejBP5>dXiZ3)oPXZx=G9z|M0jNkMv>w0a_pIT&*8_E7-{J0-cKgzp<Z@6nPUV-YU4(Fp&|2aGD)cvf&FSTJR-TYg0;S=ib6vrxZk&}%96n4m'
    'K8T|qXw~TNrQK89W*$VwINu8dS~H0hS}pGRI8oSW7E_A=YJQ`Jc99?MqT^_wTpCuEUp$~NA)=E*+9^<ZsG)9@f}33~ZUyP409Z(idfs+`@AmWlGWi*o2+!dd'
    '{g<&9ZACi;G;DEetKU4fgjngEmc=VXJT@1C+I+Md+h4)KyD24eoH5;1-o*AR!wTrI(RRzwi%voQbp-kUNB8;RZ%3S{W;cnN58$64;h%>I<u2OdR097Xq3I$2'
    'Y0Df2&;EKfJ_(rpgKH9C>LRN3&#uOZ;G<O{Elyv0HAN}ztT#GUDYz(|4|j&aNDLU9BmM*5c`>}Y;K*Mk*k@7yYBoca3e5uN*2BjvvkgVjAT+#C+hC-XRYj6}'
    'U}tI?J<?p3YUTd#VrSN6g#TuK^30Fc8!Q=xK|WBtl7)Q0x8{F6r}Up>IsW^Y4I;h&{d~sIX!=%S8&=>;ur-*s+IIB4=|r?mNz-=XKc8KJ>sYZXsr7=_L%(#v'
    'yaIJ7ZYEd<zmz)u8<-s!LU~Bk7uu429B9`JEOgZ(EhQdF%tbh5bClZ$dN%09ZlsiANm@RXma0u9$-&#2%W|v}ONp2l2>zBUKz@;KwndG7&ZGT=u+_}|5tZ^C'
    'mD5UxBzj%j-Ox45ub{nN?gi;G_kqN2#(zNXu66wf&<2#QplQ5^-kRndP9oHuFhdV7@2f99u+*JdHR|-u*upq=uO#Smkjc$svrdYx9_w}r+&s{@#y^I?*T6o;'
    'jZ8<$IeVPf#8TI{m>4d%O~i%abBZ%AuS&7caHEm_zlGx|u9KD2t#$O-pYLfGJ2Pj1!G-L@l9xIpK)oyZBS<;R9YJ?4u}=KD-U#sF5@&>acSLyh<lSp@L>TmL'
    '#)Xo1R72#vt?1i_dy%*$Q0m>BH^Mzzq@TSpS_n8Pm@GGz$D($CKV8%2U}|m;_*>r|@OQ|P36G0GD_eIG=pQ|}4>4X1{ckb;Z!!LFG5&8c{?8EOiLU-F#{X5t'
    'czxHkE9#cZTOHg&U&rcDi0vJax>d4j=+{@3vDcBAi=ue++$m9XHD<yU_w+#5757xsL@7(MoJ)2$KmnJ$x{EH<u@Xlt<t&a^cO<bUWnGRKK3u{PcVAgdViUPU'
    'IH=7n_-8wox56vF@_EGzYk4oM<-G{=iWh%XUh&o6yyD-y;@`aD-@M|V$Sc13n^*iR^NOzw7jRL?E4qdLI=tem{{mj|mCq}##!R@p;;S#^6)(PwS9CYP7xRi2'
    'EAomLIbQLV#VfwLE3f$K&7ZD41-|6ji#II{%BwHVvie{+B?36YSVw{Ir6{`EpQ$$e=^0&?kq%PiXB;&1kbkI975???;K{R>FJ7bf)&qX>^a+NZJlNr1PB;nt'
    'cKPTNV5X*{A;AQ~-&0N$VU7Sio551{<_u~8KSS&_Jic%CdTYmKuOB>WsPwukBp3-$vm!gL#VFZESv7BVW;tbK{8Yi~zS4qA5Ur*>WAGEErviQJXUd3bJNiq@'
    '%ZxPkg{$_0OVPMCH%J2wC)6j6AzWj76BYLEE#>~tA0V5u^U%A)2HD7}v)$TKP-%CUL#*X(>pAOq<4|lDAH>=m1`sRnX6}p4mdZ&$d$`Mxaym;)kXj3JS+Qou'
    'D5)S#l9g5PDid#VUd&D)eH3-TF7lZ7j5>>6@Q<t*eat*6_8Pkg!-V#HJ`BSxQzy~v>aoq5g81oYOT(`Bqb7F`2MWyx7&F5@IZK#C596XdE*cHj>24C4o$c{H'
    'jwMiUlDfy$=sQqTvv$RzQvp6GxcBzMaD4W%Dl=rk?%j`s-2T<}aB)K5WqkVbeWmghF*=rP{Cp^YEtXNypuFIo4fP8KULYBqaU2|FPQ|#tM6H0FM{8SNBGbNA'
    'fc%FtTR7OwaRT7%sMyk3F2JpLzryY-FD@I&qAvwNH^uwXc*q3N1l*HBH+*Foz?}Dy!wUGLS}GhUdElpKUsoO|$O>u60y*|y4^y%KU&I61)iTTAKt&sYLC?fp'
    '1%^^4Yq`MSuI?8L3{b~P0)v#Z1P0xa#F~_K1qS%=&lVUEdi*8&TOb1MsD6U`f&45eN&%Qlq`DYM|APs(*TTcsKy`a#2mPxMemBrx2lQiMrD|tT8&(#fwtZ_m'
    'Rz-Xz`$t<a{%A|ajsqW8|Kj+qA3}oVFdUh`6jcjFmbFxF6oXjN?+r4bZ!L+b&8{=pLOWC(u2Iyr!6ft3tsN(1yWvU?-@#Yjsi%T@<T6yoFDa@>9X$00cHbgT'
    'bH|f;9x$9w$ZGKWDrSR~g&xh<2gMT|OW$SOHDT_E&KgHGK|=Br{B~Ipa-4!nnXNWZP~cLM)VBhrqTnZZzc~0PJ}`=dLV%6saR_i=V+yWR@zgTZa6q*_cAqVo'
    '460`a#)2nEgYX1_ihSvd1O2g2?V%Itk1_rj;Ga8IiEb$v>+c5ot7*5VdPq=JieDF{>mUvb4W#WJlIZ9}>f7R@lxepfSXPU2$H+=c4O@FEe){~`v62|4K*7M1'
    'G#_^~jCpLb)Yi(0%d2R#%U0ALyDW@$E)Bf%olQL!dWli4>!&`+rDo@@e_q)_<~ybTrL19JU>sa#xC$-jGRu|BK12O4w+-~Jd&7|s=zvASX_w2cWOA4aL0ict'
    '#)bFusR{D+GTpTZDFJ}+q4G*~E$NjWwCg*qj*?-mCnU*o#U#o$HX9*(*Ml;AQO0@6k?#C(d2;$!cqyKaCcQ<iJKO%TD{DtnC7(e>Ir4|p3FB3XJ|nuC9_WVd'
    'X}yf;@jD{5mG{IlfvFzEP6FN~h@bgo<VDA}_hmNfFzvg!d~oNP$lA2^w0TSomE`OE6+zz>C|AO0^3KsIHk4t-z8=BiTG0?v6ww_lYDu<O^>Uic06WDrTbq72'
    '0u_E$Tb#@tr9w8QxZnSBvbR|RV|!as#&GH&R<S_PHsij#Y3}0}+UDGib`RFMkE@#JKIZLnzuN}7-|uXp`||@Fj-S6cc=@c3qHQZWy#f~IR7LKOhZnuk4<lr2'
    '$Vi89>cj&LN9T2vA2EO62vdyTx7dCBN-`-D7yI<^9q_3;4K)57KR-Bl1HX3Z*Dr^M#|Q9hyV3Z}pS^tY`Wbt=VSz3BH+)F~G`z-P5(+NK^Dav6i>C+Or$+}*'
    'UKQcyauuSv6^(!b`SY;<Y^*;60cfBC4SXP5AmI;_OGLHgDhlQoz;$5;2|Bp*3v-C!?~uU|9xs)ig*@KP-siw_72x-lV)rUh!6nt>+ZsdeI_pKrN=eC&pMGsL'
    'D(py3uOFHMv|uln{R8>UDwN->BKghKgwpLr%N+=W<%}ENl;St~(JG#Q#d?CvtKNXtQ<7?VYlg39z45|dw|;MarWq{r-38oYw;bjSrF94@8y8fQ#YPlagvlz5'
    ')>@H=BwC~-P!{rHIgcp*8|T{PdeI~TBPwHs6}J{PgV5v&a}<3qlUOcJ*m#ASUCQ+$#~)EH9>)g7BzD<+Q4i~BWQejQI|FHrq1z=MWcg+>>+Y(JeiHiFiqLgg'
    'k<Atmc0*3_GH@v{mTqVW)>ibe@!9Hg^A3G>%yrAVom)nwX;`~qyw56LE1c;%mGfHnd2oBd@bfm6CzEIcWd{CyKiXzl5N}6OQ)EPb>R5rHgjwGAFF*+UFfl`9'
    'Hc3&`2}t_Z)oH_Gi{r*B8{ZM+S2~J89|2a>aAo;JX$GSGJm^CuAklYm?2mdAaU5$i)SS<=6y*<30b<WdzCxTKQ<+Bw)e89jyBqY28VKt`PG(u}-1XqKBu$(~'
    's{04=VIhCjyesbt8W!w=aYS%EFKua(nnPCu^!;?r>4xEHR}^z2UIyz*a$Z%!HMy9mgO8Z_kTMz%d7mbH5t;0CYMOO``+PC0;o*!ofmfO><_JVx!&6$p3&L6%'
    'U*oTQIiXclE%TPxP><nhtFy8{s3m;jiTaDlo_gkWy51GJR#&{#BfG0~S<3q^7cSim^u?kj)UlFeDdjA|Qg<Y=CS_f*5<Xl>s*HZ#X+<x|ob?Q-Y4#C@7M*1C'
    'MSYgdr!bg|Q+}gxSnEFh{TW+@veBfw^`N=SFY70h$$1>HASd$ylwh`)Oh!B#{f~q05c>r+be|s{7i?d8{qu|8|4(n%*4ws`h5riCeW2LTfuuTVB3A`=yN0TV'
    'q+O>479a#!mT8%=Bx-fBn;7};dv0^(P@?R(4{c0pIQKc{J9BR5B+tda4mtIrLJ;b2h9v3<`5oqtrH}vh=f4N%So=HVa9rQTZy#8fNsn5>dW^AG9379W4C#3W'
    '%Ycus)r%ahfvf^oyK6WR<6F#uY2Hf8A9(Rq+99>}C*cD0hF4N7yX6NhxnU)S8%PFpI5G2bi~nG}zBIZi{=#%OIy~TSvNROR?~)2#a^`?b`tVXdIbl918jPD_'
    'PQpINTi<LY9(=($4XBU_-ABAjXD3Cb&TIL4m9H1OEuFGWOS(xmkk|{y1%jibuvDh<uKNi-3ZuZIx;Uh&=sR@#BTwI#a&NKBmttjdi^_!g_J7b3RP^=vtNnFh'
    '$GizYR1M{NH1Ra_vP#+!q)WamuGvK(38HiVU$HCf?&pV91)iINw@jlJ{*toQ0+4kAhLt=k()?Aqo84}!sxhMzD;=2ZX~tp;Psb|Sa&>3ZnMmb73r<$pv}~j2'
    'h>p0EHMQ~MZe!OJwkeV`?wxv3)`53UNg1Apj>&dIQ+cRGnijuB8Kea7WMD{NHrNoW$$GNbP#FHx)6Zjm#4VY)`o71zo-M81i;n&-jqd3v9##h?iHeo{RT~1d'
    'rDm?usS&=Y$t>qpQ>CF<Zxp=mv38|0utw7&It~jew$SS@WEvA-la+YJ9~;B$S;0}RdERa)|LU0Ew^*O0(uSro$%$!#+tqg3ND|~zr1gOtEyU_K{3F$JBS#T?'
    'AuELjQkdt8DW_ED5LW!jsPK()KNlm~wmDl<HamR^|B)R@HS~oTZVsM5?t_b}pca1pb7V1bKPsAG-dTkahxAgOBm@nR1-d=|z8m2VWks6UR{_P{6|n?&a_OU#'
    'Cc)aJb~hP6PzUKxeU$Brs-~(T8ON`hv5P(SN)duHRDy<eLc8an;9+&mx?RTlo|rIB!M<a$eT_I`B_Rz4&@;23bBL<xLNP>5OrKDmUL^ICwXxKzfWE9j*M63f'
    'BLelhsDu^|A3Q;BsqDAf<dY4g7NP<ywy4E+#T8Y+l2=RzQnS#Gyi!5>i2hamP16Z0dF4$nI{)wQr=50m0}@7osiW4>Y=?QNTA1#*^Der~;b;E#Qi&zwbA0Ei'
    'SMG`xFEQr^qdzH^m7k!OK5im-o0gA1BvvCw=T!__L`tG*!V^KIMa)VIDsnyfEC%pofpFR=R;A8qV$W~SdCKlau3t5$r2>{}gI-QeE}&OZo8!d^F?YKlr7VwK'
    'b%du%nsSD4tzC;5v7!|tH=guD^i^qX$iEBKE|mBh#LJK87vqngvUoh5!@`XziFZ75Cz4b<v8Z;^$em=a&PkDLWGd(?ew?W(FvI58JYZZQ*mujBZ(4QO*vwWp'
    'F*R8cgp1e>oGujYxh0!Lh947J+WT(j{g~Sr!!Bv@pDFH`#F6DBTN&&k^s~Eo(-{vx{{H75Y{37C+Q7b;&<XKF2@GeAZNjUhB9cuP*DmtsRP{aVv!21E5}y)&'
    '()QT87@Ag|MO%zz-;a1|@c|bN%AnaG{o5W@GihQsDqD(>laZ*fE>WR!?mKwqF-|d|FgYu=Bv*18#jMtd6Xl?DPl@3b`Yoti1uO1Ms~53~fDlkC?Eq@2t8&x0'
    'CX&}<Du4?JwVZSk+)$Deu`eG3!$K<XD(V8o0OE+Wj*A4nj7S*4Vl)-3XOOMMZ$#u#8>7Y(=f2o5K>z?c=7(@#S6ChnzVIXFTxh9*5*1sbOoC$@;hpwdRJwFe'
    'DLBJqz3r>m4K;2{cMpmsd~WwmwItB<?PZJsKOSI>*4#`V=Lyw(dZN{j+Y);r@-&79UX~AIY`-5cRnu1rq#?!ebDOKl_EtJUyJwU}b)!vX{!-$HyvTj}e;R%N'
    '{oO;7wQF*tF7t<P+9(neX;^kqa;OWk$;4%hW#u`YHRxP$&*2v}`-o`+-OSK|)qKRJoW@M7;-_WvteCKYpr|wNH#rkAkp`7k6qh?@^bizBTuwqa)wH$7yt{#)'
    'IJ_qn@|SAWye3x(&2I|(n-!a`IL0IG1>rq&m_AQb8`hTyzC3q&qXux(nTTg$O@c}cHVtZW(WWk9!A+|Jse_pgLQd1lv6%BMW6pLrnj<XOph^pt+6J8MZWVCC'
    'yM36EOZ@WBUw+kb1n7+mQm4DEr9he7=Lo<z<WwhXZ3LT;Nf32yoiAYiisel6ZrfRiEWc4V#+KkQJ>#*t%W)Z6^z4}0!bZd28270`=sjn>%b?iEQ8ina55eF%'
    'KX%^R?0lc)dY33L`ShH=;}b}~*uK6~TwV#g<0&OyaoVqr0f&f4o59ijSTx|=F*Ub=Q*~d66yc9p-m$Mk03k@d{-lyFGk5()`Gt{1)TVrjETT8>-!F?ai;{2V'
    '!?joqi6;6~^_-`QXkwhk-gZxGg@k>#_GztDQs?nv)LV|%O9(6au?K2<c$`3>sRPs8dU|0#`A77hUB1Jl%|LJgt>O(Bsy--rw<wd=#jIFjg4^kBe!ZLLXQ=Ig'
    '<<3>I+eNf3%h#cPI7jn;*b<If(I@dFjz_QQ`fbxnl$t8#b4*|Car^#OXY%EwS+dudT#>BuxN@%K!=fdeFF5?bi`lhEo5#Q`PP1Nj#PSP|4nRglB9<wv8ShtL'
    'o0pCDh@(#qlTdRM^kf8p-%9NI&Qu@`-_q)gGek>pgY9SS_+fV2iD@BQ(I@sZZbqyk2uG>zpRny3P&%dQ!oHnQ;l^0h5UE&007hEyc;=NbxIh;H0jSk!lMxh6'
    'Ew3qa$!@!zS#fDu_};$Q40N$;Cyzz4k{k%nU`KuFQEKbWYO>Bj3IXhbz1K@9u2Ampl6D!!S0_o~<}3-^!XdyJAL(_Xv1g--HaDc%v!HZ{@93qmAy^RiYn~dq'
    'XfJo$Mwr`b@tK$#YEqb6p#vXtOA!Zi>kgz2HfVskRVzng?hoe|13;9U$s#`?dqPyM!gv-dna~yuu)K-7Z{NR(H_`bIKb&gp{bAs{+|LY3hQEP0&-j)X9vp}J'
    'L8EKlF?{y2hW6hyH0?p{Fy;@kOtck^7mLRbo!@K4UHUe&4Pw})mZfkd-wbxA#itsHebwB$AXx&35lT9<+h+JvR%}Njjy*&C!FwI>33e#?0lFRb!BY*0jeY45'
    't^n<kO;e>kA%&pc=Gk{@gF7Z`UIE_qT*BTSCtla~Xa>2EItF+OUfQ#5;5)W8JIS8!+TgjaYqRHht~u-Qe807s5OK8tp10bp;;c5XeANa`iMOi#NYXtVM6Ijc'
    '@_LT80)pOe%Xxk>otK;4I#)z`H~{$Y2}6<JtjjO?5|sum%T3C-PI;bI$^lDUtQ^lP3b``0$p7Pa)Pu3ZsU@u7mwa8qE7o+&J4~os^Nx%m<dv+U82k+zvW;Sf'
    'I;2fLrarwq^Qh+(PvaBX{73QCqrwAd@?ylzM+#SLqjp`RYwDl4o&~aZzN#AUi;ZJ)&nxR*H(~sl5W`}-Ke14RLcXmWyb4>(QRo_r3AJnkJFGONIupYU@ukfX'
    '@i`Fqf?iAT3mIurF(7~~v@u#dCG*gyu7?Q|ryMYIu7bSjuPresQ_cF!FHiyv`c;(`UaZ@yaaNbr(#``RW-IGgh0{3khwJ2tw(ayPU+wt<iIwfs!pGlirt5+i'
    '+1*~n@;d*^vLZD~OKB=(uZV^Hs3zFDwgtpWlY^nK%X_&ic*!kjLKLb^hDw|2WtZxW1eT@o9JCADVt8OASv>qzxoWi?-7-yK#>E20x2gb5*vMMEgHtN2>uxo@'
    '#IO3iumF;{ZA~~e(djpG8#PQR3vwg}w^?Of9z~`2Rkf(gx~M3>sx8VKjY_H!AB2EvHygHAyf_S`yIfH?=u!BBxf!0^kGFjoID9S)Y{0({gF$N<o{a<xg#?Qr'
    '5-ci6aA+aHVPhm%9DxM?52>cQPX'
)).decode("utf-8")
_BASE_NS = {}
exec(compile(_BASE_SRC, "base_agent.py", "exec"), _BASE_NS)
_BASE_AGENT = [_v for _v in list(_BASE_NS.values()) if callable(_v)][-1]
_SLOT_START = 288
_GUARD = True
_FIXED_PRICE = frozenset(("HIRE", "BUY_SEED", "BUY_ANIMAL", "BUY_LAND"))
_CAP = 100
_SHED_TILES = frozenset(((4, 4), (5, 4), (4, 5), (5, 5)))
_PRODUCT_OF = {"GOOSE": "EGG", "COW": "MILK", "SHEEP": "WOOL"}
_STRUCT_OF = {"GOOSE": "COOP", "COW": "PASTURE", "SHEEP": "PASTURE"}
_FIRST_YIELD = {"WHEAT": 2, "CARROT": 2, "TOMATO": 8, "STRAWBERRY": 10, "MELON": 10}
_SELLABLE = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER")


def _g(o, k, d=None):
    try:
        v = o[k]
    except Exception:
        v = getattr(o, k, d)
    return d if v is None else v


def _slot_priority(observation, action):
    try:
        step = int(observation["step"])
    except Exception:
        step = int(getattr(observation, "step", 0) or 0)
    if step < _SLOT_START or not isinstance(action, dict):
        return action
    market = action.get("market") or []
    if not any(isinstance(o, list) and o and o[0] == "SELL" for o in market):
        return action
    head, tail = [], []
    for o in market:
        if not (isinstance(o, list) and o):
            continue
        (tail if o[0] in _FIXED_PRICE else head).append(o)
    out = dict(action)
    out["market"] = (head + tail)[:10]
    return out


def _project(obs, action):
    """Shed and carried inventories after this turn's unit actions and market orders (engine rules)."""
    me = int(_g(obs, "player", 0))
    farm = _g(obs, "farms")[me]
    priv = _g(obs, "private")
    day = int(_g(obs, "step", 0)) // 24
    shed = {k: int(v) for k, v in dict(_g(priv, "shed", {})).items() if int(v) > 0}
    invs = [{k: int(v) for k, v in dict(inv).items() if int(v) > 0} for inv in _g(priv, "inventories", [{}])]
    pos = [tuple(_g(farm, "farmer"))] + [tuple(h) for h in _g(farm, "hands", [])]
    tiles = _g(farm, "tiles")
    size = len(tiles)
    done = set()
    units = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
    for idx, act in enumerate(units[:len(pos)]):
        if not (isinstance(act, list) and act):
            continue
        op = act[0]
        x, y = pos[idx]
        while len(invs) <= idx:
            invs.append({})
        inv = invs[idx]
        adj = (x, y) in _SHED_TILES
        tile = tiles[y][x] if 0 <= x < size and 0 <= y < size else None
        is_dict = isinstance(tile, dict) or hasattr(tile, "keys")
        if op == "HARVEST" and is_dict and ("H", x, y) not in done:
            n = int(_g(tile, "yield_units", 0))
            if n > 0 and _g(tile, "kind") == "PLANT":
                crop = _g(tile, "crop")
                if day - int(_g(tile, "planted_day", day)) >= _FIRST_YIELD.get(crop, 99):
                    inv[crop] = inv.get(crop, 0) + n
                    done.add(("H", x, y))
            elif n > 0 and _g(tile, "animal") in _PRODUCT_OF:
                prod = _PRODUCT_OF[_g(tile, "animal")]
                inv[prod] = inv.get(prod, 0) + n
                done.add(("H", x, y))
        elif op == "COLLECT_FERTILIZER" and is_dict and _g(tile, "animal") and _g(tile, "fertilizer_available", False) \
                and ("C", x, y) not in done:
            inv["FERTILIZER"] = inv.get("FERTILIZER", 0) + 1
            done.add(("C", x, y))
        elif op == "FEED" and is_dict and _g(tile, "animal") and not _g(tile, "fed_today", False) \
                and ("F", x, y) not in done and inv.get("WHEAT", 0) > 0:
            inv["WHEAT"] -= 1
            done.add(("F", x, y))
        elif op == "FERTILIZE" and is_dict and _g(tile, "kind") == "PLANT" and inv.get("FERTILIZER", 0) > 0:
            inv["FERTILIZER"] -= 1
        elif op == "PICKUP" and adj and len(act) >= 2:
            n = min(int(act[2]) if len(act) >= 3 else 1, shed.get(act[1], 0))
            if n > 0:
                shed[act[1]] -= n
                inv[act[1]] = inv.get(act[1], 0) + n
        elif op == "DROP" and adj:
            for item, n in list(inv.items()):
                take = min(n, max(0, _CAP - sum(shed.values())))
                if take > 0:
                    shed[item] = shed.get(item, 0) + take
                del inv[item]
        elif op == "PLACE" and len(act) >= 2:
            item = act[1]
            if item in _STRUCT_OF and is_dict and _g(tile, "kind") == _STRUCT_OF[item] and not _g(tile, "animal"):
                if inv.get(item, 0) > 0:
                    inv[item] -= 1
            elif adj:
                n = min(int(act[2]) if len(act) >= 3 else 1, inv.get(item, 0), max(0, _CAP - sum(shed.values())))
                if n > 0:
                    inv[item] -= n
                    shed[item] = shed.get(item, 0) + n
    for o in (action.get("market") or [])[:10]:
        if not (isinstance(o, list) and o):
            continue
        if o[0] == "SELL" and len(o) >= 3 and o[1] in shed:
            shed[o[1]] -= min(int(o[2]), shed[o[1]])
        elif o[0] in ("BUY_PRODUCT", "BUY_ANIMAL") and len(o) >= 3:
            n = min(int(o[2]), max(0, _CAP - sum(shed.values())))
            if n > 0:
                shed[o[1]] = shed.get(o[1], 0) + n
    return shed, invs, farm


def _room_guard(observation, action):
    step = int(_g(observation, "step", 0))
    if step % 24 != 23 or step >= 718 or not isinstance(action, dict):
        return action
    shed, invs, farm = _project(observation, action)
    carried = {}
    for inv in invs:
        for k, v in inv.items():
            if v > 0:
                carried[k] = carried.get(k, 0) + v
    excess = sum(v for v in shed.values() if v > 0) + sum(carried.values()) - _CAP
    if excess <= 0:
        return action
    animals = sum(1 for row in _g(farm, "tiles") for t in row
                  if (isinstance(t, dict) or hasattr(t, "keys")) and _g(t, "animal"))
    wheat_spare = shed.get("WHEAT", 0) + carried.get("WHEAT", 0) - (animals + 2)
    prices = _g(_g(observation, "market"), "prices", {})
    market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
    extra = []
    for item in sorted(_SELLABLE, key=lambda it: -int(_g(prices, it, 0))):
        avail = shed.get(item, 0)
        if item == "WHEAT":
            avail = min(avail, max(0, wheat_spare))
        n = min(excess, avail)
        if n <= 0 or int(_g(prices, item, 0)) <= 1:
            continue
        for o in market:
            if o[0] == "SELL" and len(o) >= 3 and o[1] == item:
                o[2] = int(o[2]) + n
                break
        else:
            extra.append(["SELL", item, n])
        excess -= n
        if excess <= 0:
            break
    out = dict(action)
    out["market"] = (extra + market)[:10]
    return out


_RACE_FROM = 720
_RACE_SHARE = 1.0
_RACE_ITEMS = ("MILK", "WOOL", "STRAWBERRY", "EGG", "TOMATO", "CARROT")
_SHOP_GOODS = {"BAKERY": ("EGG", "WHEAT"), "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
               "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"), "YARN_STORE": ("WOOL",),
               "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"), "PET_CAFE": ("CARROT",),
               "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
               "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY")}


def _kind(t):
    if not (isinstance(t, dict) or hasattr(t, "keys")):
        return None
    return _g(t, "animal") or _g(t, "crop") or _g(t, "kind")


def _similar(obs):
    """Share of occupied tiles holding the same thing on both farms (cha22-family rivals score ~1)."""
    me = int(_g(obs, "player", 0))
    farms = _g(obs, "farms")
    a, b = _g(farms[me], "tiles"), _g(farms[1 - me], "tiles")
    same = total = 0
    for y in range(len(a)):
        for x in range(len(a[y])):
            ka, kb = _kind(a[y][x]), _kind(b[y][x])
            if ka is None and kb is None:
                continue
            total += 1
            same += ka == kb
    return same / total if total else 0.0


def _race(observation, action):
    """Late game against a same-route rival: when both farms' stock of a premium good exceeds what the
    town can still eat before the end, prices only fall and the first seller wins, so every step after a
    consumption tick our remaining shed stock of that good is sold at the front of the list."""
    step = int(_g(observation, "step", 0))
    if step < _RACE_FROM or step >= 715 or step % 4 != 1 or not isinstance(action, dict):
        return action
    if _similar(observation) < 0.85:
        return action
    shed, invs, farm = _project(observation, action)
    shops = list(_g(_g(observation, "town", {}), "unlocked_shops", []))
    prices = _g(_g(observation, "market"), "prices", {})
    days_left = (718 - step) / 24.0
    market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
    planned = {}
    for o in market:
        if o[0] == "SELL" and len(o) >= 3:
            planned[o[1]] = planned.get(o[1], 0) + int(o[2])
    extra = []
    for item in _RACE_ITEMS:
        spare = shed.get(item, 0)
        if spare <= 0 or int(_g(prices, item, 0)) <= 2:
            continue
        rate = 1.0 + sum((12.0 if len(_SHOP_GOODS.get(sh, ())) == 1 else 6.0)
                         for sh in shops if item in _SHOP_GOODS.get(sh, ()))
        held = spare + planned.get(item, 0) + sum(i.get(item, 0) for i in invs)
        if 2 * held <= rate * days_left:
            continue
        k = int(math.ceil(spare * _RACE_SHARE))
        for o in market:
            if o[0] == "SELL" and len(o) >= 3 and o[1] == item:
                o[2] = int(o[2]) + k
                break
        else:
            extra.append(["SELL", item, k])
    if not extra and all(o == p for o, p in zip(market, action.get("market") or [])):
        return action
    out = dict(action)
    sells = [o for o in extra + market if o[0] == "SELL"]
    rest = [o for o in market if o[0] != "SELL"]
    out["market"] = (sells + rest)[:10]
    return out


_OPEN20 = False


def _open20(observation, action):
    """Step 0: the base's own v9 opening trade (BUY 20 / SELL 15 wheat, net +5) instead of the plain BUY 5
    a later base layer puts there; family rivals that beat us open this way."""
    step = int(_g(observation, "step", 0))
    if step != 0 or not isinstance(action, dict):
        return action
    market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
    wheat = [o for o in market if o[0] == "BUY_PRODUCT" and len(o) >= 3 and o[1] == "WHEAT"]
    if len(wheat) != 1 or int(wheat[0][2]) != 5:
        return action
    rest = [o for o in market if o is not wheat[0]]
    out = dict(action)
    out["market"] = [["BUY_PRODUCT", "WHEAT", 20], ["SELL", "WHEAT", 15]] + rest
    return out


_EAGER_FROM = 288
_EAGER_TO = 700
_EAGER_BANDS = {'MILK': (0.3, 0.9), 'STRAWBERRY': (0.3, 0.9), 'WOOL': (0.3, 0.9)}   # item -> (floor, ceiling) as shares of the base price
_SORT_SELLS = True
_SORT_TOL = 10.0
# engine MARKET_PARAMS: base, T, below_func, below_target, above_func, above_target (I0 = 10000)
_MKT = {"WHEAT": (25, 400, "sqrt", 0.80, "log", 0.20), "CARROT": (35, 450, "hinge", 1.00, "sqrt", 0.70),
        "TOMATO": (60, 200, "hinge", 0.40, "sqrt", 0.60), "STRAWBERRY": (120, 100, "sqrt", 0.70, "linear", 1.60),
        "MELON": (250, 300, "log", 0.20, "sq", 3.60), "EGG": (50, 332, "hinge", 0.40, "log", 0.20),
        "MILK": (160, 122, "sqrt", 0.60, "linear", 1.60), "WOOL": (200, 105, "log", 0.20, "sq", 3.20),
        "FERTILIZER": (100, 200, "linear", 0.40, "linear", 0.40)}


def _shape(f, x, T):
    x = max(0.0, x)
    if f == "linear":
        return x
    if f == "sq":
        return x * x
    if f == "sqrt":
        return math.sqrt(x)
    if f == "log":
        return math.log(1.0 + x)
    if f == "hinge":
        u = x / T
        return u + 8.0 * max(0.0, u - 1.0) ** 2
    return x


def _mprice(item, inv):
    base, T, bf, bt, af, at = _MKT[item]
    if inv < 10000:
        p = base + bt * base / _shape(bf, T, T) * _shape(bf, 10000 - inv, T)
    else:
        p = base - at * base / _shape(af, T, T) * _shape(af, inv - 10000, T)
    return max(1, int(round(p)))


def _stake(item, q, inv):
    """What our q units lose if a rival sells as many units of the same item in an earlier slot."""
    if item not in _MKT or q <= 0:
        return 0.0
    q = min(q, 40)
    return float(sum(_mprice(item, inv + k) - _mprice(item, inv + q + k) for k in range(q)))


def _eager(observation, action):
    """Sell premium goods as soon as they reach the shed instead of holding them for the base's
    scheduled lots: in a glutted market the first seller gets the price, and family rivals that
    sell on arrival beat the base's schedule by hundreds of coins."""
    step = int(_g(observation, "step", 0))
    if step < _EAGER_FROM or step >= _EAGER_TO or not isinstance(action, dict):
        return action
    shed, invs, farm = _project(observation, action)
    prices = _g(_g(observation, "market"), "prices", {})
    market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
    free = 10 - len(market)
    changed = False
    for item, (lo, hi) in _EAGER_BANDS.items():
        spare = shed.get(item, 0)
        quote = int(_g(prices, item, 0))
        if spare <= 0 or quote < max(2.0, lo * _MKT[item][0]) or quote > hi * _MKT[item][0]:
            continue
        for o in market:
            if o[0] == "SELL" and len(o) >= 3 and o[1] == item:
                o[2] = int(o[2]) + spare
                changed = True
                break
        else:
            if free > 0:
                market.insert(0, ["SELL", item, spare])
                free -= 1
                changed = True
    if not changed:
        return action
    out = dict(action)
    out["market"] = market[:10]
    return out


def _sort_sells(observation, action):
    """Permute the SELL orders among the slots they already occupy, largest stake first: in a same-step
    race the earlier slot sells every unit before the rival's first. An order only moves ahead of one it
    beats by more than _SORT_TOL coins, so a mirror rival's identical list keeps the base's order. A SELL
    after a BUY_PRODUCT of the same item (a wash) stays put; every other order keeps its slot."""
    step = int(_g(observation, "step", 0))
    if step < _SLOT_START or not isinstance(action, dict):
        return action
    market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
    inv = _g(_g(observation, "market"), "inventory", {})
    bought = set()
    slots, sells = [], []
    for i, o in enumerate(market):
        if o[0] == "BUY_PRODUCT" and len(o) >= 2:
            bought.add(o[1])
        elif o[0] == "SELL" and len(o) >= 3 and o[1] in _MKT and o[1] not in bought:
            slots.append(i)
            sells.append((-_stake(o[1], int(o[2]), int(_g(inv, o[1], 10000))), o))
    if len(sells) < 2:
        return action
    ranked = []
    for s, o in sells:
        pos = len(ranked)
        while pos > 0 and ranked[pos - 1][0] - s > _SORT_TOL:
            pos -= 1
        ranked.insert(pos, (s, o))
    if [o for s, o in ranked] == [o for s, o in sells]:
        return action
    for i, (s, o) in zip(slots, ranked):
        market[i] = o
    out = dict(action)
    out["market"] = market[:10]
    return out


def _v6_agent(observation, configuration=None):
    action = _BASE_AGENT(observation, configuration)
    if _OPEN20:
        try:
            action = _open20(observation, action)
        except Exception:
            pass
    if _EAGER_FROM < 720:
        try:
            action = _eager(observation, action)
        except Exception:
            pass
    try:
        action = _slot_priority(observation, action)
    except Exception:
        pass
    if _RACE_FROM < 720:
        try:
            action = _race(observation, action)
        except Exception:
            pass
    if _GUARD:
        try:
            action = _room_guard(observation, action)
        except Exception:
            pass
    if _SORT_SELLS:
        try:
            action = _sort_sells(observation, action)
        except Exception:
            pass
    return action


# ---- team 42 arena build: v6 + eager-sale band 0.2-1.4x base (MILK/STRAWBERRY/WOOL) + wheat lead-sell 2 steps keeping the next 4 steps of feed pickups
# Everything above is the live v6 (cha22 base, Apache-2.0, with team 42 layers) verbatim, except that its
# final `agent` is renamed `_v6_agent`. Below, team 42 modifications of 2026-09-25 (v7b, v7 with the eager floor at 0.3):
# 5. the eager sale band above is overridden to 0.3x base with no upper cap (MILK, STRAWBERRY, WOOL);
# 6. wheat lead-sell layer: from step 240 to 700, wheat that the route tape sells in the next 2 steps is
#    sold now (order appended last), keeping back the wheat the tape's units pick up from the shed in the
#    next 4 steps (their feed). Layer code from gold/hybrid/layers.py; other layers there are off.

_CFG = {'top': {'_EAGER_BANDS': {'MILK': (0.3, 99.0), 'STRAWBERRY': (0.3, 99.0), 'WOOL': (0.3, 99.0)}}, 'base': {}, 'layers': {'wheat_lead': {'lead': 2, 'hours': [], 'front': False, 'reserve_h': 4}}}


def _lg(o, k, d=None):
    if isinstance(o, dict):
        return o.get(k, d)
    return getattr(o, k, d)


def wrap(cfg, ns):
    """Apply cfg to a namespace holding v6 (its `agent`, `_project` and `_BASE_NS`) and return the layered agent."""
    for k, v in (cfg.get("top") or {}).items():
        ns[k] = v
    for k, v in (cfg.get("base") or {}).items():
        ns["_BASE_NS"][k] = v
    base_agent = ns["agent"]
    chassis = ns["_BASE_NS"]["_IMPL"].chassis
    force = cfg.get("force_route")
    table = cfg.get("route_table")
    late = cfg.get("late_route")
    force_from = int(cfg.get("force_from", 144))
    rules = cfg.get("route_rules") or []
    if force is not None or table or late is not None or rules:
        orig_router = chassis.router

        def router(observation, step, state, _orig=orig_router):
            r = _orig(observation, step, state)
            if late is not None and step >= 648:
                return state.get("_mid_route", r) if late == "keep" else late
            if 144 <= step < 648:
                if rules and step >= 216:
                    shops = list(_lg(_lg(observation, "town", {}), "unlocked_shops", []) or [])
                    if len(shops) >= 3:
                        for rule in rules:
                            if ("|".join(shops[:2]) == rule["pair"] and shops[2] not in rule.get("third_not", ())
                                    and (not rule.get("third_in") or shops[2] in rule["third_in"])):
                                state["_mid_route"] = rule["route"]
                                return rule["route"]
                if force is not None and step >= force_from:
                    r = force
                elif table:
                    key = state.get("_table_key")
                    if key is None:
                        shops = list(_lg(_lg(observation, "town", {}), "unlocked_shops", []) or [])[:2]
                        key = state["_table_key"] = "|".join(shops)
                    r = table.get(key, r)
                state["_mid_route"] = r
            return r
        chassis.router = router
    project = ns["_project"]
    layers = cfg.get("layers") or {}
    mm_state = {}

    def planned(route, step, item, lead):
        tape = chassis.routes.get(route) or []
        q = 0
        for t in range(step + 1, min(len(tape), step + 1 + lead)):
            a = tape[t]
            if isinstance(a, dict):
                for o in a.get("market") or []:
                    if o and o[0] == "SELL" and len(o) >= 3 and o[1] == item:
                        q += int(o[2])
        return q

    def planned_pickups(route, step, item, horizon):
        """Units of `item` the tape's units pick up from the shed in steps step+1 .. step+horizon."""
        tape = chassis.routes.get(route) or []
        q = 0
        for t in range(step + 1, min(len(tape), step + 1 + horizon)):
            a = tape[t]
            if isinstance(a, dict):
                for u in [a.get("farmer")] + list(a.get("hands") or []):
                    if isinstance(u, list) and len(u) >= 3 and u[0] == "PICKUP" and u[1] == item:
                        q += int(u[2])
        return q

    lead_debt = {}

    def lead_sell(obs, action, item, lead, hours, front, reserve_h=0, book=False):
        """Sell now what the route tape sells of `item` in the next `lead` steps. reserve_h > 0 keeps back what the
        tape's units pick up from the shed in the next reserve_h steps (feed); book=True subtracts the early sale from
        the tape's own later SELL orders, so the total sold stays the same and only the timing moves."""
        step = int(_lg(obs, "step", 0))
        player = int(_lg(obs, "player", 0))
        key = (player, item)
        if step == 0:
            lead_debt.pop(key, None)
        if step < 240 or step > 700:
            return action
        st = chassis.players.get(player)
        if not st or st.get("route") is None:
            return action
        market = None
        if book and lead_debt.get(key):
            due_now = sum(n for due, n in lead_debt[key] if due == step)
            lead_debt[key] = [(due, n) for due, n in lead_debt[key] if due > step]
            if due_now > 0:
                market = [list(o) for o in (action.get("market") or []) if isinstance(o, (list, tuple)) and o]
                for o in market:
                    if o[0] == "SELL" and len(o) >= 3 and o[1] == item and due_now > 0:
                        cut = min(int(o[2]), due_now)
                        o[2] = int(o[2]) - cut
                        due_now -= cut
                market = [o for o in market if not (o[0] == "SELL" and len(o) >= 3 and int(o[2]) <= 0)]
                action = dict(action)
                action["market"] = market
        if hours and step % 24 not in hours:
            return action
        plan = planned(st["route"], step, item, lead) - sum(n for due, n in lead_debt.get(key, []))
        if plan <= 0:
            return action
        shed, invs, farm = project(obs, action)
        market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
        selling = sum(int(o[2]) for o in market if o[0] == "SELL" and len(o) >= 3 and o[1] == item)
        reserve = planned_pickups(st["route"], step, item, reserve_h) if reserve_h else 0
        k = min(plan, int(shed.get(item, 0)) - selling - reserve)
        if k <= 0:
            return action
        if book:
            tape = chassis.routes.get(st["route"]) or []
            left = k
            for t in range(step + 1, min(len(tape), step + 1 + lead)):
                a = tape[t]
                if isinstance(a, dict) and left > 0:
                    q = sum(int(o[2]) for o in (a.get("market") or []) if o and o[0] == "SELL" and len(o) >= 3
                            and o[1] == item)
                    take = min(q, left)
                    if take > 0:
                        lead_debt.setdefault(key, []).append((t, take))
                        left -= take
        for i, o in enumerate(market):
            if o[0] == "SELL" and o[1] == item:
                o[2] = int(o[2]) + k
                if front:
                    market.insert(0, market.pop(i))
                break
        else:
            if len(market) >= 10:
                return action
            if front:
                market.insert(0, ["SELL", item, k])
            else:
                market.append(["SELL", item, k])
        out = dict(action)
        out["market"] = market
        return out

    def wheat_mm(obs, action, q, keep):
        step = int(_lg(obs, "step", 0))
        player = int(_lg(obs, "player", 0))
        st = mm_state.get(player)
        if st is None or step == 0:
            st = mm_state[player] = {"held": 0, "buy_step": -9, "before": 0}
        market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
        shed, invs, farm = project(obs, action)
        if st["held"] and step == st["buy_step"] + 1:
            raw = dict(_lg(_lg(obs, "private", {}) or {}, "shed", {}) or {})
            got = int(raw.get("WHEAT", 0)) - st["before"]
            held = max(0, min(st["held"], got))
            if held > 0:
                market.insert(0, ["SELL", "WHEAT", held])
            st["held"] = 0
        elif 264 <= step <= 688 and step % 4 == 0 and step % 24 < 20 and len(market) < 10:
            room = 100 - sum(shed.values()) - sum(int(o[2]) for o in market if o[0] == "BUY_PRODUCT" and len(o) >= 3)
            money = float(_lg(_lg(obs, "farms")[player], "money", 0))
            if room >= q + keep and money > 4000:
                market.append(["BUY_PRODUCT", "WHEAT", q])
                st.update(held=q, buy_step=step, before=int(shed.get("WHEAT", 0)))
        out = dict(action)
        out["market"] = market[:10]
        return out

    opp_state = {}
    product_of = {"COW": "MILK", "SHEEP": "WOOL", "GOOSE": "EGG"}

    def opp_race(obs, action, items, min_units, share):
        """Sell our shed stock of a premium good in slot 0 on the step the rival harvests a lot of it: its units
        carry the lot to its shed and sell it a few steps later, so ours reaches the book first."""
        step = int(_lg(obs, "step", 0))
        player = int(_lg(obs, "player", 0))
        farms = _lg(obs, "farms")
        tiles = _lg(farms[1 - player], "tiles")
        snap = {}
        for y, row in enumerate(tiles):
            for x, t in enumerate(row):
                if isinstance(t, dict):
                    item = t.get("crop") or product_of.get(t.get("animal"))
                    if item in items:
                        snap[(x, y)] = (item, int(t.get("yield_units", 0) or 0))
        st = opp_state.get(player)
        opp_state[player] = {"step": step, "snap": snap}
        if st is None or st["step"] != step - 1 or step < 240 or step > 710:
            return action
        harvested = {}
        for xy, (item, y0) in st["snap"].items():
            now = snap.get(xy)
            y1 = now[1] if now and now[0] == item else 0
            if y1 < y0:
                harvested[item] = harvested.get(item, 0) + (y0 - y1)
        hot = [i for i, n in harvested.items() if n >= min_units]
        if not hot:
            return action
        shed, invs, farm = project(obs, action)
        market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
        for item in hot:
            selling = sum(int(o[2]) for o in market if o[0] == "SELL" and len(o) >= 3 and o[1] == item)
            k = int((int(shed.get(item, 0)) - selling) * share)
            if k <= 0:
                continue
            for i, o in enumerate(market):
                if o[0] == "SELL" and o[1] == item:
                    o[2] = int(o[2]) + k
                    market.insert(0, market.pop(i))
                    break
            else:
                if len(market) >= 10:
                    continue
                market.insert(0, ["SELL", item, k])
        out = dict(action)
        out["market"] = market[:10]
        return out

    base_price = {"WHEAT": 25, "CARROT": 35, "TOMATO": 60, "STRAWBERRY": 120, "MELON": 250, "EGG": 50, "MILK": 160,
                  "WOOL": 200, "FERTILIZER": 100}

    def hold_premium(obs, action, items, floor, dump_from, min_room):
        """Drop SELL orders of `items` quoted below floor x base while the shed keeps `min_room` free slots."""
        step = int(_lg(obs, "step", 0))
        if step < 240 or step >= dump_from:
            return action
        shed, invs, farm = project(obs, action)
        prices = _lg(_lg(obs, "market"), "prices")
        market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
        room = 100 - sum(shed.values())
        keep = []
        for o in market:
            if o[0] == "SELL" and len(o) >= 3 and o[1] in items:
                px = float(prices.get(o[1], 0) if isinstance(prices, dict) else _lg(prices, o[1], 0))
                n = int(o[2])
                if px < floor * base_price[o[1]] and room - n >= min_room:
                    room -= n
                    continue
            keep.append(o)
        out = dict(action)
        out["market"] = keep
        return out

    mirror_knobs = cfg.get("mirror_knobs") or {}
    mirror_sim = float(cfg.get("mirror_sim", 0.9))
    mirror_from = int(cfg.get("mirror_from", 144))
    base_ns = ns["_BASE_NS"]
    knob_default = {k: base_ns.get(k) for k in mirror_knobs}
    mirror_state = {}

    def tile_key(t):
        if not isinstance(t, dict):
            return t
        return (t.get("kind"), t.get("crop"), t.get("animal"))

    def set_mirror_knobs(obs):
        """Aggressive knobs only while the rival's farm looks like ours (a cha22-family mirror)."""
        step = int(_lg(obs, "step", 0))
        player = int(_lg(obs, "player", 0))
        st = mirror_state.setdefault(player, {"on": False, "last": -99})
        if step == 0:
            st.update(on=False, last=-99)
        if step >= mirror_from and step - st["last"] >= 24:
            st["last"] = step
            farms = _lg(obs, "farms")
            mine, theirs = _lg(farms[player], "tiles"), _lg(farms[1 - player], "tiles")
            same = total = 0
            for y in range(len(mine)):
                for x in range(len(mine[y])):
                    a, b = tile_key(mine[y][x]), tile_key(theirs[y][x])
                    if a in (None, "LOCKED") and b in (None, "LOCKED"):
                        continue
                    total += 1
                    same += a == b
            st["on"] = total > 0 and same / total >= mirror_sim
        for k, v in mirror_knobs.items():
            base_ns[k] = v if st["on"] else knob_default[k]

    def agent(observation, configuration=None):
        if mirror_knobs:
            try:
                set_mirror_knobs(observation)
            except Exception:
                pass
        action = base_agent(observation, configuration)
        for name, p in layers.items():
            if not p:
                continue
            try:
                if name == "fert_lead":
                    action = lead_sell(observation, action, "FERTILIZER", p.get("lead", 3), p.get("hours", [19, 20, 21]),
                                       p.get("front", False))
                elif name == "wheat_lead":
                    action = lead_sell(observation, action, "WHEAT", p.get("lead", 2), p.get("hours", []),
                                       p.get("front", False), p.get("reserve_h", 0), p.get("book", False))
                elif name == "bulk_lead":
                    for item in p.get("items", ["EGG", "TOMATO", "CARROT"]):
                        action = lead_sell(observation, action, item, p.get("lead", 2), p.get("hours", []),
                                           p.get("front", False))
                elif name == "premium_lead":
                    for item in p.get("items", ["MILK", "WOOL", "STRAWBERRY"]):
                        action = lead_sell(observation, action, item, p.get("lead", 2), p.get("hours", []), True)
                elif name == "wheat_mm":
                    action = wheat_mm(observation, action, p.get("q", 30), p.get("keep", 25))
                elif name == "final_dump":
                    step = int(_lg(observation, "step", 0))
                    if p.get("from_step", 696) <= step <= 711:
                        shed, invs, farm = project(observation, action)
                        market = [list(o) for o in (action.get("market") or []) if isinstance(o, list) and o]
                        for item in p.get("items", ["MILK", "WOOL", "STRAWBERRY", "EGG", "TOMATO"]):
                            selling = sum(int(o[2]) for o in market if o[0] == "SELL" and len(o) >= 3 and o[1] == item)
                            k = int(shed.get(item, 0)) - selling
                            if k <= 0:
                                continue
                            for i, o in enumerate(market):
                                if o[0] == "SELL" and o[1] == item:
                                    o[2] = int(o[2]) + k
                                    market.insert(0, market.pop(i))
                                    break
                            else:
                                if len(market) < 10:
                                    market.insert(0, ["SELL", item, k])
                        action = dict(action)
                        action["market"] = market[:10]
                elif name == "hold_premium":
                    action = hold_premium(observation, action, tuple(p.get("items", ["MILK", "WOOL", "STRAWBERRY"])),
                                          p.get("floor", 0.8), p.get("dump_from", 696), p.get("min_room", 20))
                elif name == "opp_race":
                    action = opp_race(observation, action, tuple(p.get("items", ["MILK", "WOOL", "STRAWBERRY"])),
                                      p.get("min_units", 2), p.get("share", 1.0))
            except Exception:
                pass
        return action

    return agent


agent = _v6_agent
_LAYERED = wrap(_CFG, globals())


def agent(observation, configuration=None):
    return _LAYERED(observation, configuration)


# ---------------------------------------------------------------------------
# Team 42 SHEEPFEED fix (outermost layer): see tools/add_sheepfeed.py.
_SF_MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}


def _sf_ns():
    return globals().get("_BASE_NS") or globals()


def _sf_walk(pos, target):
    x, y = pos
    tx, ty = target
    if x != tx:
        return ["EAST" if x < tx else "WEST"]
    if y != ty:
        return ["SOUTH" if y < ty else "NORTH"]
    return None


_SF_STUCK = {}


def _sheepfeed(obs, action):
    step = int(obs["step"])
    day, hour = divmod(step, 24)
    seat0 = int(obs["player"])
    rec = _SF_STUCK.get(seat0)
    if rec is None or step <= rec["step"]:
        rec = _SF_STUCK[seat0] = {"step": -1, "run": {}, "stall_day": {}}
    rec["step"] = step
    if day < 11 or step >= 717 or not isinstance(action, dict):
        return action
    seat = int(obs["player"])
    st = (_sf_ns().get("_V233_STATES") or {}).get(seat)
    if not st or not st.get("committed") or not st.get("workers"):
        return action
    farm = obs["farms"][seat]
    priv = obs["private"]
    tiles = farm["tiles"]
    hands = farm["hands"]
    units = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
    positions = [tuple(farm["farmer"])] + [tuple(h) for h in hands]
    access = {(4, 4), (5, 4), (4, 5), (5, 5)}
    invs = priv.get("inventories") or []
    shed_wheat = int((priv.get("shed") or {}).get("WHEAT", 0))
    sheep = {}
    for targets in st["workers"].values():
        for x, y in targets:
            t = tiles[y][x]
            if isinstance(t, dict) and t.get("animal") == "SHEEP":
                sheep[(x, y)] = t
    hungry = [xy for xy, t in sheep.items() if not t.get("fed_today")]
    changed = False
    stalled = False
    # wheat the earlier units pick up this turn, in engine order (farmer, then hands by index)
    left = shed_wheat
    for i, cmd in enumerate(units[:len(positions)]):
        pickup = bool(cmd) and cmd[0] == "PICKUP" and len(cmd) >= 2 and cmd[1] == "WHEAT" and positions[i] in access
        want = (int(cmd[2]) if len(cmd) >= 3 else 1) if pickup else 0
        if i in st["workers"]:
            if pickup:
                stuck_now = want <= 0 or left <= 0
                run = rec["run"].get(i, 0) + 1 if stuck_now else 0
                rec["run"][i] = run
                if stuck_now and run >= 2:   # a real deadlock: nothing to pick up on two turns in a row
                    rec["stall_day"][i] = day
            if rec["stall_day"].get(i) == day:
                # take the worker over for the day while it cannot get wheat from the shed
                stalled = True
                inv = invs[i] if i < len(invs) else {}
                pos = positions[i]
                new = None
                if int(inv.get("WHEAT", 0)) > 0 and hungry:
                    here = sheep.get(pos)
                    if not (cmd == ["FEED"] and here is not None and not here.get("fed_today")):
                        target = min(hungry, key=lambda xy: (abs(pos[0] - xy[0]) + abs(pos[1] - xy[1]), xy))
                        new = _sf_walk(pos, target) or ["FEED"]
                elif left <= 0 or not hungry:
                    todo = [xy for xy, t in sheep.items() if t.get("fed_today") and not t.get("cared_today")]
                    todo = todo or [xy for xy, t in sheep.items() if int(t.get("yield_units", 0)) > 0]
                    if todo:
                        target = min(todo, key=lambda xy: (abs(pos[0] - xy[0]) + abs(pos[1] - xy[1]), xy))
                        t = sheep[target]
                        new = _sf_walk(pos, target) or (["CARE"] if t.get("fed_today") and not t.get("cared_today")
                                                         else ["HARVEST"])
                if new:
                    units[i] = new
                    changed = True
                    continue
        if pickup:
            left -= min(max(0, want), left)
    carried = sum(int((invs[i] if i < len(invs) else {}).get("WHEAT", 0)) for i in st["workers"])
    short = len(hungry) - carried - left
    market = [list(o) for o in (action.get("market") or []) if isinstance(o, (list, tuple)) and o]
    if stalled and short > 0 and hour <= 20:
        for o in market:
            if short > 0 and o[0] == "SELL" and len(o) >= 3 and o[1] == "WHEAT" and int(o[2]) > 0:
                cut = min(int(o[2]), short)
                o[2] = int(o[2]) - cut
                short -= cut
                changed = True
        buying = sum(int(o[2]) for o in market if o[0] == "BUY_PRODUCT" and len(o) >= 3 and o[1] == "WHEAT")
        need = min(6, short - buying)
        quote = int((obs["market"]["prices"] or {}).get("WHEAT", 0))
        if need > 0 and 0 < quote and float(farm.get("money", 0)) > 1000 + need * (quote + 10):
            for o in market:
                if o[0] == "BUY_PRODUCT" and len(o) >= 3 and o[1] == "WHEAT":
                    o[2] = int(o[2]) + need
                    break
            else:
                if len(market) >= 10:
                    market = [o for o in market if not (o[0] == "SELL" and len(o) >= 3 and int(o[2]) <= 0)]
                if len(market) < 10:
                    market.insert(0, ["BUY_PRODUCT", "WHEAT", need])
            changed = True
    if not changed:
        return action
    out = dict(action)
    out["farmer"], out["hands"] = units[0], units[1:]
    out["market"] = market[:10]
    return out


_PRE_SF_AGENT = globals().pop("agent")   # pop first: the loader takes the last callable in module order


def agent(observation, configuration=None):
    action = _PRE_SF_AGENT(observation, configuration)
    try:
        return _sheepfeed(observation, action)
    except Exception:
        return action


# ---------------------------------------------------------------------------
# Team 42 FERTMORE layer (outermost): see tools/add_fertmore.py.
_FM_FROM, _FM_TO = 288, 690
_FM_EXTRA = 0   # extra units taken at the route's own fertilizer pickups
_FM_EXTRA_FROM = 20   # from this day (the fertilizer book is worth $10-20 by then)
# crop: (first_yield_day, max_yield_day, max_yield, ongoing, interval)
_FM_CROPS = {"WHEAT": (2, 4, 6, False, 0), "CARROT": (2, 3, 4, False, 0),
             "TOMATO": (8, 8, 4, True, 1), "STRAWBERRY": (10, 10, 4, True, 2)}
_FM_ACCESS = ((4, 4), (5, 4), (4, 5), (5, 5))
_FM_STEPS = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}
_FM_CACHE = {}


def _fm_ns():
    return globals().get("_BASE_NS") or globals()


def _fm_spawn(positions):
    occ = {a: 0 for a in _FM_ACCESS}
    for p in positions:
        if tuple(p) in occ:
            occ[tuple(p)] += 1
    return min(_FM_ACCESS, key=lambda a: (occ[a], _FM_ACCESS.index(a)))


def _fm_tape_waters(seat, day):
    """Tiles the route's own units water on `day` (farmer from (4, 4), hands spawned by the tape's hires)."""
    key = (seat, day)
    if key in _FM_CACHE:
        return _FM_CACHE[key]
    chassis = _fm_ns()["_IMPL"].chassis
    native = chassis.players.get(seat)
    out = set()
    if native and native.get("route") is not None and day <= 29:
        pos = [(4, 4)]
        for t in range(day * 24, min(719, day * 24 + 24)):
            tape = chassis.routes.get(2 if t >= 648 else native["route"]) or []
            a = tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}
            cmds = [a.get("farmer") or ["PASS"]] + list(a.get("hands") or [])
            for i in range(len(pos)):
                c = cmds[i] if i < len(cmds) and cmds[i] else ["PASS"]
                if c[0] in _FM_STEPS:
                    dx, dy = _FM_STEPS[c[0]]
                    nx, ny = pos[i][0] + dx, pos[i][1] + dy
                    if 0 <= nx < 10 and 0 <= ny < 10:
                        pos[i] = (nx, ny)
                elif c[0] == "WATER":
                    out.add(pos[i])
            for o in a.get("market") or []:
                if o and o[0] == "HIRE":
                    pos.append(_fm_spawn(pos))
    if len(_FM_CACHE) > 16:
        _FM_CACHE.clear()
    _FM_CACHE[key] = out
    return out


def _fm_gain_units(t, day, replacing_water, tomorrow_watered):
    spec = _FM_CROPS.get(t.get("crop"))
    if not spec:
        return 0.0
    first, maxday, maxy, ongoing, interval = spec
    planted = int(t["planted_day"])
    fu = int(t.get("fertilized_until_day", -1))
    watered = bool(t.get("watered_today"))
    if not ongoing:
        ws = (maxday + 1) // 2
        covered = 0
        for d in (day, day + 1, day + 2):
            a = d - planted
            if a < ws or a > maxday or d <= fu:
                continue
            if d == day and (replacing_water or watered):
                continue
            covered += 1
        remaining = sum(1 for d in range(day, planted + maxday + 1)
                        if d - planted >= ws and not (d == day and watered))
        room = max(0, maxy - int(t.get("yield_units", 0)) - remaining)
        return 0.75 * min(covered, room)
    units = 0
    for e in (day, day + 1, day + 2):
        if e > 28 or e <= fu:
            continue
        dsf = e + 1 - planted - first
        if dsf < 0 or dsf % interval or dsf // interval + 1 > maxy:
            continue
        if e == day and not watered:
            continue
        if e == day + 1 and not tomorrow_watered:
            continue
        units += 1
    return 0.9 * units


def _fertmore(obs, action):
    step = int(obs["step"])
    day = step // 24
    if step < _FM_FROM or step > _FM_TO or not isinstance(action, dict):
        return action
    seat = int(obs["player"])
    chassis = _fm_ns()["_IMPL"].chassis
    native = chassis.players.get(seat)
    if not native or native.get("route") is None:
        return action
    farm = obs["farms"][seat]
    priv = obs["private"]
    tiles = farm["tiles"]
    positions = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
    invs = priv.get("inventories") or []
    units = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
    prices = obs["market"]["prices"]
    fquote = float(prices.get("FERTILIZER", 0))
    tape = chassis.routes.get(2 if step >= 648 else native["route"]) or []
    planned = {}
    for tt in range(step + 1, min(len(tape), day * 24 + 24)):
        a = tape[tt] if isinstance(tape[tt], dict) else {}
        for u, c in enumerate([a.get("farmer") or ["PASS"]] + list(a.get("hands") or [])):
            if c and c[0] == "FERTILIZE":
                planned[u] = planned.get(u, 0) + 1
    tomorrow = None
    targeted = set()
    changed = False
    if _FM_EXTRA > 0 and day >= _FM_EXTRA_FROM:
        # the route's own fertilizer pickups take a few more units to spend along the way, but only out of
        # stock that no later pickup of the route needs today
        later = 0
        for tt in range(step + 1, min(len(tape), day * 24 + 24)):
            a = tape[tt] if isinstance(tape[tt], dict) else {}
            for c in [a.get("farmer") or ["PASS"]] + list(a.get("hands") or []):
                if c and c[0] == "PICKUP" and len(c) >= 3 and c[1] == "FERTILIZER":
                    later += max(0, int(c[2]))
        shed_f = int((priv.get("shed") or {}).get("FERTILIZER", 0)) - later
        for u, cmd in enumerate(units[:len(positions)]):
            if cmd and cmd[0] == "PICKUP" and len(cmd) >= 2 and positions[u] in _FM_ACCESS:
                want = max(0, int(cmd[2]) if len(cmd) >= 3 else 1)
                if cmd[1] == "FERTILIZER":
                    extra = min(_FM_EXTRA, max(0, shed_f - want))
                    if extra > 0:
                        units[u] = ["PICKUP", "FERTILIZER", want + extra]
                        changed = True
                    shed_f -= min(shed_f, want + max(0, extra))
    for u, cmd in enumerate(units[:len(positions)]):
        inv = invs[u] if u < len(invs) else {}
        spare = int(inv.get("FERTILIZER", 0)) - planned.get(u, 0)
        if spare <= 0:
            continue
        pos = positions[u]
        t = tiles[pos[1]][pos[0]]
        if not (isinstance(t, dict) and t.get("kind") == "PLANT") or pos in targeted:
            continue
        crop = t.get("crop")
        if crop not in _FM_CROPS:
            continue
        op = cmd[0] if cmd else "PASS"
        replacing = False
        if op == "PASS" or (op == "WATER" and t.get("watered_today")):
            pass
        elif op == "WATER" and int(t.get("consecutive_unwatered", 1)) == 0:
            age = day - int(t["planted_day"])
            if crop in ("WHEAT", "CARROT") and age == 1:
                replacing = True
            elif crop == "STRAWBERRY":
                first, maxday, maxy, ongoing, interval = _FM_CROPS[crop]
                dsf = day + 1 - int(t["planted_day"]) - first
                if dsf >= 0 and dsf % interval == 0:
                    continue          # production tonight: keep today's water
                if tomorrow is None:
                    tomorrow = _fm_tape_waters(seat, day + 1)
                if pos not in tomorrow:
                    continue
                replacing = True
            else:
                continue
        else:
            continue
        tw = True
        if t.get("crop") in ("STRAWBERRY", "TOMATO"):
            if tomorrow is None:
                tomorrow = _fm_tape_waters(seat, day + 1)
            tw = pos in tomorrow
        value = _fm_gain_units(t, day, replacing, tw) * float(prices.get(crop, 0))
        if value <= fquote + 5:
            continue
        units[u] = ["FERTILIZE"]
        targeted.add(pos)
        changed = True
    if not changed:
        return action
    out = dict(action)
    out["farmer"], out["hands"] = units[0], units[1:]
    return out


_PRE_FM_AGENT = globals().pop("agent")   # pop first: the loader takes the last callable in module order


def agent(observation, configuration=None):
    action = _PRE_FM_AGENT(observation, configuration)
    try:
        return _fertmore(observation, action)
    except Exception:
        return action

# ---------------------------------------------------------------------------
# Team 42 TICK layer (outermost), 2026-09-25: wheat tick arbitrage. The town eats wheat right after
# the market of every step s with s % 4 == 0. At such steps (day 10 on) buy up to N wheat in the last
# order slot, N capped by shed room that stays safe if every unit ending the step on a shed tile drops
# its bag at s + 1, and by spare cash; sell the same wheat at s + 1 (joined to the base wheat sell or
# right after the leading sells). The base policy sees the shed without that wheat. Stops for the rest
# of the game once the rival is seen doing the same (its wheat flow is inferred from the market).
_TICK_SRC = r'''import copy as _copy
import math as _math
CFG = {'FROM_DAY': 10, 'NMAX': 95, 'RESERVE': 1500.0, 'MIN_GAIN': 3.0, 'MARGIN': 3, 'NEAR': 1, 'BUYSLOT': 'pad', 'SELLSLOT': 'after', 'GUARD': 1, 'TH': 10, 'WIN': 8, 'HITS': 2}
TEL = {"buys": 0, "units": 0, "sold": 0, "skips_full": 0, "carry": 0}
_WSHOPS = {"BAKERY", "PIZZA_SHOP", "BRUNCH_SPOT", "ICE_CREAM_SHOP", "FARMERS_MARKET"}
_FIB = [1, 1]
while len(_FIB) < 40:
    _FIB.append(_FIB[-1] + _FIB[-2])
_PRICE = {"COW": 400, "SHEEP": 500, "GOOSE": 300}
_SEED = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}
_AMP_B = 0.8 * 25 / _math.sqrt(400)
_AMP_A = 0.2 * 25 / _math.log(401)
_MEM = {}
_SHED = frozenset(((4, 4), (5, 4), (4, 5), (5, 5)))
_MOVES = {"MOVE_UP": (0, -1), "MOVE_DOWN": (0, 1), "MOVE_LEFT": (-1, 0), "MOVE_RIGHT": (1, 0),
          "UP": (0, -1), "DOWN": (0, 1), "LEFT": (-1, 0), "RIGHT": (1, 0),
          "NORTH": (0, -1), "SOUTH": (0, 1), "WEST": (-1, 0), "EAST": (1, 0)}


def _wp(inv):
    if inv < 10000:
        p = 25 + _AMP_B * _math.sqrt(10000 - inv)
    else:
        p = 25 - _AMP_A * _math.log(1 + inv - 10000)
    return max(1, int(round(p)))


def _get(o, k, d=None):
    try:
        return o[k]
    except Exception:
        return getattr(o, k, d)


def _spend(prices, market, hires_today):
    s = 0.0
    h = hires_today
    for o in market:
        if not o:
            continue
        if o[0] == "HIRE":
            s += _FIB[min(39, h)]
            h += 1
        elif o[0] == "BUY_LAND":
            s += 4000
        elif o[0] == "BUY_ANIMAL" and len(o) >= 3:
            s += _PRICE.get(o[1], 500) * int(o[2])
        elif o[0] == "BUY_SEED" and len(o) >= 3:
            s += _SEED.get(o[1], 100) * int(o[2])
        elif o[0] == "BUY_PRODUCT" and len(o) >= 3:
            s += (int(_get(prices, o[1], 50)) + 6) * int(o[2])
    return s


def _net_wheat(market):
    n = 0
    for o in market:
        if o and len(o) >= 3 and o[1] == "WHEAT":
            if o[0] == "SELL":
                n += int(o[2])
            elif o[0] == "BUY_PRODUCT":
                n -= int(o[2])
    return n


def _doctor(observation, hide):
    obs = _copy.deepcopy(observation)
    priv = _get(obs, "private")
    shed = dict(_get(priv, "shed", {}) or {})
    shed["WHEAT"] = max(0, int(shed.get("WHEAT", 0)) - hide)
    try:
        priv["shed"] = shed
    except Exception:
        setattr(priv, "shed", shed)
    return obs


def _cons(observation, step):
    if step % 4 != 0:
        return 0
    town = _get(observation, "town", {}) or {}
    shops = list(_get(town, "unlocked_shops", []) or [])
    return sum(1 for s in shops if s in _WSHOPS) + (1 if step % 24 == 0 else 0)


def _track(mem, observation, step, a):
    """Infer the rival's net wheat flow of the previous step from the market identity
    dI = our net sold + rival net sold - town use; flag a rival that buys at s % 4 == 0 and sells at s + 1."""
    mk = _get(observation, "market", {}) or {}
    inv_w = int((_get(mk, "inventory", {}) or {}).get("WHEAT", 10000))
    w_now = int((_get(_get(observation, "private"), "shed", {}) or {}).get("WHEAT", 0))
    prev = mem.get("prev")
    if prev is not None and prev["step"] == step - 1 and prev["step"] % 24 != 23:
        our_net = prev["w_units"] - w_now
        mem["flow"][prev["step"]] = (inv_w - prev["inv"]) - our_net + prev["cons"]
    try:
        w_units = int(_PROJECT(observation, dict(a, market=[]))[0].get("WHEAT", 0))
    except Exception:
        w_units = w_now
    mem["prev"] = {"step": step, "inv": inv_w, "w_units": w_units, "cons": _cons(observation, step)}
    if not mem["rival"] and step % 4 == 2:
        fl = mem["flow"]
        hits = 0
        for s0 in range(step - 2, step - 2 - 4 * CFG["WIN"], -4):
            if fl.get(s0, 0) <= -CFG["TH"] and fl.get(s0 + 1, 0) >= CFG["TH"]:
                hits += 1
        if hits >= CFG["HITS"]:
            mem["rival"] = True
            TEL["rival_step"] = step


def _decide(observation, configuration=None):
    try:
        step = int(_get(observation, "step", 0))
        me = int(_get(observation, "player", 0))
    except Exception:
        return _BASE(observation, configuration)
    mem = _MEM.setdefault(me, {"pend": None, "last": -1})
    if step <= mem["last"]:
        mem.clear()
        mem.update({"pend": None, "last": -1})
    mem.setdefault("flow", {})
    mem.setdefault("rival", False)
    mem["last"] = step
    pend = mem["pend"]
    hide = 0
    if pend is not None:
        try:
            shed_w = int((_get(_get(observation, "private"), "shed", {}) or {}).get("WHEAT", 0))
            hide = max(0, min(pend["n"], shed_w - pend["without"]))
        except Exception:
            hide = 0
    obs_in = observation
    if hide > 0:
        try:
            obs_in = _doctor(observation, hide)
        except Exception:
            obs_in = observation
    a = _BASE(obs_in, configuration)
    try:
        if not isinstance(a, dict):
            return a
        market = [list(o) for o in (a.get("market") or []) if isinstance(o, (list, tuple)) and o]
        if pend is not None:
            mem["pend"] = None
            if hide > 0:
                placed = False
                if CFG["SELLSLOT"] == "first" and len(market) < 10:
                    market.insert(0, ["SELL", "WHEAT", hide])
                    placed = True
                for o in ([] if placed else market):
                    if o[0] == "SELL" and len(o) >= 3 and o[1] == "WHEAT":
                        o[2] = int(o[2]) + hide
                        placed = True
                        break
                if not placed and len(market) < 10:
                    i = 0
                    while i < len(market) and market[i][0] == "SELL":
                        i += 1
                    market.insert(i, ["SELL", "WHEAT", hide])
                    placed = True
                if placed:
                    TEL["sold"] += hide
                else:
                    TEL["carry"] += 1
                    mem["pend"] = {"n": hide, "without": pend["without"], "step": step}
            a = dict(a)
            a["market"] = market
            if mem["pend"] is not None:
                return a
        if step % 4 != 0 or step // 24 < CFG["FROM_DAY"] or step > 716:
            return a
        if mem.get("rival"):
            TEL["rival_skips"] = TEL.get("rival_skips", 0) + 1
            return a
        if len(market) >= 10:
            TEL["skips_full"] += 1
            return a
        town = _get(observation, "town", {}) or {}
        shops = list(_get(town, "unlocked_shops", []) or [])
        c = sum(1 for s in shops if s in _WSHOPS) + (1 if step % 24 == 0 else 0)
        if c <= 0:
            return a
        mk = _get(observation, "market", {}) or {}
        inv_w = int((_get(mk, "inventory", {}) or {}).get("WHEAT", 10000))
        prices = _get(mk, "prices", {}) or {}
        proj = _PROJECT(observation, dict(a, market=market))
        pshed, pinvs = proj[0], proj[1]
        carried = 0
        if CFG["NEAR"]:
            me_f = _get(observation, "farms")[me]
            pos = [tuple(_get(me_f, "farmer"))] + [tuple(h) for h in (_get(me_f, "hands", []) or [])]
            units = [a.get("farmer") or ["PASS"]] + list(a.get("hands") or [])
            for idx, inv in enumerate(pinvs):
                if idx >= len(pos):
                    break
                x, y = pos[idx]
                act = units[idx] if idx < len(units) else ["PASS"]
                if isinstance(act, list) and act and act[0] in _MOVES:
                    dx, dy = _MOVES[act[0]]
                    x, y = x + dx, y + dy
                if (x, y) in _SHED:
                    carried += sum(int(v) for v in inv.values() if int(v) > 0)
        else:
            carried = sum(int(v) for inv in pinvs for v in inv.values() if int(v) > 0)
        room = 100 - sum(int(v) for v in pshed.values()) - carried - CFG["MARGIN"]
        me_farm = _get(observation, "farms")[me]
        money = float(_get(me_farm, "money", 0))
        spend = _spend(prices, market, int(_get(me_farm, "hires_today", 0) or 0))
        cash = money - spend - CFG["RESERVE"]
        I = inv_w + _net_wheat(market)
        n = min(int(CFG["NMAX"]), room)
        TEL["lim_room"] = TEL.get("lim_room", 0) + (room < int(CFG["NMAX"]))
        cost = 0
        k = 0
        while k < n:
            p = _wp(I - k - 1)
            if cost + p > cash:
                break
            cost += p
            k += 1
        TEL["lim_cash"] = TEL.get("lim_cash", 0) + (k < n)
        n = k
        if n < 10:
            return a
        gain = sum(_wp(I - j) for j in range(n + 1, n + c + 1)) - sum(_wp(I - j) for j in range(1, c + 1))
        if gain < CFG["MIN_GAIN"]:
            return a
        if CFG["BUYSLOT"] == "pad":
            while len(market) < 9:
                market.append([])
        market.append(["BUY_PRODUCT", "WHEAT", n])
        mem["pend"] = {"n": n, "without": int(pshed.get("WHEAT", 0)), "step": step}
        TEL["buys"] += 1
        TEL["units"] += n
        a = dict(a)
        a["market"] = market
    except Exception:
        pass
    return a


def agent(observation, configuration=None):
    a = _decide(observation, configuration)
    try:
        if CFG["GUARD"] and isinstance(a, dict):
            step = int(_get(observation, "step", 0))
            me = int(_get(observation, "player", 0))
            _track(_MEM[me], observation, step, a)
    except Exception:
        pass
    return a
'''
_PRE_TICK_AGENT = globals().pop("agent")   # pop first: the loader takes the last callable in module order
_TICK_NS = {"__name__": "tick_layer", "_BASE": _PRE_TICK_AGENT, "_PROJECT": _project}
exec(compile(_TICK_SRC, "tick_layer", "exec"), _TICK_NS)
_TICK = _TICK_NS["agent"]


def agent(observation, configuration=None):
    return _TICK(observation, configuration)

# ---------------------------------------------------------------------------
# Team 42 TICK TRAP GUARD layer (outermost, v9). Some rivals trap the TICK layer's wheat round trip: at
# s % 4 == 0 they buy 80-90 wheat in slot 0 and sell as much in slot 9, against our last-slot tick buy (net flow
# zero, so the flow guard cannot see it), or they buy one step before our tick buy and sell with our tick sell.
# Money moves only in the market, so each step the cash of our own final orders is simulated alone with the
# engine's rules and compared with the realized cash one step later. Three of the last four tick cycles losing
# 40+ (or the prebuy flow pattern twice) pause TICK for the game, and a counter sells a wheat lot into the
# rival's lift (middle slot) and buys it back in the last slot after its sell, while that keeps paying.
_TG_SRC = r'''
import math as _math
CFG = {'ACT': 1, 'K': 4, 'NB': 3, 'BAD': 40.0, 'LOSS': 0.0, 'UNTIL': 700, 'PREBUY': 1, 'TH': 25, 'HITS': 2, 'WIN': 8, 'LOG': 0, 'CF': 1, 'CF_X': 80, 'CF_SLOT': 2, 'CF_MIN_N': 15, 'CF_UNTIL': 688, 'CF_RESERVE': 1500.0, 'CF_K': 8, 'CF_SPIKE': 60.0, 'CF_SPARE0': 1, 'CF_PICK': 2, 'CF_STOCK': 1, 'CF_PREBUY': 1}
TEL = {"devs": [], "cycles": [], "trap_step": None, "prebuy_step": None}
_MEM = {}
_MP = {
    "WHEAT": (25, 400, "sqrt", 0.80, "log", 0.20),
    "CARROT": (35, 450, "hinge", 1.00, "sqrt", 0.70),
    "TOMATO": (60, 200, "hinge", 0.40, "sqrt", 0.60),
    "STRAWBERRY": (120, 100, "sqrt", 0.70, "linear", 1.60),
    "MELON": (250, 300, "log", 0.20, "sq", 3.60),
    "EGG": (50, 332, "hinge", 0.40, "log", 0.20),
    "MILK": (160, 122, "sqrt", 0.60, "linear", 1.60),
    "WOOL": (200, 105, "log", 0.20, "sq", 3.20),
    "FERTILIZER": (100, 200, "linear", 0.40, "linear", 0.40),
}
_SHOPS = {
    "BAKERY": ["EGG", "WHEAT"], "PIZZA_SHOP": ["MILK", "TOMATO", "WHEAT"], "BRUNCH_SPOT": ["EGG", "WHEAT", "STRAWBERRY"],
    "YARN_STORE": ["WOOL"], "ICE_CREAM_SHOP": ["STRAWBERRY", "MILK", "WHEAT"], "PET_CAFE": ["CARROT"],
    "SMOOTHIE_SHOP": ["STRAWBERRY", "MILK"], "FARMERS_MARKET": ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY"],
}
_SEED_COST = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}
_ANIMAL_COST = {"GOOSE": 300, "COW": 400, "SHEEP": 500}
_LAND = [1000, 2000, 4000]
_FIBS = [1, 1]
while len(_FIBS) < 60:
    _FIBS.append(_FIBS[-1] + _FIBS[-2])


def _shape(f, x, T):
    x = max(0.0, x)
    if f == "linear":
        return x
    if f == "sq":
        return x * x
    if f == "sqrt":
        return _math.sqrt(x)
    if f == "log":
        return _math.log(1.0 + x)
    if f == "hinge":
        u = x / T
        return u + 8.0 * max(0.0, u - 1.0) ** 2
    return x


def _price(item, inv):
    base, T, bf, bt, af, at = _MP[item]
    if inv < 10000:
        p = base + bt * base / _shape(bf, T, T) * _shape(bf, 10000 - inv, T)
    else:
        p = base - at * base / _shape(af, T, T) * _shape(af, inv - 10000, T)
    return max(1, int(round(p)))


def _get(o, k, d=None):
    try:
        return o[k]
    except Exception:
        return getattr(o, k, d)


def _cons(shops, step):
    """Town consumption of every product after the market of `step` (engine _town_consume)."""
    c = {}
    if step % 4 == 0:
        for sh in shops:
            prods = _SHOPS.get(sh, [])
            m = 2 if len(prods) == 1 else 1
            for it in prods:
                c[it] = c.get(it, 0) + m
    if step % 24 == 0:
        for it in _MP:
            if it != "FERTILIZER":
                c[it] = c.get(it, 0) + 1
    return c


def _sim(observation, market, shed0, me):
    """Cash change of our market list alone, engine rules (_process_market / _commit_unit); also our effect on the
    market inventory per item and the items we traded."""
    farm = _get(observation, "farms")[me]
    money = float(_get(farm, "money", 0))
    hires = int(_get(farm, "hires_today", 0) or 0)
    nland = len(list(_get(farm, "unlocked_quadrants", ["NW"]) or ["NW"])) - 1
    inv = {k: int(v) for k, v in dict(_get(_get(observation, "market", {}) or {}, "inventory", {}) or {}).items()}
    inv0 = dict(inv)
    shed = {k: int(v) for k, v in dict(shed0).items()}
    cash = 0.0
    traded = set()
    for o in list(market)[:10]:
        if not isinstance(o, (list, tuple)) or not o:
            continue
        op = o[0]
        if op == "HIRE":
            c = _FIBS[min(59, hires)]
            if money >= c:
                money -= c
                cash -= c
                hires += 1
            continue
        if op == "BUY_LAND":
            if nland < len(_LAND) and money >= _LAND[nland]:
                money -= _LAND[nland]
                cash -= _LAND[nland]
                nland += 1
            continue
        if len(o) < 3:
            continue
        try:
            q = int(o[2])
        except Exception:
            continue
        item = o[1]
        for _ in range(max(0, q)):
            if op == "SELL":
                if item not in _MP or shed.get(item, 0) <= 0:
                    break
                p = _price(item, inv.get(item, 10000))
                shed[item] -= 1
                money += p
                cash += p
                traded.add(item)
                if p > 1:
                    inv[item] = inv.get(item, 10000) + 1
            elif op == "BUY_PRODUCT":
                if item not in ("WHEAT", "FERTILIZER"):
                    break
                p = _price(item, inv.get(item, 10000) - 1)
                if money < p or sum(shed.values()) >= 100:
                    break
                money -= p
                cash -= p
                traded.add(item)
                shed[item] = shed.get(item, 0) + 1
                inv[item] = inv.get(item, 10000) - 1
            elif op == "BUY_SEED":
                p = _SEED_COST.get(item)
                if p is None or money < p:
                    break
                money -= p
                cash -= p
            elif op == "BUY_ANIMAL":
                p = _ANIMAL_COST.get(item)
                if p is None or money < p or sum(shed.values()) >= 100:
                    break
                money -= p
                cash -= p
                shed[item] = shed.get(item, 0) + 1
            else:
                break
    delta = {k: inv[k] - inv0.get(k, 10000) for k in inv if inv[k] != inv0.get(k, 10000)}
    return cash, delta, traded, inv0


def _prebuy_hits(fl, step):
    hits = 0
    for s0 in range(step - 2, step - 2 - 4 * CFG["WIN"], -4):
        if fl.get(s0 - 1, 0) <= -CFG["TH"] and fl.get(s0 + 1, 0) >= CFG["TH"]:
            hits += 1
    return hits


def _pickups(me, step, horizon):
    """Wheat the base route's units pick up from the shed in the next `horizon` steps (their feed)."""
    try:
        ns = _NS.get("_BASE_NS") or _NS
        chassis = ns["_IMPL"].chassis
        native = chassis.players.get(me)
        if not native or native.get("route") is None:
            return 0
        total = 0
        for t in range(step + 1, min(719, step + 1 + horizon)):
            tape = chassis.routes.get(2 if t >= 648 else native["route"]) or []
            a = tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}
            for c in [a.get("farmer") or ["PASS"]] + list(a.get("hands") or []):
                if c and c[0] == "PICKUP" and len(c) >= 2 and c[1] == "WHEAT":
                    total += max(0, int(c[2]) if len(c) >= 3 else 1)
        return total
    except Exception:
        return 30


def _place_mid(market, order, lo):
    """Put order at an index in [lo, 8]: after the rival's slot-0/1 lift, before its slot-9 sell."""
    if len(market) <= 8:
        while len(market) < lo:
            market.append([])
        market.append(order)
        return True
    for i in range(lo, 9):
        if not market[i]:
            market[i] = order
            return True
    return False


def _place_last(market, order):
    if len(market) >= 10:
        slot = next((i for i, o in enumerate(market) if not o), None)
        if slot is None:
            return False
        market.pop(slot)
    while len(market) < 9:
        market.append([])
    market.append(order)
    return True


def _counter(observation, a, mem, step, me):
    """Sandwich fade: after the trap is confirmed, sell wheat in a middle slot at s % 4 == 0 (into the rival's slot-0
    lift, ahead of its slot-9 sell) and buy the lot back in the last slot of the next step."""
    market = [list(o) for o in (a.get("market") or []) if isinstance(o, (list, tuple))]
    live = [o for o in market if o]
    changed = None
    owned = int(mem.get("cf_owned", 0))
    if step > CFG["CF_UNTIL"] or not mem["cf_on"]:
        if owned > 0 and step <= 717:
            shed_w = int(_PROJECT(observation, dict(a, market=live))[0].get("WHEAT", 0))
            y = int(min(owned, shed_w))
            if y > 0 and len(live) < 10:
                market = live + [["SELL", "WHEAT", y]]
                changed = ("sell", y)
    elif step % 4 == mem.get("cf_phase", 0):
        shed_w = int(_PROJECT(observation, dict(a, market=live))[0].get("WHEAT", 0))
        pick = _pickups(me, step, CFG["CF_PICK"])
        cap = owned if (mem.get("cf_phase", 0) != 0 or not CFG["CF_SPARE0"]) else CFG["CF_X"]
        y = int(min(CFG["CF_X"], cap, shed_w - pick))
        if CFG.get("LOG"):
            TEL.setdefault("cf_log", []).append(("S", step, shed_w, pick, y, len(live)))
        if y >= CFG["CF_MIN_N"] and _place_mid(market, ["SELL", "WHEAT", y], CFG["CF_SLOT"]):
            changed = ("sell", y)
    elif step % 4 == 1 and step <= CFG["CF_UNTIL"] - 12:
        pshed, pinvs = _PROJECT(observation, dict(a, market=live))[:2]
        shed_w = int(pshed.get("WHEAT", 0))
        want = CFG["CF_X"] - owned
        carried = sum(int(v) for inv in pinvs for v in inv.values() if int(v) > 0)
        room = 100 - sum(int(v) for v in pshed.values()) - carried - 3
        farm = _get(observation, "farms")[me]
        quote = int(_get(_get(_get(observation, "market", {}) or {}, "prices", {}) or {}, "WHEAT", 40))
        cash = float(_get(farm, "money", 0)) - CFG["CF_RESERVE"]
        if CFG.get("LOG"):
            TEL.setdefault("cf_log", []).append(("B", step, shed_w, want, room, int(cash)))
        want = int(max(0, min(want, room, cash // max(1, quote + 6))))
        if want < 10:
            want = 0
        if want > 0 and _place_last(market, ["BUY_PRODUCT", "WHEAT", want]):
            changed = ("buy", want)
    if changed is None:
        return a, None
    a = dict(a)
    a["market"] = market[:10]
    return a, changed


def agent(observation, configuration=None):
    try:
        step = int(_get(observation, "step", 0))
        me = int(_get(observation, "player", 0))
    except Exception:
        return _BASE(observation, configuration)
    mem = _MEM.get(me)
    if mem is None or step <= mem["last"]:
        mem = _MEM[me] = {"last": -1, "prev": None, "cyc": None, "cycles": [], "trap": False, "prebuy": False,
                          "cf_on": False, "cf_off": False, "cf_cyc": None, "cf_cycles": [], "cf_sold_step": None}
    mem["last"] = step
    tick_mem = None
    try:
        tick_mem = _NS["_TICK_NS"]["_MEM"].get(me)
        money = float(_get(_get(observation, "farms")[me], "money", 0))
        prev = mem["prev"]
        mem["prev"] = None
        if prev is not None and prev["step"] == step - 1:
            dev = money - prev["money"] - prev["E"]
            inv_now = dict(_get(_get(observation, "market", {}) or {}, "inventory", {}) or {})
            cons = _cons(prev["shops"], prev["step"])
            clean = True
            for it in prev["traded"]:
                if it == "WHEAT":
                    continue
                rf = int(inv_now.get(it, 10000)) - prev["inv"].get(it, 10000) - prev["delta"].get(it, 0) + cons.get(it, 0)
                if rf != 0:
                    clean = False
                    break
            if CFG.get("LOG"):
                TEL["devs"].append((prev["step"], round(dev, 1), prev["tick"], prev["tsell"], prev.get("cf"), clean)
                                   + ((prev.get("mk"), prev.get("shed0")) if CFG.get("LOG", 0) >= 2 else ()))
            cf = prev.get("cf")
            if cf and cf[0] == "sell":
                mem["cf_cyc"] = {"s0": prev["step"], "dev": dev, "clean": clean}
                mem["cf_cyc_s0"] = prev["step"]
            elif cf and cf[0] == "buy" and mem["cf_cyc"] is not None and prev["step"] - mem["cf_cyc"]["s0"] <= 2:
                d = mem["cf_cyc"]["dev"] + dev
                ok = mem["cf_cyc"]["clean"] and clean
                mem["cf_cyc"] = None
                TEL.setdefault("cf_cycles", []).append((mem["cf_cyc_s0"], round(d), ok))
                if ok:
                    mem["cf_cycles"].append(d)
                last = mem["cf_cycles"][-CFG["CF_K"]:]
                if ok and len(last) >= CFG["CF_K"] and max(last) < CFG["CF_SPIKE"]:
                    mem["cf_on"] = False
                    mem["cf_off"] = True
                    TEL["cf_off_step"] = step
            if prev["tick"]:
                mem["cyc"] = {"s0": prev["step"], "dev": dev, "clean": clean}
            elif prev["tsell"] and mem["cyc"] is not None and mem["cyc"]["s0"] == prev["step"] - 1:
                d = mem["cyc"]["dev"] + dev
                ok = mem["cyc"]["clean"] and clean
                mem["cyc"] = None
                TEL["cycles"].append((prev["step"] - 1, round(d), ok))
                if ok:
                    mem["cycles"].append(d)
                last = mem["cycles"][-CFG["K"]:]
                bad = sum(1 for x in last if x <= -CFG["BAD"])
                if ok and not mem["trap"] and prev["step"] <= CFG["UNTIL"] and len(last) >= CFG["K"] and (
                        bad >= CFG["NB"] or (CFG["LOSS"] > 0 and sum(last) < -CFG["LOSS"])):
                    mem["trap"] = True
                    TEL["trap_step"] = step
                    if CFG["CF"] and not mem["cf_off"]:
                        mem["cf_on"] = True
                        mem["cf_phase"] = 0
        if CFG["PREBUY"] and not mem["prebuy"] and tick_mem is not None and step % 4 == 2:
            if _prebuy_hits(tick_mem.get("flow") or {}, step) >= CFG["HITS"]:
                mem["prebuy"] = True
                TEL["prebuy_step"] = step
                if CFG["CF"] and CFG["CF_PREBUY"] and not mem["cf_off"] and not mem["trap"]:
                    mem["cf_on"] = True
                    mem["cf_phase"] = 3
        if CFG["ACT"] and (mem["trap"] or mem["prebuy"]) and tick_mem is not None:
            tick_mem["rival"] = True
    except Exception:
        pass
    pend_before = (tick_mem or {}).get("pend") if tick_mem is not None else None
    a = _BASE(observation, configuration)
    cfd = None
    try:
        if mem.get("cf_owned", 0) > 0:
            shed_now = int((_get(_get(observation, "private"), "shed", {}) or {}).get("WHEAT", 0))
            mem["cf_owned"] = min(mem["cf_owned"], shed_now)
        if CFG["ACT"] and (mem["cf_on"] or mem.get("cf_owned", 0) > 0) and isinstance(a, dict):
            a, cfd = _counter(observation, a, mem, step, me)
            if cfd is not None:
                TEL["cf_" + cfd[0]] = TEL.get("cf_" + cfd[0], 0) + cfd[1]
                if cfd[0] == "sell":
                    mem["cf_sold_step"] = step
                    mem["cf_owned"] = max(0, mem.get("cf_owned", 0) - cfd[1])
                else:
                    mem["cf_owned"] = mem.get("cf_owned", 0) + cfd[1]
    except Exception:
        cfd = None
    try:
        if isinstance(a, dict):
            tick_mem = _NS["_TICK_NS"]["_MEM"].get(me) or {}
            pend = tick_mem.get("pend")
            tick = bool(pend and pend.get("step") == step)
            shed0 = _PROJECT(observation, dict(a, market=[]))[0]
            E, delta, traded, inv0 = _sim(observation, a.get("market") or [], shed0, me)
            shops = list(_get(_get(observation, "town", {}) or {}, "unlocked_shops", []) or [])
            mem["prev"] = {"step": step, "money": float(_get(_get(observation, "farms")[me], "money", 0)), "E": E,
                           "delta": delta, "traded": traded, "inv": inv0, "shops": shops,
                           "tick": tick and pend_before is None, "tsell": pend_before is not None, "cf": cfd}
            if CFG.get("LOG", 0) >= 2:
                mem["prev"]["mk"] = [list(o) for o in (a.get("market") or [])]
                mem["prev"]["shed0"] = dict(shed0)
    except Exception:
        pass
    return a
'''
_PRE_TG_AGENT = globals().pop("agent")   # pop first: the loader takes the last callable in module order
_TG_NS = {"__name__": "tick_trap_guard", "_BASE": _PRE_TG_AGENT, "_PROJECT": _project, "_NS": globals()}
exec(compile(_TG_SRC, "tick_trap_guard", "exec"), _TG_NS)
_TG_AGENT = _TG_NS["agent"]


def agent(observation, configuration=None):
    return _TG_AGENT(observation, configuration)
